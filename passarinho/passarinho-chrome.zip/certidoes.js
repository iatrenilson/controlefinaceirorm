// Certidões (Federal, Estadual, Eleitoral, Militar): sites, preenchimento e o "Emitir todas".
// Carregado pelo popup.html E pelo background (2026-11-23): o "Emitir todas" roda no background, para terminar
// mesmo se a janelinha da extensão fechar (antes parava no meio e nem todas eram preenchidas).

// ── Certidões pelo menu da página da PF (o usuário pediu, 2026-11-22, vendo o "Emitir todas" de outro sistema) ──
// Abre cada site numa aba e preenche com os dados do cliente escolhido no menu. Endereços = os favoritos do usuário.
// O captcha (e o envio) de cada site fica com o usuário.
const SITES_CERTIDAO = {
  federal:   { nome: "Justiça Federal (TRF1)",   url: "https://sistemas.trf1.jus.br/certidao/#/solicitacao", func: "injectarTrf1", world: "MAIN" },
  estadual:  { nome: "Justiça Estadual (TJAM)",  url: "https://sistemas.tjam.jus.br/certidaounica/#/home",   func: "injectarDados", world: "ISOLATED" },
  eleitoral: { nome: "Justiça Eleitoral (TSE)",  url: "https://www.tse.jus.br/servicos-eleitorais/autoatendimento-eleitoral#/", func: "injectarTse", world: "MAIN" },
  militar:   { nome: "Justiça Militar (STM)",    url: "https://www2.stm.jus.br/ceneg_internet/emitir/index.php", func: "injectarStm", world: "ISOLATED" },
};
// Popup e menu chamam esta: pede ao background para abrir e preencher (lá não para se a janelinha fechar). Se o
// background não responder, faz aqui mesmo, como antes.
async function emitirCertidoesNoFundo(cliente, quais) {
  try {
    const r = await chrome.runtime.sendMessage({ action: "emitirCertidoes", cliente, quais });
    if (Array.isArray(r?.resultados)) return r.resultados;
  } catch (_) {}
  return emitirCertidoes(cliente, quais);
}

async function emitirCertidoes(cliente, quais) {
  const dados = {
    nome: (cliente.nome || "").toUpperCase(),
    cpf: cliente.cpf || "",
    nomeMae: (cliente.nome_mae || "").toUpperCase(),
    nomePai: (cliente.nome_pai || "").toUpperCase(),
    dataNascimento: cliente.data_nascimento || "",
    email: "",
  };
  const funcs = { injectarTrf1, injectarDados, injectarTse, injectarStm };
  // abre todas as abas em segundo plano e preenche cada uma quando o site terminar de carregar; só no fim mostra a
  // primeira (o popup do ícone fecha quando uma aba vai para a frente, e pararia o preenchimento no meio)
  // Sempre na janela NORMAL (2026-11-23): partindo do Portal PF / Sinarm / SisGCorp, que ficam na janela anônima, as abas
  // abriam lá e nada era preenchido (o usuário viu: "só emite quando eu parto da tela do meu site")
  let janela = null;
  try { janela = (await chrome.windows.getAll({ windowTypes: ["normal"] })).find(w => !w.incognito) || null; } catch (_) {}
  if (!janela) janela = await chrome.windows.create({ incognito: false, focused: false }).catch(() => null);
  const naJanela = janela?.id ? { windowId: janela.id } : {};
  const abas = [];
  for (const q of quais) {
    const site = SITES_CERTIDAO[q];
    if (!site) continue;
    const tab = await chrome.tabs.create({ url: site.url, active: false, ...naJanela });
    abas.push({ site, tabId: tab.id });
  }
  const resultados = await Promise.all(abas.map(async ({ site, tabId }) => {
    const fim = Date.now() + 90000; // 4 sites carregando juntos: 45 s às vezes não dava
    let ultimo = "";
    while (Date.now() < fim) {
      await new Promise(r => setTimeout(r, 2500));
      const t = await chrome.tabs.get(tabId).catch(() => null);
      if (!t) return { nome: site.nome, ok: false, msg: "aba fechada" };
      if (t.status !== "complete") continue;
      // Federal: o preenchimento fica rodando dentro da página e espera a aba ser aberta (a lista "Tipo de Certidão"
      // não abre em segundo plano). Não espera aqui: o popup pode fechar e a página termina sozinha
      if (site.func === "injectarTrf1") {
        chrome.scripting.executeScript({ target: { tabId }, world: site.world, func: funcs[site.func], args: [dados] }).catch(() => {});
        return { nome: site.nome, ok: true, msg: "" , depois: true };
      }
      try {
        const res = (await chrome.scripting.executeScript({ target: { tabId }, world: site.world, func: funcs[site.func], args: [dados] }))?.[0]?.result;
        const n = typeof res === "object" ? (res?.n || 0) : (res || 0);
        if (n > 0) return { nome: site.nome, ok: true, msg: `${n} campo(s)` };
        ultimo = (typeof res === "object" && res?.dbg) || "formulário ainda não apareceu";
      } catch (e) { ultimo = String(e?.message || e).slice(0, 60); }
    }
    return { nome: site.nome, ok: false, msg: ultimo || "não consegui preencher" };
  }));
  if (abas[0]) {
    chrome.tabs.update(abas[0].tabId, { active: true }).catch(() => {});
    if (janela?.id) chrome.windows.update(janela.id, { focused: true }).catch(() => {});
  }
  return resultados;
}

async function injectarDados(dados) {
  function setInput(el, valor) {
    if (!el || !valor) return false;
    el.focus();
    try {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set
        || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
      setter.call(el, valor);
    } catch (_) { el.value = valor; }
    ["input", "change", "blur", "keyup"].forEach(ev =>
      el.dispatchEvent(new Event(ev, { bubbles: true })));
    return true;
  }

  // Busca campo por lista de candidatos (placeholder, name, id, aria-label, label, texto próximo)
  function achar(candidatos) {
    for (const texto of candidatos) {
      if (!texto) continue;
      const t = texto.toLowerCase();
      // por placeholder
      for (const el of document.querySelectorAll("input, textarea")) {
        if ((el.placeholder || "").toLowerCase().includes(t)) return el;
      }
      // por name ou id
      for (const el of document.querySelectorAll("input, textarea")) {
        if ((el.name || "").toLowerCase().includes(t) || (el.id || "").toLowerCase().includes(t)) return el;
      }
      // por aria-label
      for (const el of document.querySelectorAll("input[aria-label], textarea[aria-label]")) {
        if ((el.getAttribute("aria-label") || "").toLowerCase().includes(t)) return el;
      }
      // por label/span próximo
      for (const lbl of document.querySelectorAll("label, mat-label, span, legend, div")) {
        if (lbl.textContent.trim().toLowerCase().includes(t)) {
          const container = lbl.closest("mat-form-field, .form-group, .field, fieldset, tr, div, li");
          if (container) {
            const inp = container.querySelector("input, textarea");
            if (inp) return inp;
          }
          // label com for=
          if (lbl.htmlFor) {
            const el = document.getElementById(lbl.htmlFor);
            if (el) return el;
          }
        }
      }
    }
    return null;
  }

  function formatarData(iso) {
    if (!iso) return "";
    const p = iso.split("T")[0].split("-");
    return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : iso;
  }

  const data = formatarData(dados.dataNascimento);
  let n = 0;

  const mapeamento = [
    { valor: dados.nome,    chaves: ["nome completo", "nome", "name", "requerente", "solicitante", "titular"] },
    { valor: dados.cpf,     chaves: ["cpf", "cadastro de pessoa", "documento"] },
    { valor: dados.nomeMae, chaves: ["nome da mãe", "nome mae", "mae", "mãe", "mother", "filiação", "filiacao"] },
    { valor: dados.nomePai, chaves: ["nome do pai", "nome pai", "pai", "father", "nome_pai"] },
    { valor: data,          chaves: ["data de nascimento", "nascimento", "data nasc", "birth", "dt_nasc", "dtnascimento"] },
    { valor: dados.email,   chaves: ["e-mail", "email", "correio"] },
  ];

  for (const { valor, chaves } of mapeamento) {
    if (!valor) continue;
    const el = achar(chaves);
    if (setInput(el, valor)) n++;
  }

  // Certidão Estadual (TJAM): depois de preencher, clica em "Consultar" (o usuário pediu, 2026-11-22; a Federal já
  // clicava em "Emitir Certidão"). Espera o botão ficar habilitado (o site valida os campos antes)
  if (n > 0 && /tjam\.jus\.br$/i.test(location.hostname)) {
    const esperar = ms => new Promise(r => setTimeout(r, ms));
    await esperar(700);
    const fim = Date.now() + 6000;
    let btn = null;
    while (Date.now() < fim) {
      btn = [...document.querySelectorAll("button")].find(b => /^\s*consultar\s*$/i.test(b.textContent || ""));
      if (btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") break;
      await esperar(250);
    }
    if (btn && !btn.disabled) { btn.click(); return { n, dbg: "consultar=ok" }; }
    return { n, dbg: btn ? "botão Consultar desabilitado (confira os campos)" : "botão Consultar não encontrado" };
  }

  return n;
}

async function injectarTrf1(dados) {
  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
  function norm(s) { return (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }

  function clickOpt(opt) {
    opt.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
    opt.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    opt.click();
    opt.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
  }

  async function aguardarOpcao(pred, timeoutMs = 4000) {
    const fim = Date.now() + timeoutMs;
    while (Date.now() < fim) {
      const opts = Array.from(document.querySelectorAll("mat-option"));
      const found = opts.find(o => !norm(o.textContent).includes("selecionar") && pred(o));
      if (found) return found;
      await delay(150);
    }
    return null;
  }

  // Aba aberta em segundo plano ("Emitir todas"): a lista "Tipo de Certidão" só abre com a aba visível, e antes só o
  // CPF entrava (o usuário viu, 2026-11-22). Espera a pessoa abrir a aba e então preenche tudo. Uma vez por página.
  if (window.__passarinho_trf1) return { n: 0, dbg: "já em andamento nesta aba" };
  window.__passarinho_trf1 = true;
  try {
    if (document.hidden) await new Promise(r => {
      const f = () => { if (!document.hidden) { document.removeEventListener("visibilitychange", f); r(); } };
      document.addEventListener("visibilitychange", f);
    });
    // o formulário (Angular) pode ainda estar montando
    const fimForm = Date.now() + 15000;
    while (Date.now() < fimForm && !document.querySelector("mat-select")) await delay(300);
    await delay(400);
  } catch (_) {}

  let n = 0;
  let dbg = "";

  // 1. Tipo de Certidão → Criminal
  const tipoSelect = Array.from(document.querySelectorAll("mat-select")).find(el =>
    norm(el.closest("mat-form-field")?.querySelector("mat-label, label")?.textContent || "").includes("tipo") ||
    norm(el.closest("mat-form-field")?.querySelector("mat-label, label")?.textContent || "").includes("certid")
  );
  dbg += tipoSelect ? "tipo=ok" : "tipo=null";
  if (tipoSelect) {
    tipoSelect.click();
    const criminal = await aguardarOpcao(o => norm(o.textContent).includes("criminal"));
    if (criminal) { clickOpt(criminal); n++; await delay(300); dbg += ",crim=ok"; }
    else dbg += ",crim=null";
  }

  // 2. Órgão: igual ao Tipo de Certidão — abre painel com click e seleciona opção
  // O autocomplete mostra sempre as 16 opções fixas (sem filtro), basta achar e clicar
  const orgaoInput = document.getElementById("mat-mdc-chip-list-input-0") ||
    Array.from(document.querySelectorAll("input")).find(el =>
      norm(el.placeholder || "").includes("orgao") ||
      norm(el.placeholder || "").includes("selecionar") ||
      norm(el.closest("mat-form-field")?.querySelector("mat-label, label")?.textContent || "").includes("orgao")
    );
  dbg += orgaoInput ? ",org=ok" : ",org=null";
  if (orgaoInput) {
    await delay(400);
    // Abre o painel: sequência idêntica ao que funciona no browser
    orgaoInput.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    orgaoInput.focus();
    orgaoInput.dispatchEvent(new FocusEvent("focus", { bubbles: false }));
    orgaoInput.dispatchEvent(new FocusEvent("focusin", { bubbles: true }));
    orgaoInput.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
    orgaoInput.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    await delay(500);

    dbg += `,opts=${document.querySelectorAll("mat-option").length}`;

    // Encontra a opção do Amazonas (todas as 16 opções aparecem sem filtro)
    const orgaoOpt = await aguardarOpcao(o => norm(o.textContent).includes("amazonas"), 4000);
    dbg += orgaoOpt ? ",opt=ok" : ",opt=null";
    if (orgaoOpt) {
      clickOpt(orgaoOpt);
      n++;
      await delay(400);
      const chips = document.querySelectorAll("mat-chip, .mat-mdc-chip, .mdc-evolution-chip");
      dbg += `,chip=${chips.length}`;
    }
  }

  // 3. CPF — placeholder "Ex. 000.000.000-00"
  const cpfInput = Array.from(document.querySelectorAll("input")).find(el =>
    (el.placeholder || "").includes("000.000.000") ||
    norm(el.closest("mat-form-field")?.querySelector("mat-label, label")?.textContent || "").includes("cpf")
  );
  if (cpfInput) {
    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    try { nativeSetter.call(cpfInput, dados.cpf); } catch(_) { cpfInput.value = dados.cpf; }
    cpfInput.dispatchEvent(new InputEvent("input", { data: dados.cpf, inputType: "insertText", bubbles: true }));
    cpfInput.dispatchEvent(new Event("change", { bubbles: true }));
    n++;
    dbg += ",cpf=ok";
  } else dbg += ",cpf=null";

  // 4. Fecha a lista de Órgãos (fica aberta depois de escolher) e clica em "Emitir Certidão"
  const ativo = document.activeElement;
  if (ativo) {
    ativo.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
    ativo.blur();
  }
  document.body.click();
  await delay(500);

  const fimBtn = Date.now() + 5000;
  let btnEmitir = null;
  while (Date.now() < fimBtn) {
    btnEmitir = Array.from(document.querySelectorAll("button")).find(b =>
      norm(b.textContent).includes("emitir certid"));
    if (btnEmitir && !btnEmitir.disabled && btnEmitir.getAttribute("aria-disabled") !== "true") break;
    await delay(200);
  }
  if (btnEmitir && !btnEmitir.disabled) {
    btnEmitir.click();
    dbg += ",emitir=ok";
  } else dbg += btnEmitir ? ",emitir=desabilitado" : ",emitir=null";

  return { n, dbg };
}


async function injectarTse(dados) {
  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
  function norm(s) { return (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }

  async function aguardarEl(pred, ms = 5000) {
    const fim = Date.now() + ms;
    while (Date.now() < fim) { const el = pred(); if (el) return el; await delay(200); }
    return null;
  }

  function labelDo(el) {
    // Texto do label/span mais próximo associado ao input
    const cont = el.closest("label, .form-group, mat-form-field, [class*='field'], [class*='form'], li, tr, div");
    return norm(cont?.querySelector("label, mat-label, legend, span, p, th, td")?.textContent || "");
  }

  function setInput(el, valor) {
    if (!el || !valor) return false;
    el.focus();
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    try { setter ? setter.call(el, valor) : (el.value = valor); } catch { el.value = valor; }
    ["input", "change", "blur"].forEach(ev =>
      el.dispatchEvent(new Event(ev, { bubbles: true })));
    return true;
  }

  // Localiza input por lista de palavras-chave (placeholder, aria-label, name, id, label próximo)
  function acharInput(chaves) {
    for (const el of document.querySelectorAll("input:not([type='hidden']), textarea")) {
      const attrs = norm([el.placeholder, el.getAttribute("aria-label"), el.name, el.id].join(" "));
      if (chaves.some(k => attrs.includes(k))) return el;
    }
    for (const el of document.querySelectorAll("input:not([type='hidden']), textarea")) {
      if (chaves.some(k => labelDo(el).includes(k))) return el;
    }
    return null;
  }

  let n = 0, dbg = "";

  // Se estiver na página principal, clica em "Certidão de crimes eleitorais"
  const linkCrimes = await aguardarEl(() =>
    [...document.querySelectorAll("a, button, li, span, div")]
      .find(el => {
        const t = el.textContent.trim();
        return t.length < 80 && norm(t).includes("crimes eleit");
      }), 2000);

  if (linkCrimes) {
    dbg += "link=ok";
    linkCrimes.click();
    await delay(2500);
  } else {
    dbg += "link=skip";
  }

  // Aguarda campo CPF aparecer
  const cpfInput = await aguardarEl(() => acharInput(["cpf", "cadastro de pessoa"]), 5000);

  if (!cpfInput) { return { n: 0, dbg: dbg + ",cpf=nf" }; }

  if (setInput(cpfInput, dados.cpf)) { n++; dbg += ",cpf=ok"; }
  await delay(800);

  // Nome completo
  const nomeInput = acharInput(["nome completo", "nome do requerente", "nome"]);
  if (nomeInput && nomeInput !== cpfInput) {
    // Tira as marcações do cadastro, ex.: "(PARADO) (MARTINS) FULANO" → "FULANO"
    const nomeLimpo = (dados.nome || "").replace(/\([^)]*\)/g, " ").replace(/\s+/g, " ").trim();
    if (setInput(nomeInput, nomeLimpo)) { n++; dbg += ",nome=ok"; }
    await delay(400);
  }

  // Opção de filiação: sem nome do pai → escolhe a opção só com o nome da mãe
  if (!(dados.nomePai || "").trim()) {
    const selFil = [...document.querySelectorAll("select")].find(s =>
      [...s.options].some(o => norm(o.textContent).includes("mae")));
    const optMae = selFil && [...selFil.options].find(o => {
      const t = norm(o.textContent);
      return t.includes("apenas") && t.includes("mae") && !t.includes("pai"); // "APENAS NOME DE MÃE"
    });
    if (optMae) {
      selFil.value = optMae.value;
      selFil.dispatchEvent(new Event("input", { bubbles: true }));
      selFil.dispatchEvent(new Event("change", { bubbles: true }));
      dbg += ",filiacao=mae";
      await delay(600);
    } else dbg += ",filiacao=nf";
  }

  // Nome da mãe
  const maeInput = acharInput(["nome da mae", "nome mae", "mae", "filiacao mae", "mae do requerente"]);
  if (maeInput && setInput(maeInput, dados.nomeMae)) { n++; dbg += ",mae=ok"; }
  await delay(400);

  // Nome do pai
  const paiInput = acharInput(["nome do pai", "nome pai", "pai", "filiacao pai", "pai do requerente"]);
  if (paiInput && setInput(paiInput, dados.nomePai)) { n++; dbg += ",pai=ok"; }
  await delay(400);

  // Data de nascimento
  if (dados.dataNascimento) {
    const [ano, mes, dia] = dados.dataNascimento.split("T")[0].split("-");
    const dtInput = acharInput(["data de nasc", "nascimento", "data nasc", "dt nasc", "birth"]);
    if (dtInput) {
      const val = dtInput.type === "date" ? `${ano}-${mes}-${dia}` : `${dia}/${mes}/${ano}`;
      if (setInput(dtInput, val)) { n++; dbg += ",dob=ok"; }
      await delay(400);
    }
  }

  // Aguarda validação do formulário antes de clicar
  await delay(1500);

  // Clica em "Entrar" (não no "Entrar com e-Título")
  const fimBtn = Date.now() + 5000;
  let btnEntrar = null;
  while (Date.now() < fimBtn) {
    btnEntrar = [...document.querySelectorAll("button, input[type='submit'], input[type='button'], a")]
      .find(b => norm((b.value || b.textContent || "").trim()) === "entrar");
    if (btnEntrar && !btnEntrar.disabled && btnEntrar.getAttribute("aria-disabled") !== "true") break;
    await delay(200);
  }
  if (btnEntrar && !btnEntrar.disabled) {
    btnEntrar.click();
    dbg += ",entrar=ok";
  } else dbg += btnEntrar ? ",entrar=desabilitado" : ",entrar=null";

  return { n, dbg };
}

function injectarStm(dados) {
  function set(name, value) {
    const el = document.querySelector(`[name="${name}"]`);
    if (!el || value === undefined || value === null || value === "") return false;
    el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  let n = 0;

  // Nome completo
  if (set("txt_nome", dados.nome)) n++;

  // CPF: "960.100.100-00" → 960 | 100 | 100 | 00
  const cpf = (dados.cpf || "").replace(/\D/g, "");
  if (cpf.length === 11) {
    set("txt_cpf1", cpf.slice(0, 3));
    set("txt_cpf2", cpf.slice(3, 6));
    set("txt_cpf3", cpf.slice(6, 9));
    set("txt_dv",   cpf.slice(9, 11));
    n++;
  }

  // Data de nascimento: "1990-05-15" → dia=15, mes=05, ano=1990
  const iso = (dados.dataNascimento || "").split("T")[0];
  const partes = iso.split("-");
  if (partes.length === 3) {
    set("txt_dia", partes[2]);
    set("txt_mes", partes[1]);
    set("txt_ano", partes[0]);
    n++;
  }

  // Nome da mãe
  if (set("txt_nome_mae", dados.nomeMae)) n++;

  // Espera a pessoa marcar o "Não sou um robô" e então clica em "Emitir".
  // O reCAPTCHA é marcado pela pessoa; a extensão só aguarda a confirmação dele.
  if (window.__passarinhoStmTimer) clearInterval(window.__passarinhoStmTimer);
  const inicio = Date.now();
  window.__passarinhoStmTimer = setInterval(() => {
    if (Date.now() - inicio > 120000) { clearInterval(window.__passarinhoStmTimer); return; }
    const resp = document.querySelector("textarea[name='g-recaptcha-response'], #g-recaptcha-response");
    if (!resp || !resp.value) return;
    clearInterval(window.__passarinhoStmTimer);
    const btn = [...document.querySelectorAll("input[type='submit'], input[type='button'], button")]
      .find(el => ((el.value || el.textContent || "").trim().toLowerCase() === "emitir"));
    if (btn) btn.click();
  }, 400);

  return { n, dbg: "— marque o \"Não sou um robô\" que eu clico em Emitir." };
}
