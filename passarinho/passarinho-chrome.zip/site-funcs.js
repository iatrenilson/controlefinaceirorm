// Consultas que o Passarinho faz no sistema RW (rwinvestimentos.com.br), rodando DENTRO da aba do sistema (mundo da
// página, onde o site deixa window.__passarinho_supabase com o login de quem está nela).
// Ficam aqui, com nome, porque são usadas por dois lugares:
//  - popup.js / menu-painel.js (menu na página da PF): rodam direto na aba do sistema;
//  - background.js: quando o menu está numa aba ANÔNIMA e o sistema na janela normal, o Chrome não deixa o menu rodar
//    nada lá ("No tab with id"); o background (perfil normal) roda por ele, só estas funções, chamadas pelo nome.
// Cada função tem de ser independente (o Chrome a copia para a página): nada de variáveis de fora.
const SITE_FUNCS = {
  // lista de clientes de Clientes Armas (sem login a busca volta vazia sem erro: não conta como aba que funciona)
  clientes: async () => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data, error } = await sb
      .from("declaracao_clientes")
      .select("id,nome,cpf,rg,orgao_emissor,data_expedicao,data_nascimento,nome_mae,nome_pai,endereco,numero,complemento,bairro,cidade,estado,cep,telefone,profissao,local_nascimento,uf_nascimento,email,titulo_eleitor,genero")
      .order("nome");
    if (error || !data?.length) return { ok: false };
    return { ok: true, data };
  },

  // documentos (Docs CR) de um cliente
  docsCliente: async (cid) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data, error } = await sb
      .from("declaracao_docs_cr")
      .select("tipo,file_url,file_name")
      .eq("cliente_id", cid);
    if (error) return { ok: false };
    // aba sem login também volta vazia: o cliente existe, então confere com uma aba que enxergue o cadastro dele
    if (!data?.length) {
      const { data: cli } = await sb.from("declaracao_clientes").select("id").eq("id", cid).maybeSingle();
      if (!cli) return { ok: false };
    }
    return { ok: true, docs: data || [] };
  },

  // nome do cliente (o "Login PF" confere se a conta aberta no portal é dele antes de ir para o Sinarm CAC)
  nomeCliente: async (cid) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data } = await sb.from("declaracao_clientes").select("nome").eq("id", cid).maybeSingle();
    return data ? { ok: true, nome: data.nome || "" } : { ok: false };
  },

  // CPF e Senha GOV.br do cliente, para o login no gov.br (só o background usa, e só na aba que a Passarinho abriu)
  credGov: async (cid) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data, error } = await sb.from("declaracao_clientes").select("cpf,senha_gov").eq("id", cid).maybeSingle();
    if (error || !data) return { ok: false };
    return { ok: true, cpf: data.cpf || "", senha: data.senha_gov || "" };
  },

  // grava a lista de processos lida no Sinarm CAC / Portal PF (tabela processos_pf)
  salvarProcessos: async (clienteId, linhas) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data: antes, error: e1 } = await sb.from("processos_pf").select("protocolo,status").eq("cliente_id", clienteId);
    if (e1) return { ok: false, erro: e1.message };
    const anterior = Object.fromEntries((antes || []).map(p => [p.protocolo, p.status]));
    const agora = new Date().toISOString();
    const linha = l => ({ cliente_id: clienteId, protocolo: l.protocolo, servico: l.servico, descricao: l.descricao || "",
      status: l.status, data_solicitacao: l.data || null, consultado_em: agora, origem: l.origem || "portal",
      motivo: l.motivo || "", gru: l.gru || "", posicao_fila: l.posicao_fila || "" });
    // status novo ou diferente: marca desde quando; igual: só atualiza a hora da consulta
    const mudou = linhas.filter(l => anterior[l.protocolo] !== l.status).map(l => ({ ...linha(l), status_desde: agora }));
    const igual = linhas.filter(l => anterior[l.protocolo] === l.status).map(linha);
    for (const lote of [mudou, igual]) {
      if (!lote.length) continue;
      const { error } = await sb.from("processos_pf").upsert(lote, { onConflict: "cliente_id,protocolo" });
      if (error) return { ok: false, erro: error.message };
    }
    return { ok: true, mudaram: mudou.filter(l => anterior[l.protocolo] !== undefined).length };
  },
  // Pedido de atualização feito pelo cliente no celular (tabela pedidos_atualizacao, 2026-11-25): pega o mais antigo
  // pendente (dos últimos 3 dias) e marca como "rodando", para só um computador atender
  pegarPedido: async () => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const desde = new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(); // pedido guardado com o computador desligado (até 3 dias)
    // os pedidos do próprio cliente passam na frente dos da consulta geral do escritório (automatico)
    const { data, error } = await sb.from("pedidos_atualizacao").select("id,cliente_id,automatico")
      .eq("status", "pendente").gt("pedido_em", desde).order("automatico").order("pedido_em").limit(1);
    if (error) return { ok: false, erro: error.message };
    if (!data?.length) return { ok: true, pedido: null };
    const p = data[0];
    const { data: marcou } = await sb.from("pedidos_atualizacao")
      .update({ status: "rodando", atualizado_em: new Date().toISOString() })
      .eq("id", p.id).eq("status", "pendente").select("id");
    if (!marcou?.length) return { ok: true, pedido: null };
    const { data: cli } = await sb.from("declaracao_clientes").select("id,nome,cpf,senha_gov").eq("id", p.cliente_id).maybeSingle();
    // cliente com processo no Sinarm CAC (GT etc.): a consulta passa também por lá
    const { count: noSinarm } = await sb.from("processos_pf").select("id", { count: "exact", head: true })
      .eq("cliente_id", p.cliente_id).eq("origem", "sinarm");
    // a senha não sai daqui: só se o cadastro tem CPF e senha
    return { ok: true, pedido: { id: p.id, clienteId: p.cliente_id, nome: cli?.nome || "", temLogin: !!(cli?.cpf && cli?.senha_gov),
      temSinarm: (noSinarm || 0) > 0, automatico: !!p.automatico } };
  },
  // Consulta geral: um aviso no sino a CADA cliente consultado (o usuário pediu, 2026-11-27: "a cada consulta
  // informando, ficaria mais certeza que funcionou"), com o status dos processos ou o motivo de não ter dado
  avisoPedidoAutomatico: async (pedidoId) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data: p } = await sb.from("pedidos_atualizacao").select("cliente_id,status,mensagem").eq("id", pedidoId).maybeSingle();
    if (!p || (p.status !== "feito" && p.status !== "erro")) return { ok: false };
    if (/duas etapas/.test(p.mensagem || "")) return { ok: true }; // esse já tem o aviso próprio (🔐)
    const { data: c } = await sb.from("declaracao_clientes").select("nome").eq("id", p.cliente_id).maybeSingle();
    const { data: procs } = await sb.from("processos_pf").select("servico,status,descricao").eq("cliente_id", p.cliente_id);
    const curto = s => String(s || "").replace(/\s*\([^)]*\)/g, "").replace(/^Emitir |^Solicitar /i, "").slice(0, 45);
    const st = [...new Set((procs || []).filter(x => x.status && !/rascunho/i.test(x.descricao || ""))
      .map(x => `${curto(x.servico)}: ${x.status}`))].slice(0, 4).join(" · ");
    const { data: { user } } = await sb.auth.getUser();
    const { error } = await sb.from("notifications").insert(p.status === "feito"
      ? { titulo: `🔎 Consultado: ${c?.nome || "Cliente"}`, mensagem: st || "Nenhuma solicitação na Polícia Federal.",
          created_by: user?.id, target_user_id: user?.id }
      : { titulo: `⚠️ Não consultado: ${c?.nome || "Cliente"}`, mensagem: `Motivo: ${p.mensagem || "erro"}. Segue para o próximo.`,
          created_by: user?.id, target_user_id: user?.id });
    return { ok: !error };
  },
  // Resumo da consulta geral (2026-11-27, o usuário pediu: "como eu sei que foi consultado?"): quando não sobra nenhum
  // pedido automático na fila, uma notificação no sino de quem está logado com cada cliente consultado e o status dos
  // processos dele, e os que não deram certo com o motivo. desde = só os pedidos terminados depois do último resumo.
  resumoConsultaGeral: async (desde) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { count: falta } = await sb.from("pedidos_atualizacao").select("id", { count: "exact", head: true })
      .eq("automatico", true).in("status", ["pendente", "rodando"]);
    if (falta) return { ok: true, pronto: false };
    const { data: peds } = await sb.from("pedidos_atualizacao").select("cliente_id,status,mensagem,atualizado_em")
      .eq("automatico", true).in("status", ["feito", "erro"]).gt("atualizado_em", desde).order("atualizado_em");
    if (!peds?.length) return { ok: true, pronto: true, n: 0 };
    const ids = [...new Set(peds.map(p => p.cliente_id))];
    const { data: clis } = await sb.from("declaracao_clientes").select("id,nome").in("id", ids);
    const { data: procs } = await sb.from("processos_pf").select("cliente_id,servico,status,descricao").in("cliente_id", ids);
    const nome = id => (clis || []).find(c => c.id === id)?.nome || "Cliente";
    const curto = s => String(s || "").replace(/\s*\([^)]*\)/g, "").replace(/^Emitir |^Solicitar /i, "").slice(0, 45);
    const feitos = [], erros = [];
    for (const id of ids) {
      const ultimo = peds.filter(p => p.cliente_id === id).pop();
      if (ultimo.status === "erro") { erros.push(`${nome(id)} (${ultimo.mensagem || "erro"})`); continue; }
      const dele = (procs || []).filter(p => p.cliente_id === id && p.status && !/rascunho/i.test(p.descricao || ""));
      const st = [...new Set(dele.map(p => `${curto(p.servico)}: ${p.status}`))].slice(0, 3).join("; ");
      feitos.push(`${nome(id)} — ${st || "nenhuma solicitação"}`);
    }
    const { data: { user } } = await sb.auth.getUser();
    const mensagem = `Consultados (${feitos.length}): ${feitos.join(" | ")}` +
      (erros.length ? ` ‖ Não consultados (${erros.length}): ${erros.join(" | ")}` : "");
    const { error } = await sb.from("notifications").insert({
      titulo: `✅ Consulta geral concluída: ${feitos.length} de ${ids.length} clientes`, mensagem,
      created_by: user?.id, target_user_id: user?.id });
    return { ok: !error, pronto: true, n: ids.length };
  },
  // aviso no sino do escritório (dono do cliente), ex.: conta gov com verificação em duas etapas na consulta geral
  avisarEscritorio: async (clienteId, titulo, mensagem) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { data: c } = await sb.from("declaracao_clientes").select("owner_id").eq("id", clienteId).maybeSingle();
    if (!c?.owner_id) return { ok: false };
    const { error } = await sb.from("notifications").insert({ titulo, mensagem, created_by: c.owner_id, target_user_id: c.owner_id });
    return { ok: !error };
  },
  // Consulta geral (2026-11-27): um pedido "automatico" para cada cliente com processo em andamento (não deferido,
  // indeferido, cancelado ou arquivado; rascunho não conta) e com login gov no cadastro. Pula quem já tem pedido na fila
  // e, com soUmaVezHoje, quem já foi consultado hoje. A mesma regra está no botão de Clientes Armas (Declaracoes.tsx).
  criarConsultaGeral: async (soUmaVezHoje) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const FINAL = /^(deferid|indeferid|cancelad|arquivad|conclu|finalizad|encerrad|desistid)/i;
    const { data: procs, error } = await sb.from("processos_pf").select("cliente_id,status,descricao,consultado_em");
    if (error) return { ok: false, erro: error.message };
    const andamento = new Set((procs || [])
      .filter(p => p.status && !FINAL.test(String(p.status).trim()) && !/rascunho/i.test(p.descricao || ""))
      .map(p => p.cliente_id));
    if (soUmaVezHoje) {
      const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
      for (const p of procs || []) if (p.consultado_em && new Date(p.consultado_em) >= hoje) andamento.delete(p.cliente_id);
    }
    const { data: fila } = await sb.from("pedidos_atualizacao").select("cliente_id").in("status", ["pendente", "rodando"]);
    for (const f of fila || []) andamento.delete(f.cliente_id);
    if (!andamento.size) return { ok: true, n: 0 };
    const { data: clis } = await sb.from("declaracao_clientes").select("id,cpf,senha_gov").in("id", [...andamento]);
    const com = (clis || []).filter(c => c.cpf && c.senha_gov).map(c => ({ cliente_id: c.id, automatico: true }));
    if (!com.length) return { ok: true, n: 0 };
    const { error: e2 } = await sb.from("pedidos_atualizacao").insert(com);
    return e2 ? { ok: false, erro: e2.message } : { ok: true, n: com.length };
  },
  fecharPedido: async (id, status, mensagem) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { error } = await sb.from("pedidos_atualizacao")
      .update({ status, mensagem: mensagem || "", atualizado_em: new Date().toISOString() }).eq("id", id);
    return { ok: !error };
  },
  // "Passarinho ligada" (tabela passarinho_sinal): a página do cliente sabe na hora se o computador está ligado
  // 2026-11-28: também passarinho_computadores (nome do computador e se atende a fila), para o site mostrar ao lado do
  // sino qual computador faz as consultas. Só quem atende grava o passarinho_sinal.
  sinalPassarinho: async (maquina, nome, atende, versao) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const agora = new Date().toISOString();
    // 2026-11-28: no notebook cada atualização (zip extraído numa pasta nova = extensão nova, memória zerada) virava um
    // "computador" novo. A identidade e o nome agora ficam também no site, neste navegador, que não muda com a extensão.
    try {
      const salvo = localStorage.getItem("passarinhoMaquina");
      if (salvo) maquina = salvo; else if (maquina) localStorage.setItem("passarinhoMaquina", maquina);
      if (nome) localStorage.setItem("passarinhoNomePc", nome); else nome = localStorage.getItem("passarinhoNomePc") || "";
    } catch (_) {}
    if (maquina) await sb.from("passarinho_computadores")
      .upsert({ maquina, nome: String(nome || "").slice(0, 40), atende: atende !== false, versao: versao || "", visto_em: agora });
    if (atende === false) return { ok: true };
    const { error } = await sb.from("passarinho_sinal").upsert({ id: 1, visto_em: agora });
    return { ok: !error };
  },
  // clientes esperando atualização (pedidos guardados): o quadro da PF avisa quem está esperando
  pedidosPendentes: async () => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const desde = new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString();
    const { data, error } = await sb.from("pedidos_atualizacao").select("cliente_id,pedido_em,automatico,declaracao_clientes(nome)")
      .in("status", ["pendente", "rodando"]).gt("pedido_em", desde).order("pedido_em");
    if (error) return { ok: false };
    return { ok: true, pedidos: (data || []).map(p => ({ clienteId: p.cliente_id, nome: p.declaracao_clientes?.nome || "",
      automatico: !!p.automatico })) };
  },
  // a lista do cliente foi lida e gravada na aba do próprio usuário: os pedidos dele em espera ficam como feitos
  concluirPedidosDoCliente: async (clienteId) => {
    const sb = window.__passarinho_supabase;
    if (!sb) return { ok: false };
    const { error } = await sb.from("pedidos_atualizacao")
      .update({ status: "feito", mensagem: "lido pelo escritório", atualizado_em: new Date().toISOString() })
      .eq("cliente_id", clienteId).eq("status", "pendente");
    return { ok: !error };
  },
  // Conferência com o Portal PF (2026-11-25): pinta os campos do cadastro aberto em Clientes Armas — verde = igual ao
  // Portal PF, vermelho = diferente. Só se o cadastro aberto for do mesmo cliente (nome). res = { campo: true/false }
  marcarConferencia: (nome, res) => {
    const n = t => String(t || "").replace(/\([^)]*\)/g, " ").normalize("NFD").replace(/[̀-ͯ]/g, "")
      .toLowerCase().replace(/[º°]/g, "o").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
    const ROTULO = { "nome completo": "nome", "cpf": "cpf", "rg": "rg", "orgao emissor rg": "orgao",
      "data de expedicao rg": "expedicao", "data de nascimento": "nasc", "genero": "genero", "nome da mae": "mae",
      "nome do pai": "pai", "cep": "cep", "endereco": "endereco", "no": "numero", "complemento": "complemento",
      "bairro": "bairro", "cidade": "cidade", "estado": "estado", "local de nascimento": "localnasc",
      "uf nascimento": "ufnasc", "profissao": "profissao", "telefone": "telefone", "email": "email", "e mail": "email" };
    let marcados = 0;
    for (const janela of document.querySelectorAll("[role=dialog]")) {
      const labels = [...janela.querySelectorAll("label")];
      const SEL = "input,select,textarea,button[role=combobox]";
      const campoDe = lab => {
        for (let el = lab.nextElementSibling; el; el = el.nextElementSibling) {
          const x = el.matches(SEL) ? el : el.querySelector(SEL);
          if (x) return x;
        }
        return lab.parentElement?.querySelector(SEL) || null;
      };
      const labNome = labels.find(l => n(l.textContent) === "nome completo");
      const inNome = labNome && campoDe(labNome);
      if (!inNome || n(inNome.value) !== n(nome)) continue; // cadastro de outro cliente (ou fechado)
      for (const lab of labels) {
        const campo = ROTULO[n(lab.textContent)];
        const el = campo && campoDe(lab);
        if (!el) continue;
        if (!(campo in res)) {
          if (el.dataset.passarinhoConf) { el.style.removeProperty("color"); el.style.removeProperty("border-color"); delete el.dataset.passarinhoConf; el.title = ""; }
          continue;
        }
        const cor = res[campo] ? "#22c55e" : "#ef4444";
        el.style.setProperty("color", cor, "important");
        el.style.setProperty("border-color", cor, "important");
        el.dataset.passarinhoConf = "1";
        el.title = res[campo] ? "✓ Igual ao Portal PF" : "✗ Diferente do Portal PF";
        marcados++;
      }
    }
    return { ok: marcados > 0, marcados };
  },
};
