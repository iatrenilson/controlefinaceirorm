// Consultas ao sistema RW com nome (as mesmas do menu): o background só roda estas, nunca código vindo de mensagem
importScripts("site-funcs.js");
importScripts("certidoes.js");

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "ping") {
    sendResponse({ ok: true });
  } else if (msg.action === "minhaAba") {
    // o menu do Portal PF / SisGCorp (quadro dentro da página) pergunta em qual aba ele está
    sendResponse({ tabId: _sender.tab?.id ?? null });
  } else if (msg.action === "rodarNoSite") {
    // Menu numa aba ANÔNIMA e sistema RW na janela normal: o Chrome não deixa o menu rodar nada na aba normal
    // ("No tab with id"); o background roda no perfil normal e pode. Só funções de site-funcs.js, pelo nome, e só em aba
    // do próprio sistema RW.
    (async () => {
      try {
        // credGov (senha gov) nunca sai por mensagem: só o próprio background usa, no login do gov.br
        const func = msg.nome === "credGov" ? null : SITE_FUNCS[msg.nome];
        const aba = await chrome.tabs.get(msg.tabId);
        if (!func || !/^https:\/\/(rwinvestimentos\.com\.br|iatrenilson\.github\.io)\//.test(aba?.url || ""))
          return sendResponse({ ok: false, error: "consulta ou aba não permitida" });
        const r = await chrome.scripting.executeScript({ target: { tabId: msg.tabId }, world: "MAIN", func, args: msg.args || [] });
        sendResponse({ ok: true, result: r?.[0]?.result });
      } catch (e) { sendResponse({ ok: false, error: String(e?.message || e) }); }
    })();
  } else if (msg.action === "sairGov") {
    // clicou em "Sair" no Portal PF / Sinarm CAC: sai do gov.br pela saída oficial dele, apaga a sessão da PF do navegador
    // desta aba e volta para entrar
    (async () => {
      const tab = _sender.tab;
      await limparSessaoGov(tab);
      if (tab?.id) { await chrome.tabs.update(tab.id, { url: SAIR_GOVBR }).catch(() => {}); await new Promise(r => setTimeout(r, 3000)); }
      await limparSessaoGov(tab); // o "Sair" do site pode ter gravado algo no meio
      if (tab?.id) chrome.tabs.update(tab.id, { url: /servicos.pf.gov.br/.test(tab.url || "")
        ? "https://servicos.pf.gov.br/sisgcorp-cliente-web-externo/" : "https://portal.pf.gov.br/portal-web-externo/" }).catch(() => {});
      sendResponse({ ok: true });
    })();
  } else if (msg.action === "loginPfCliente") {
    // botão "Login PF" do cartão do cliente no sistema RW (site-ponte.js): abre o Portal PF na janela ANÔNIMA (onde o
    // usuário trabalha; cria uma se não houver), sai da conta que estiver lá (o "fantasma"), e o login gov do cliente
    // é feito sozinho (loginGov) com a autorização da PF (consentirGov)
    (async () => {
      try {
        if (!/^https:\/\/(rwinvestimentos\.com\.br|iatrenilson\.github\.io)\//.test(_sender.tab?.url || ""))
          return sendResponse({ ok: false, erro: "página não permitida" });
        if ((await chrome.storage.local.get(["passarinhoPausado"])).passarinhoPausado)
          return sendResponse({ ok: false, erro: "A Passarinho está pausada." });
        let win = (await chrome.windows.getAll({ windowTypes: ["normal"] })).find(w => w.incognito);
        // abas do cliente anterior (Portal PF / Sinarm / gov.br) na mesma sessão: o portal delas renova a sessão sozinho e
        // derrubava a conta nova ("faz login e sai", 2026-11-27). Fecha antes; com preenchimento rodando, não mexe e avisa.
        const antigas = (await chrome.tabs.query({ url: SITES_GOV })).filter(t => t.incognito === !!win);
        for (const t of antigas) {
          const rodando = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN",
            func: () => !!window.__passarinho_rodando }).then(r => r?.[0]?.result).catch(() => false);
          if (rodando) return sendResponse({ ok: false, erro: "tem um preenchimento da Passarinho rodando em outra aba do Portal PF. Termine ou pare antes de trocar de cliente." });
        }
        // abre a guia nova ANTES de fechar as antigas: se elas eram as únicas da janela anônima, a janela fecharia junto
        // e a guia nova não teria onde abrir ("No window with id", 2026-11-27)
        let tab = win ? await chrome.tabs.create({ windowId: win.id, url: SAIR_GOVBR, active: true }).catch(() => null) : null;
        if (!tab) {
          try { win = await chrome.windows.create({ incognito: true, url: SAIR_GOVBR }); }
          catch (_) { win = await chrome.windows.create({ url: SAIR_GOVBR }); } // anônima não permitida: janela normal
          tab = win.tabs?.[0];
        }
        if (!tab?.id) return sendResponse({ ok: false, erro: "não consegui abrir a aba" });
        if (antigas.length) await chrome.tabs.remove(antigas.map(t => t.id)).catch(() => {});
        chrome.windows.update(win.id, { focused: true }).catch(() => {});
        await limparSessaoGov(tab);
        await chrome.storage.local.set({ loginGov: { clienteId: msg.clienteId, tabId: tab.id, em: Date.now() },
          consentirGov: { tabId: tab.id, em: Date.now() } });
        sendResponse({ ok: true });
        await new Promise(r => setTimeout(r, 3000));
        await limparSessaoGov(tab);
        await chrome.tabs.update(tab.id, { url: "https://portal.pf.gov.br/portal-web-externo/#/solicitacoes" }).catch(() => {});
        // Portal PF sem nenhuma solicitação do cliente: a mesma guia vai para o Sinarm CAC, já logado (o usuário pediu,
        // 2026-11-27). Só se a conta aberta for a do cliente; olha por até 3 minutos (o login pode pedir código)
        const nome = (await rodarNoSistema("nomeCliente", [msg.clienteId]))?.nome || "";
        const fim = Date.now() + 3 * 60 * 1000;
        while (nome && Date.now() < fim) {
          await new Promise(r => setTimeout(r, 2500));
          const est = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: lerPortalParaPedido }).catch(() => null))?.[0]?.result;
          if (!est) { if (!(await chrome.tabs.get(tab.id).catch(() => null))) break; continue; } // guia fechada
          if (est.host !== "portal.pf.gov.br" || !est.nome || !est.naLista) continue;
          if (nomeLimpo(est.nome) !== nomeLimpo(nome)) break;
          if (est.linhas.length) break; // tem solicitação no Portal PF: fica nele
          if (est.vazia) {
            await chrome.storage.local.set({ loginGov: { clienteId: msg.clienteId, tabId: tab.id, em: Date.now() }, consentirGov: { tabId: tab.id, em: Date.now() } });
            await chrome.tabs.update(tab.id, { url: "https://servicos.pf.gov.br/sisgcorp-cliente-web-externo/#/listar-processos" }).catch(() => {});
            // depois do login ele cai na Tela Inicial: vai à lista pelo menu
            const fimS = Date.now() + 2 * 60 * 1000;
            let tentou = 0;
            while (Date.now() < fimS) {
              await new Promise(r => setTimeout(r, 2500));
              const s = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: lerSinarmParaPedido }).catch(() => null))?.[0]?.result;
              if (!s) { if (!(await chrome.tabs.get(tab.id).catch(() => null))) break; continue; }
              if (s.naLista) break;
              if (s.host === "servicos.pf.gov.br" && ++tentou % 3 === 1)
                await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: irParaListaSinarm }).catch(() => {});
            }
            break;
          }
        }
      } catch (e) { try { sendResponse({ ok: false, erro: String(e?.message || e).slice(0, 120) }); } catch (_) {} }
    })();
  } else if (msg.action === "emitirCertidoes") {
    // "Emitir todas" / uma certidão (2026-11-23): roda aqui para terminar mesmo se a janelinha da extensão fechar
    emitirCertidoes(msg.cliente || {}, msg.quais || [])
      .then(resultados => sendResponse({ ok: true, resultados }))
      .catch(e => sendResponse({ ok: false, error: String(e?.message || e) }));
  } else if (msg.action === "abrirSistema") {
    // abre o sistema RW numa aba de fundo da janela normal (onde o login fica guardado) e espera ficar pronto
    (async () => {
      try {
        const url = "https://rwinvestimentos.com.br/declaracoes";
        const normal = (await chrome.windows.getAll({ windowTypes: ["normal"] })).find(w => !w.incognito);
        const tab = normal
          ? await chrome.tabs.create({ windowId: normal.id, url, active: false })
          : (await chrome.windows.create({ url, incognito: false, focused: false, state: "minimized" })).tabs?.[0];
        if (!tab?.id) return sendResponse({ ok: false });
        const fim = Date.now() + 20000;
        while (Date.now() < fim) {
          await new Promise(r => setTimeout(r, 700));
          try {
            const pronto = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN",
              func: () => !!window.__passarinho_supabase }))?.[0]?.result;
            if (pronto) { await new Promise(r => setTimeout(r, 800)); return sendResponse({ ok: true, tabId: tab.id }); }
          } catch (_) {}
        }
        sendResponse({ ok: false });
      } catch (e) { sendResponse({ ok: false, error: String(e?.message || e) }); }
    })();
  } else {
    // mensagem para outra parte da extensão (ex.: "menuExecutar", que o menu da aba da PF responde): o background não
    // responde, senão a resposta dele chegaria antes e o popup acharia que deu errado
    return false;
  }
  return true;
});

// Sites com o menu fixo na página (painel.js): Portal PF e SisGCorp (Exército)
const SITES_MENU = ["https://portal.pf.gov.br/*", "https://sisgcorp.eb.mil.br/*", "https://servicos.pf.gov.br/*"];

// Extensão recarregada (sozinha pelo menu, ou em chrome://extensions): as abas desses sites já abertas ficariam com o
// menu antigo até um F5; põe o menu novo nelas (o painel.js novo esconde o antigo)
chrome.runtime.onInstalled.addListener(async () => {
  try {
    const abas = await chrome.tabs.query({ url: SITES_MENU });
    for (const aba of abas) chrome.scripting.executeScript({ target: { tabId: aba.id }, files: ["painel.js"] }).catch(() => {});
    // sistema RW aberto: ponte nova do botão "Login PF" (sem precisar de F5)
    for (const aba of await chrome.tabs.query({ url: SITES_SISTEMA }))
      chrome.scripting.executeScript({ target: { tabId: aba.id }, files: ["site-ponte.js"] }).catch(() => {});
  } catch (_) {}
});

// Nesses sites já existe o menu fixo na página (painel.js): clicar no ícone da extensão lá não abre o popup,
// só mostra o menu fixo (põe se faltar e abre se estiver recolhido). Nos outros sites o popup continua igual.
const ehSiteMenu = url => /^https:\/\/(portal\.pf\.gov\.br|sisgcorp\.eb\.mil\.br|servicos\.pf\.gov\.br)\//.test(url || "");
// 2026-11-22: o usuário pediu para fazer tudo pelo popup do ícone (cliente, processo, certidões), como em outra
// extensão que ele viu. O ícone abre o popup em TODOS os sites; o menu da página fica recolhido e só abre quando
// precisa (Continuar, aviso, erro). O onClicked abaixo deixa de ser chamado (com popup, o Chrome não o dispara).
function ajustarPopup(tabId, url) {
  chrome.action.setPopup({ tabId, popup: "popup.html" }).catch(() => {});
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => { if (info.url || info.status === "loading") ajustarPopup(tabId, tab.url); });
async function ajustarTodas() {
  try { for (const aba of await chrome.tabs.query({})) ajustarPopup(aba.id, aba.url); } catch (_) {}
}
chrome.runtime.onInstalled.addListener(ajustarTodas);
chrome.runtime.onStartup.addListener(ajustarTodas);
chrome.action.onClicked.addListener(async tab => {
  if (!ehSiteMenu(tab.url)) return;
  await chrome.storage.local.set({ menuRecolhido: false }).catch(() => {});
  chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["painel.js"] }).catch(() => {});
});

// ON / OFF no ícone (2026-11-22, como na extensão que o usuário viu): mostra se a Passarinho está ligada ou pausada
// (botão Pausar / Retomar do popup, chrome.storage passarinhoPausado)
function mostrarEstadoNoIcone(pausado) {
  // ligada: só o logo, sem etiqueta (o usuário achou o "ON" feio, 2026-11-26); pausada continua com "OFF"
  chrome.action.setBadgeText({ text: pausado ? "OFF" : "" }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: pausado ? "#6b6b6b" : "#d4a730" }).catch(() => {});
  chrome.action.setBadgeTextColor?.({ color: pausado ? "#ffffff" : "#1a1714" })?.catch?.(() => {});
  chrome.action.setTitle({ title: pausado ? "Passarinho pausada (clique para retomar)" : "Passarinho Assessoria" }).catch(() => {});
}
const conferirEstadoIcone = () => chrome.storage.local.get(["passarinhoPausado"]).then(r => mostrarEstadoNoIcone(!!r.passarinhoPausado)).catch(() => {});
chrome.runtime.onInstalled.addListener(conferirEstadoIcone);
chrome.runtime.onStartup.addListener(conferirEstadoIcone);
conferirEstadoIcone();
chrome.storage.onChanged.addListener((mud, area) => {
  if (area === "local" && mud.passarinhoPausado) mostrarEstadoNoIcone(!!mud.passarinhoPausado.newValue);
});

// ── Login no gov.br sozinho (2026-11-22, o usuário pediu) ──
// O popup abre o Portal PF / Sinarm CAC / SisGCorp numa aba e guarda { clienteId, tabId, em } em loginGov. Quando ESSA
// aba chega na tela de login do gov.br (sso.acesso.gov.br) em até 10 minutos, o background busca no sistema o CPF e a
// Senha GOV.br do cliente e preenche: CPF → Continuar → senha → Entrar. O captcha e o código de verificação ficam com o
// usuário. A senha não é guardada na extensão nem escrita em lugar nenhum. Pausada, não faz nada.
const SITES_SISTEMA = ["https://rwinvestimentos.com.br/*", "https://iatrenilson.github.io/*"];
async function credenciaisGov(clienteId) {
  const abas = (await chrome.tabs.query({ url: SITES_SISTEMA })).sort((a, b) => Number(a.incognito) - Number(b.incognito));
  for (const aba of abas) {
    try {
      const r = (await chrome.scripting.executeScript({ target: { tabId: aba.id }, world: "MAIN", func: SITE_FUNCS.credGov, args: [clienteId] }))?.[0]?.result;
      if (r?.ok) return r;
    } catch (_) {}
  }
  return null;
}
// roda na tela do gov.br (mundo isolado da extensão, fora do alcance dos scripts da página)
async function preencherLoginGov(cpf, senha) {
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const visivel = el => !!el && el.getClientRects().length > 0;
  const escrever = (el, v) => {
    el.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const fim = Date.now() + 10000;
  while (Date.now() < fim) {
    const campoSenha = [...document.querySelectorAll("input[type=password]")].find(visivel);
    if (campoSenha) {
      if (!senha) return "sem-senha";
      if (!campoSenha.value) escrever(campoSenha, senha);
      await esperar(300);
      const entrar = document.querySelector("#submit-button") ||
        [...document.querySelectorAll("button")].find(b => visivel(b) && /^\s*entrar\s*$/i.test(b.textContent || ""));
      if (entrar && !entrar.disabled) entrar.click();
      return "senha";
    }
    const campoCpf = document.querySelector("#accountId");
    if (visivel(campoCpf) && cpf) {
      const so = cpf.replace(/\D/g, "");
      if (campoCpf.value.replace(/\D/g, "") !== so) escrever(campoCpf, so);
      await esperar(300);
      document.querySelector("#enter-account-id")?.click();
      // a tela da senha pode vir na mesma página: continua olhando
      await esperar(1500);
      continue;
    }
    await esperar(400);
  }
  return "nada";
}
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== "complete" || !/^https:\/\/sso\.acesso\.gov\.br\//.test(tab.url || "")) return;
  try {
    // dois logins podem estar em andamento ao mesmo tempo (2026-11-27): o do usuário (loginGov: botão "Login PF", menu)
    // e o da fila de consultas (loginGovPedido, guia de fundo da janela normal); vale o da guia que carregou
    const st = await chrome.storage.local.get(["loginGov", "loginGovPedido", "passarinhoPausado"]);
    if (st.passarinhoPausado) return;
    const chave = st.loginGovPedido?.tabId === tabId ? "loginGovPedido" : "loginGov";
    const loginGov = st[chave];
    if (!loginGov || loginGov.tabId !== tabId) return;
    if (Date.now() - (loginGov.em || 0) > 10 * 60 * 1000) { await chrome.storage.local.remove([chave]); return; }
    // 2ª vez só depois de 15 s da 1ª: o gov.br às vezes volta para a tela de login logo depois de sair da conta anterior
    // (o usuário tinha de clicar 2, 3 vezes, 2026-11-27). No máximo 2 vezes, para não errar a senha seguidas vezes.
    if (loginGov.ultima && Date.now() - loginGov.ultima < 15000) return;
    const cred = await credenciaisGov(loginGov.clienteId);
    if (!cred?.cpf) return;
    const r = (await chrome.scripting.executeScript({ target: { tabId }, func: preencherLoginGov, args: [cred.cpf, cred.senha] }))?.[0]?.result;
    if (r === "sem-senha" || (r === "senha" && (loginGov.vezes || 0) >= 1)) await chrome.storage.local.remove([chave]);
    else if (r === "senha") await chrome.storage.local.set({ [chave]: { ...loginGov, vezes: (loginGov.vezes || 0) + 1, ultima: Date.now() } });
  } catch (_) {}
});

// ── Sessão do gov.br / PF: o "Sair" do Portal PF não sai de verdade (entra de novo na mesma conta). Sai do gov.br pela
// saída oficial dele (SAIR_GOVBR) e apaga os cookies e dados da PF (só do navegador da aba: normal ou anônimo).
// Os cookies do gov.br NÃO são apagados (2026-11-25): sem eles o gov.br não reconhece o computador e pede confirmação.
const SAIR_GOVBR = "https://sso.acesso.gov.br/logout";
// dpf.gov.br: o login da PF (o gov.br volta para "client_id=servicos.dpf.gov.br") guarda a sessão lá; sem apagar, o portal
// entrava de novo na conta anterior (2026-11-26, Luiz Carlos abria a conta do Luiz Gustavo)
const DOMINIOS_GOV = ["pf.gov.br", "dpf.gov.br"];
async function limparSessaoGov(tab) {
  try {
    let lojas = await chrome.cookies.getAllCookieStores();
    // só o navegador da aba (normal ou anônimo); sem aba ({ incognito: false }), só o normal. Antes, sem aba apagava
    // também o da janela anônima, onde o usuário trabalha
    const normal = l => l.id === "0" || l.id === "firefox-default";
    const daAba = tab?.id != null ? lojas.filter(l => (l.tabIds || []).includes(tab.id) || (tab.cookieStoreId && l.id === tab.cookieStoreId)) : [];
    lojas = daAba.length ? daAba : lojas.filter(l => (tab?.incognito ? !normal(l) : normal(l)));
    // gov.br: só os cookies da sessão (somem ao fechar o navegador); os guardados fazem o gov.br reconhecer o computador
    const alvos = [...DOMINIOS_GOV.map(d => [d, false]), ["acesso.gov.br", true]];
    for (const loja of lojas) for (const [dominio, soSessao] of alvos) {
      const cookies = await chrome.cookies.getAll({ domain: dominio, storeId: loja.id }).catch(() => []);
      for (const c of cookies) {
        if (soSessao && !c.session) continue;
        // 2026-11-26: o "^." sem a barra cortava a 1ª letra ("ortal.pf.gov.br") e nenhum cookie era apagado
        const url = "http" + (c.secure ? "s" : "") + "://" + c.domain.replace(/^\./, "") + c.path;
        await chrome.cookies.remove({ url, name: c.name, storeId: loja.id, ...(c.partitionKey ? { partitionKey: c.partitionKey } : {}) }).catch(() => {});
      }
    }
  } catch (_) {}
  // dados guardados nos sites (token do portal), só do navegador normal: na janela anônima isto não alcança (e apagaria
  // a conta aberta na janela normal), mas fechar a anônima apaga tudo
  if (tab?.incognito) return;
  try {
    const origens = ["https://portal.pf.gov.br", "https://servicos.pf.gov.br"];
    if (typeof browser !== "undefined" && browser.browsingData) {
      await browser.browsingData.remove({ hostnames: origens.map(o => o.replace("https://", "")) }, { localStorage: true });
    } else if (chrome.browsingData) {
      await chrome.browsingData.remove({ origins: origens }, { localStorage: true, indexedDB: true, cacheStorage: true, serviceWorkers: true });
    }
  } catch (_) {}
}

// ── Atualizar o processo a pedido do cliente (2026-11-25, o usuário pediu) ──
// Na Carteira Digital, "Acompanhar processo" cria um pedido (tabela pedidos_atualizacao). A cada 30 s a Passarinho
// confere; com pedido, abre o Portal PF numa guia de fundo da janela normal, o login gov é feito como sempre (loginGov acima), lê
// "Minhas solicitações", grava (salvarProcessos), sai da conta e fecha a guia. Nunca roda com Portal PF / Sinarm /
// gov.br aberto numa janela NORMAL (o login do gov.br vale para ela toda); as anônimas têm sessão própria e não
// atrapalham (o usuário trabalha nelas). Pausada, não faz nada.
// Só grava se a conta aberta for do próprio cliente do pedido. Captcha / código do gov.br: não termina e avisa.
const SITES_GOV = ["https://portal.pf.gov.br/*", "https://servicos.pf.gov.br/*", "https://sso.acesso.gov.br/*"];
let atendendoPedido = false;
async function rodarNoSistema(nome, args = []) {
  const abas = (await chrome.tabs.query({ url: SITES_SISTEMA })).sort((a, b) => Number(a.incognito) - Number(b.incognito));
  for (const aba of abas) {
    try {
      const r = (await chrome.scripting.executeScript({ target: { tabId: aba.id }, world: "MAIN", func: SITE_FUNCS[nome], args }))?.[0]?.result;
      if (r?.ok) return r;
    } catch (_) {}
  }
  return null;
}
// roda na aba do Portal PF: em que ponto está (login, lista lida)
function lerPortalParaPedido() {
  const texto = el => {
    if (!el) return "";
    const c = el.cloneNode(true);
    c.querySelectorAll(".p-column-title").forEach(x => x.remove());
    return c.textContent.replace(/\s+/g, " ").trim();
  };
  const nome = (document.querySelector(".user-info-name")?.textContent || "").trim();
  const naLista = location.hostname === "portal.pf.gov.br" && /^#\/solicitacoes\/?(\?.*)?$/.test(location.hash);
  const trs = [...document.querySelectorAll("app-solicitacoes-table table tbody tr, app-portal-table table tbody tr")];
  const linhas = trs.map(tr => {
    const td = tr.querySelectorAll("td");
    return { servico: texto(td[0]?.querySelector(".solicitacao-titulo")) || texto(td[0]),
      descricao: texto(td[0]?.querySelector(".solicitacao-descricao")),
      protocolo: texto(td[1]), data: texto(td[2]), status: texto(td[3]) };
  }).filter(l => /\d{4}-\d+/.test(l.protocolo));
  const vazia = trs.some(tr => /nenhum resultado/i.test(tr.textContent || ""));
  // na tela do gov.br: o que ela está pedindo (para anotar no pedido)
  let aviso = "";
  if (location.hostname === "sso.acesso.gov.br") {
    const vis = el => el.getClientRects().length > 0;
    const el = [...document.querySelectorAll(".alert, .br-message, [role=alert], .error, h1, h2, h3, legend, label")]
      .find(e => vis(e) && (e.textContent || "").trim().length > 3);
    aviso = (el?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 90);
    if (document.querySelector("iframe[src*='captcha'], .h-captcha, #h-captcha")) aviso = "captcha " + aviso;
  }
  // gov.br pedindo o código da verificação em duas etapas (do app gov.br / SMS / e-mail do cliente)
  const duasEtapas = location.hostname === "sso.acesso.gov.br" &&
    /duas etapas|2 etapas|dois fatores|2 fatores|c[oó]digo de (acesso|verifica[cç][aã]o|seguran[cç]a)|informe o c[oó]digo|digite o c[oó]digo/i
      .test((document.body?.innerText || "").replace(/\s+/g, " "));
  return { host: location.hostname, nome, naLista, linhas, vazia, aviso, duasEtapas };
}
// roda na aba do Sinarm CAC: lista "Listar Processo" (mesmas colunas que o quadro da PF lê em menu-painel.js)
function lerSinarmParaPedido() {
  const texto = el => {
    if (!el) return "";
    const c = el.cloneNode(true);
    c.querySelectorAll(".p-column-title").forEach(x => x.remove());
    return c.textContent.replace(/\s+/g, " ").trim();
  };
  const naLista = location.hostname === "servicos.pf.gov.br" && /^#\/listar-processos/.test(location.hash);
  const linhas = !naLista ? [] : [...document.querySelectorAll("table tbody tr")].map(tr => {
    const td = tr.querySelectorAll("td");
    return { origem: "sinarm", protocolo: texto(td[0]), data: texto(td[1]), servico: texto(td[2]), status: texto(td[3]),
      motivo: texto(td[4]), gru: texto(td[6]), posicao_fila: texto(td[7]), descricao: "" };
  }).filter(l => /\d{4,}/.test(l.protocolo));
  return { host: location.hostname, naLista, linhas, nome: (document.querySelector(".profile-name")?.textContent || "").trim() };
}
// roda na aba do Sinarm CAC: depois do login ele cai na "Tela Inicial" (o endereço da lista se perde no gov.br); vai à
// lista pelo menu, como o preenchimento da GT faz: Solicitação de Serviço › Pessoa Física › Listar Processo (2026-11-27)
async function irParaListaSinarm() {
  const naLista = () => /listar-processo/.test(location.hash);
  if (naLista()) return "ja";
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const vis = el => !!el && el.getClientRects().length > 0;
  // sem acento e sem o que está entre parênteses: o menu é "Pessoa Física (PF)" (2026-11-27: procurava só "Pessoa Física",
  // não achava e o atalho de endereço levava ao "Preencher Formulário")
  const norm = s => String(s || "").replace(/\([^)]*\)/g, " ").normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/\s+/g, " ").trim().toLowerCase();
  const porTexto = lista => {
    const alvos = lista.map(norm);
    return [...document.querySelectorAll("a,button,span,li,div,p")]
      .find(el => vis(el) && el.children.length <= 2 && alvos.includes(norm(el.textContent)));
  };
  const ate = async (f, ms) => { const fim = Date.now() + ms; while (Date.now() < fim) { const r = f(); if (r) return r; await esperar(250); } return null; };
  const LISTAR = ["Listar Processos", "Listar Processo", "Lista de Processos", "Lista de Processo"];
  // "Listar Processos" já à mostra (menu aberto): clica direto; senão abre o menu passo a passo
  let item = porTexto(LISTAR);
  if (!item) {
    for (const txt of [["Solicitação de Serviço", "Solicitações"], ["Pessoa Física"]]) {
      if (porTexto(LISTAR)) break;
      const el = await ate(() => porTexto(txt), 4000);
      if (!el) break;
      el.click();
      await esperar(900);
    }
    item = await ate(() => porTexto(LISTAR), 4000);
  }
  if (item) item.click();
  await ate(naLista, 5000);
  return naLista() ? "ok" : "nao";
}
// depois do Portal PF, a mesma guia vai ao Sinarm CAC (o login gov é o mesmo) e lê a lista; não deu em 90 s, segue sem
// ele (o Portal PF já foi gravado)
async function consultarSinarmNoPedido(tabId, pedido, anotar, esperar) {
  try {
    await chrome.storage.local.set({ loginGovPedido: { clienteId: pedido.clienteId, tabId, em: Date.now() }, consentirGovPedido: { tabId, em: Date.now() } });
    await chrome.tabs.update(tabId, { url: "https://servicos.pf.gov.br/sisgcorp-cliente-web-externo/#/listar-processos" });
    await anotar("sinarm");
    const fim = Date.now() + 90 * 1000;
    let tentativasUrl = 0;
    while (Date.now() < fim) {
      await esperar(2500);
      const est = (await chrome.scripting.executeScript({ target: { tabId }, func: lerSinarmParaPedido }).catch(() => null))?.[0]?.result;
      if (!est || est.host !== "servicos.pf.gov.br") continue;
      // conta de outra pessoa no Sinarm: não grava nada
      if (est.nome && nomeLimpo(est.nome) !== nomeLimpo(pedido.nome)) { await anotar("sinarm: conta de outra pessoa"); return; }
      if (!est.naLista) {
        if (++tentativasUrl % 3 === 1)
          await chrome.scripting.executeScript({ target: { tabId }, func: irParaListaSinarm }).catch(() => {});
        continue;
      }
      if (est.linhas.length) { await rodarNoSistema("salvarProcessos", [pedido.clienteId, est.linhas]); await anotar("sinarm lido"); return; }
    }
    await anotar("sinarm: não abriu a lista");
  } catch (_) {}
}
function sairDoPortal() {
  const b = [...document.querySelectorAll("button,a")].find(el => /^\s*sair do sistema\s*$/i.test(el.textContent || ""))
    || [...document.querySelectorAll("button,a")].find(el => /^\s*sair\s*$/i.test(el.textContent || ""));
  if (b) b.click();
  return !!b;
}
const nomeLimpo = t => String(t || "").replace(/\([^)]*\)/g, " ").normalize("NFD").replace(/[̀-ͯ]/g, "")
  .toLowerCase().replace(/\s+/g, " ").trim();
async function atenderPedidoCliente() {
  if (atendendoPedido) return;
  const { passarinhoPausado, loginGov, pedidoAtual, filaDesligada } = await chrome.storage.local.get(["passarinhoPausado", "loginGov", "pedidoAtual", "filaDesligada"]);
  // pedido que ficou pela metade (o Chrome encerrou o background no meio, ex.: extensão atualizada ao abrir o Chrome):
  // fecha a janela dele e o pedido VOLTA PARA A FILA para ser consultado de novo (o usuário pediu, 2026-11-27: "quando
  // acontecer isso tem que consultar"). Só na 3ª interrupção do mesmo pedido vira erro.
  if (pedidoAtual) {
    if (pedidoAtual.janelaId) await chrome.windows.remove(pedidoAtual.janelaId).catch(() => {});
    else if (pedidoAtual.tabId) await chrome.tabs.remove(pedidoAtual.tabId).catch(() => {});
    const { interrupcoes = {} } = await chrome.storage.local.get(["interrupcoes"]);
    const vezes = (interrupcoes[pedidoAtual.id] || 0) + 1;
    const fila = vezes < 3;
    await rodarNoSistema("fecharPedido", [pedidoAtual.id, fila ? "pendente" : "erro",
      (fila ? "voltou para a fila (interrompido: " : "interrompido 3 vezes: ") + (pedidoAtual.passo || "") + (fila ? ")" : "")]);
    // guarda só os de agora (não cresce para sempre)
    await chrome.storage.local.set({ interrupcoes: { [pedidoAtual.id]: vezes } });
    await chrome.storage.local.remove(["pedidoAtual", "loginGovPedido", "consentirGovPedido"]);
    return;
  }
  if (passarinhoPausado) return;
  // "Atender a fila de consultas neste computador" desligado no popup: outro computador (o notebook) atende (2026-11-27)
  if (filaDesligada) return;
  // login gov do usuário em andamento numa guia NORMAL (mesma sessão da fila): espera. Na janela anônima não atrapalha
  // (2026-11-27: o "Login PF" da anônima segurava a fila de 24 clientes por 10 minutos)
  if (loginGov && Date.now() - (loginGov.em || 0) < 10 * 60 * 1000) {
    const aba = await chrome.tabs.get(loginGov.tabId).catch(() => null);
    if (aba && !aba.incognito) return;
  }
  // PF / gov.br aberto na janela normal (ex.: o Chrome reabriu as abas de antes): com cliente esperando, a Passarinho
  // fecha essas abas sozinha e atende (o usuário pediu, 2026-11-26). Só não fecha aba com preenchimento rodando.
  const govNormais = (await chrome.tabs.query({ url: SITES_GOV })).filter(t => !t.incognito);
  if (govNormais.length) {
    const esperando = await rodarNoSistema("pedidosPendentes");
    if (!esperando?.pedidos?.length) return;
    for (const t of govNormais) {
      const rodando = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN",
        func: () => !!window.__passarinho_rodando }).then(r => r?.[0]?.result).catch(() => false);
      if (rodando) return;
    }
    await chrome.tabs.remove(govNormais.map(t => t.id)).catch(() => {});
    await new Promise(r => setTimeout(r, 1000));
  }
  atendendoPedido = true;
  let janela = null, pedido = null;
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const fechar = (status, msg) => rodarNoSistema("fecharPedido", [pedido.id, status, msg]);
  try {
    pedido = (await rodarNoSistema("pegarPedido"))?.pedido;
    if (!pedido) return;
    if (!pedido.temLogin) { await fechar("erro", "sem login gov no cadastro"); return; }
    // sem conta de ninguém guardada (só na janela normal): sai do gov.br e da PF e depois abre a lista
    await limparSessaoGov({ incognito: false });
    // numa GUIA de fundo da janela normal (o usuário pediu, 2026-11-27: "abra em nova guia"); sem janela normal aberta,
    // numa janela minimizada como antes. janela.id só existe quando a janela é da Passarinho (aí ela fecha a janela).
    const normal = (await chrome.windows.getAll({ windowTypes: ["normal"] })).find(w => !w.incognito);
    if (normal) janela = { id: null, tabs: [await chrome.tabs.create({ windowId: normal.id, url: SAIR_GOVBR, active: false })] };
    else janela = await chrome.windows.create({ url: SAIR_GOVBR, incognito: false, focused: false, state: "minimized" });
    const tabId = janela.tabs?.[0]?.id;
    await esperar(3000);
    await chrome.tabs.update(tabId, { url: "https://portal.pf.gov.br/portal-web-externo/#/solicitacoes" });
    await chrome.storage.local.set({ loginGovPedido: { clienteId: pedido.clienteId, tabId, em: Date.now() }, consentirGovPedido: { tabId, em: Date.now() } });
    // cada passo fica anotado no pedido (mensagem), para saber onde parou
    let passoAnotado = "";
    var anotar = async passo => {
      if (passo === passoAnotado) return;
      passoAnotado = passo;
      await chrome.storage.local.set({ pedidoAtual: { id: pedido.id, janelaId: janela.id, tabId, passo } });
      await rodarNoSistema("fecharPedido", [pedido.id, "rodando", passo]);
    };
    await anotar("guia aberta");
    let trocouConta = false, foiParaLista = 0;
    const fim = Date.now() + 3 * 60 * 1000;
    let ultimo = null;
    while (Date.now() < fim) {
      await esperar(2000);
      if ((await chrome.storage.local.get(["passarinhoPausado"])).passarinhoPausado) { await fechar("erro", "pausada"); return; }
      let est = null;
      try { est = (await chrome.scripting.executeScript({ target: { tabId }, func: lerPortalParaPedido }))?.[0]?.result; } catch (_) {}
      if (!est) { await anotar("sem acesso à aba"); continue; }
      ultimo = est;
      await anotar(est.host === "sso.acesso.gov.br" ? "login gov" + (est.aviso ? ": " + est.aviso : "") : est.nome ? (est.naLista ? "lista: " : "conta: ") + est.nome : "abrindo " + est.host);
      // verificação em duas etapas: só o cliente tem o código. Pula na hora para o próximo e avisa o escritório (o usuário
      // pediu, 2026-11-27: "me informar qual conta está com 2 etapas para eu entrar em contato com o cliente")
      if (est.duasEtapas) {
        await fechar("erro", "verificação em duas etapas (o gov.br pede o código do cliente)");
        // o motivo aparece no quadro "Consulta geral" da tela e no resumo do sino (pedido do cliente: no aviso dele no sino)
        return;
      }
      if (est.host !== "portal.pf.gov.br" || !est.nome) continue;
      // conta de outra pessoa aberta (sessão gov que ficou de antes): sai e entra de novo, uma vez
      if (nomeLimpo(est.nome) !== nomeLimpo(pedido.nome)) {
        if (trocouConta) {
          // diagnóstico: quais sites .gov.br ainda guardam cookie no navegador normal (só os nomes, nunca o conteúdo)
          const doms = await chrome.cookies.getAll({ storeId: (await chrome.cookies.getAllCookieStores())
            .find(l => (l.tabIds || []).includes(tabId))?.id || "0" }).catch(() => []);
          const lista = [...new Set(doms.map(c => c.domain.replace(/^\./, "")).filter(d => /gov\.br$/.test(d)))].join(",");
          await fechar("erro", ("conta gov de outra pessoa (" + nomeLimpo(est.nome).split(" ")[0] + "); cookies: " + lista).slice(0, 300));
          return;
        }
        trocouConta = true;
        await limparSessaoGov({ incognito: false });
        await chrome.tabs.update(tabId, { url: SAIR_GOVBR }).catch(() => {});
        await esperar(4000);
        await chrome.storage.local.set({ loginGovPedido: { clienteId: pedido.clienteId, tabId, em: Date.now() }, consentirGovPedido: { tabId, em: Date.now() } });
        await chrome.tabs.update(tabId, { url: "https://portal.pf.gov.br/portal-web-externo/#/solicitacoes" }).catch(() => {});
        continue;
      }
      if (!est.naLista) {
        if (++foiParaLista % 4 === 1) await chrome.tabs.update(tabId, { url: "https://portal.pf.gov.br/portal-web-externo/#/solicitacoes" }).catch(() => {});
        continue;
      }
      if (est.linhas.length || est.vazia) {
        const r = est.linhas.length ? await rodarNoSistema("salvarProcessos", [pedido.clienteId, est.linhas]) : { ok: true };
        if (!r?.ok) { await fechar("erro", "não consegui gravar"); return; }
        // processos do Sinarm CAC (GT etc.) também: senão a data "conferido em" deles ficava a antiga (2026-11-27)
        if (pedido.temSinarm) await consultarSinarmNoPedido(tabId, pedido, anotar, esperar);
        await fechar("feito", est.linhas.length ? "" : "nenhuma solicitação");
        return;
      }
    }
    await fechar("erro", ultimo?.host === "sso.acesso.gov.br" ? "o gov.br pediu confirmação" + (ultimo.aviso ? ": " + ultimo.aviso : "") : "tempo esgotado");
  } catch (e) {
    if (pedido) await fechar("erro", String(e?.message || e).slice(0, 80)).catch(() => {});
  } finally {
    // não deixa a conta do cliente aberta no navegador: sai do gov.br, fecha e apaga a sessão da PF
    if (janela?.tabs?.[0]?.id) { await chrome.tabs.update(janela.tabs[0].id, { url: SAIR_GOVBR }).catch(() => {}); await esperar(3000); }
    if (janela?.id) await chrome.windows.remove(janela.id).catch(() => {});
    else if (janela?.tabs?.[0]?.id) await chrome.tabs.remove(janela.tabs[0].id).catch(() => {});
    if (janela) await limparSessaoGov({ incognito: false });
    if (janela) await chrome.storage.local.remove(["loginGovPedido", "pedidoAtual", "consentirGovPedido"]).catch(() => {});
    atendendoPedido = false;
    // era da consulta geral e a fila acabou: resumo no sino (cada cliente e o status, e os que não deram)
    if (pedido?.automatico) {
      // cada cliente aparece ao vivo no quadro "Consulta geral" do site; no sino só o resumo quando a fila acaba
      // (o usuário pediu, 2026-11-27: a notificação só a da consulta geral)
      try {
        const { resumoGeralDesde } = await chrome.storage.local.get(["resumoGeralDesde"]);
        const desde = resumoGeralDesde || new Date(Date.now() - 12 * 3600 * 1000).toISOString();
        const r = await rodarNoSistema("resumoConsultaGeral", [desde]);
        if (r?.ok && r.pronto && r.n) await chrome.storage.local.set({ resumoGeralDesde: new Date().toISOString() });
      } catch (_) {}
    }
  }
}
chrome.alarms?.create("pedidosCliente", { periodInMinutes: 0.5 });
// a cada 30 s: avisa o sistema que a Passarinho está ligada (pausada não avisa: ela não atende) e atende os pedidos
chrome.alarms?.onAlarm.addListener(async a => {
  if (a.name !== "pedidosCliente") return;
  // versão nova na pasta (Chrome): recarrega sozinha. Antes só o quadro do Portal PF conferia, e sem ele aberto a versão
  // antiga ficava rodando (2026-11-27). Não recarrega no meio de uma consulta; uma tentativa por versão a cada 5 min.
  if (!atendendoPedido && typeof browser === "undefined") {
    try {
      const naPasta = (await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json()).version;
      if (naPasta && naPasta !== chrome.runtime.getManifest().version) {
        const { recarga } = await chrome.storage.local.get(["recarga"]);
        if (!(recarga && recarga.versao === naPasta && Date.now() - recarga.em < 5 * 60 * 1000)) {
          await chrome.storage.local.set({ recarga: { versao: naPasta, em: Date.now() } });
          chrome.runtime.reload();
          return;
        }
      }
    } catch (_) {}
  }
  // o sinal "Passarinho ligada" é o que diz ao celular do cliente que a consulta sai na hora: só manda quem atende a fila
  // 2026-11-28: manda também o nome deste computador (popup) e se ele atende, para o site mostrar quem faz as consultas
  const st = await chrome.storage.local.get(["passarinhoPausado", "filaDesligada", "maquinaId", "nomeComputador"]).catch(() => ({}));
  let maquina = st.maquinaId;
  if (!maquina) { maquina = crypto.randomUUID(); await chrome.storage.local.set({ maquinaId: maquina }).catch(() => {}); }
  rodarNoSistema("sinalPassarinho", [maquina, st.nomeComputador || "", !st.passarinhoPausado && !st.filaDesligada,
    chrome.runtime.getManifest().version]).catch(() => {});
  // (a consulta geral de todos os clientes NÃO é automática: só pelo botão "Consultar todos os processos" de Clientes
  // Armas — o usuário preferiu assim, 2026-11-27. Automático só os pedidos que os clientes deixaram na fila.)
  atenderPedidoCliente();
});

// ── Autorização do gov.br para a PF (2026-11-26, o usuário pediu): na 1ª vez que a conta gov do cliente entra nos
// serviços da PF, o gov.br pergunta "Autorização para compartilhamento de Dados Pessoais — Serviço: Serviços da Polícia
// Federal" (às vezes duas vezes) e o login parava ali. Só nas abas que a Passarinho abriu para o cliente (consentirGov,
// por 10 minutos) e só se o serviço for da Polícia Federal, clica em Autorizar, quantas vezes a tela aparecer.
function autorizarCompartilhamentoPf() {
  const t = (document.body?.innerText || "").replace(/\s+/g, " ");
  if (!/autoriza[cç][aã]o para compartilhamento de dados pessoais/i.test(t)) return "nao";
  if (!/servi[cç]o:\s*servi[cç]os da pol[ií]cia federal/i.test(t)) return "outro-servico";
  const b = [...document.querySelectorAll("button,input[type=submit],a")]
    .find(el => /^\s*autorizar\s*$/i.test(el.textContent || el.value || "") && el.getClientRects().length);
  if (!b) return "sem-botao";
  b.click();
  return "autorizou";
}
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== "complete" || !/^https:\/\/sso\.acesso\.gov\.br\//.test(tab.url || "")) return;
  try {
    const st = await chrome.storage.local.get(["consentirGov", "consentirGovPedido", "passarinhoPausado"]);
    if (st.passarinhoPausado) return;
    const chave = st.consentirGovPedido?.tabId === tabId ? "consentirGovPedido" : "consentirGov"; // fila ou usuário
    const consentirGov = st[chave];
    if (!consentirGov || consentirGov.tabId !== tabId) return;
    if (Date.now() - (consentirGov.em || 0) > 10 * 60 * 1000) { await chrome.storage.local.remove([chave]); return; }
    for (let i = 0; i < 5; i++) { // a tela pode demorar a montar
      const r = (await chrome.scripting.executeScript({ target: { tabId }, func: autorizarCompartilhamentoPf }))?.[0]?.result;
      if (r !== "sem-botao" && r !== "nao") return;
      await new Promise(ok => setTimeout(ok, 1000));
    }
  } catch (_) {}
});
