const SITES_PADRAO = [
  {
    id: "tjam",
    nome: "TJAM — Certidão Negativa",
    url: "sistemas.tjam.jus.br",
    campos: {
      nome: "Nome completo",
      cpf: "Seu CPF",
      nomeMae: "Nome da mãe",
      dataNasc: "Data de nascimento",
      email: "E-mail",
    }
  }
];

let sites = [];

async function carregar() {
  const { sites: s } = await chrome.storage.local.get(["sites"]);
  sites = s || SITES_PADRAO;
  renderizar();
}

function novoId() {
  return "site_" + Date.now();
}

function renderizar() {
  const lista = document.getElementById("lista-sites");
  lista.innerHTML = "";
  sites.forEach((site, idx) => {
    const card = document.createElement("div");
    card.className = "site-card";
    card.innerHTML = `
      <div class="site-header">
        <input class="site-nome-input" type="text" placeholder="Nome do site (ex: Detran AM)" value="${esc(site.nome)}" data-idx="${idx}" data-field="nome">
        <button class="btn-del" data-idx="${idx}" title="Remover site">✕</button>
      </div>
      <div class="site-body">
        <div class="url-row">
          <span class="url-label">URL contém</span>
          <input class="url-input" type="text" placeholder="ex: detran.am.gov.br" value="${esc(site.url)}" data-idx="${idx}" data-field="url">
        </div>
        <div class="hint">Parte do endereço do site — não precisa ser a URL completa</div>
        <div class="sep"></div>
        <div class="campos-label">Texto dos campos no formulário</div>
        ${campoRow(idx, "nome",     "Nome completo",      site.campos?.nome)}
        ${campoRow(idx, "cpf",      "CPF",                site.campos?.cpf)}
        ${campoRow(idx, "nomeMae",  "Nome da mãe",        site.campos?.nomeMae)}
        ${campoRow(idx, "dataNasc", "Data de nascimento", site.campos?.dataNasc)}
        ${campoRow(idx, "email",    "E-mail",             site.campos?.email)}
      </div>`;
    lista.appendChild(card);
  });

  lista.querySelectorAll("[data-field]").forEach(el => {
    el.addEventListener("input", () => {
      const idx = parseInt(el.dataset.idx);
      const field = el.dataset.field;
      const campoKey = el.dataset.campo;
      if (campoKey) {
        sites[idx].campos[campoKey] = el.value;
      } else if (field === "nome") {
        sites[idx].nome = el.value;
      } else if (field === "url") {
        sites[idx].url = el.value;
      }
    });
  });

  lista.querySelectorAll(".btn-del").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.dataset.idx);
      sites.splice(idx, 1);
      renderizar();
    });
  });
}

function campoRow(idx, campoKey, label, valor) {
  return `
    <div class="field-row">
      <span class="field-label">${label}</span>
      <input class="field-input" type="text" placeholder="texto da etiqueta/placeholder"
        value="${esc(valor || "")}" data-idx="${idx}" data-field="campo" data-campo="${campoKey}">
    </div>`;
}

function esc(s) {
  return (s || "").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

document.getElementById("btn-add").addEventListener("click", () => {
  sites.push({ id: novoId(), nome: "", url: "", campos: { nome: "", cpf: "", nomeMae: "", dataNasc: "", email: "" } });
  renderizar();
  document.querySelector(".site-card:last-of-type .site-nome-input")?.focus();
});

document.getElementById("btn-salvar").addEventListener("click", async () => {
  await chrome.storage.local.set({ sites });
  const msg = document.getElementById("salvo-msg");
  msg.style.display = "inline";
  setTimeout(() => { msg.style.display = "none"; }, 2000);
});

carregar();
