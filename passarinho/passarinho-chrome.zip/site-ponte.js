// Ponte entre o sistema RW (rwinvestimentos.com.br) e a Passarinho (2026-11-26): o botão "Login PF" do cartão do
// cliente em Clientes Armas pede para abrir o Portal PF já entrando na conta gov do cliente. A página só manda o id do
// cliente; o CPF e a senha a Passarinho busca no próprio sistema (credGov), como no resto do login automático.
// 2026-11-27: com a Passarinho atualizada, a ponte antiga da página morre ("Aperte F5"). Agora o background põe a ponte
// nova nas abas do site ao se atualizar (onInstalled), e a antiga fica quieta quando perde a ligação.
(() => {
  let versao = "";
  try { versao = chrome.runtime.getManifest().version; } catch (_) { return; }
  if (window.__passarinhoPonte === versao) return;
  window.__passarinhoPonte = versao;
  // o site sabe que a Passarinho está instalada (e qual versão)
  document.documentElement.dataset.passarinho = versao;
  window.addEventListener("message", e => {
    if (e.source !== window || e.origin !== location.origin) return;
    const d = e.data;
    if (!d || d.passarinho !== "loginPf" || !/^[0-9a-f-]{36}$/i.test(d.clienteId || "")) return;
    // ponte de uma versão anterior (sem ligação com a extensão): a ponte nova responde
    if (!chrome.runtime?.id || window.__passarinhoPonte !== versao) return;
    const responder = r => window.postMessage({ passarinho: "loginPfResp", ok: !!r?.ok, erro: r?.erro || "" }, location.origin);
    try {
      chrome.runtime.sendMessage({ action: "loginPfCliente", clienteId: d.clienteId })
        .then(responder, er => responder({ ok: false, erro: String(er?.message || er) }));
    } catch (er) { responder({ ok: false, erro: "Aperte F5 nesta página (a Passarinho foi atualizada)." }); }
  });
})();
