const APP_URLS = ["rwinvestimentos.com.br", "iatrenilson.github.io"];


let todosClientes = [];
let appTabId = null;
let pfTabId = null;
let arquivosCr = [];
let arquivosAc = [];

// Mapa tipo (Supabase) → numero (1-14)
const TIPO_PARA_NUMERO = {
  cap_tecnica: 1, ant_federal: 2, decl_inquerito: 3,
  doc_ident: 4, laudo_psico: 5, comp_residencia: 6,
  comp_ocupacao: 7, comp_2_end: 8, ant_estadual: 9,
  anexo_a: 10, decl_habitualidade: 11, comp_filiacao: 12,
  ant_militar: 13, ant_eleitoral: 14,
};

let clientesSistema = [];
let clienteSelecionado = null;
let buscaSistemaTimer = null;
// Cliente escolhido na tela de certidões: fica guardado (certClienteAtual) para preencher os outros sites
// (Federal, Eleitoral, Estadual, Militar...) sem procurar de novo; a lixeira tira a seleção
let clienteCertidao = null;

// Pesquisa de cliente igual à do site (Laudos): sem acento e sem diferença de maiúscula, por qualquer parte do nome,
// pelas palavras do nome ou pelo CPF; quem começa com o texto vem primeiro
function buscarClientesExt(lista, busca) {
  const sem = s => (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const q = sem(busca.trim());
  if (!q) return lista;
  const dig = busca.replace(/\D/g, "");
  const partes = q.split(/[^a-z0-9]+/).filter(Boolean);
  const ordem = c => {
    const nm = sem(c.nome);
    if (nm.replace(/^(\([^)]*\)\s*)+/, "").startsWith(q)) return 0;
    const palavras = nm.split(/[^a-z0-9]+/);
    if (partes.length && partes.every(p => palavras.some(w => w.startsWith(p)))) return 1;
    if (nm.includes(q)) return 2;
    return dig.length >= 3 && (c.cpf || "").replace(/\D/g, "").includes(dig) ? 3 : -1;
  };
  return lista.map(c => ({ c, o: ordem(c) })).filter(x => x.o >= 0).sort((a, b) => a.o - b.o).map(x => x.c);
}

// Abre o site do processo para o cliente: a aba nasce por trás, guarda { cliente, aba } para o login no gov.br ser
// preenchido sozinho NESSA aba (background.js, loginGov) e só então vai para a frente (o popup fecha nesse momento)
async function abrirSiteDoCliente(url, cliente) {
  const tab = await chrome.tabs.create({ url, active: false });
  try { await chrome.storage.local.set({ loginGov: { clienteId: cliente.id, tabId: tab.id, em: Date.now() }, consentirGov: { tabId: tab.id, em: Date.now() } }); } catch (_) {}
  chrome.tabs.update(tab.id, { active: true }).catch(() => {});
}
// true quando o popup foi aberto numa aba da PF / Sinarm / SisGCorp: o cliente é o dono da conta aberta e não se troca
let clienteTravado = false;
function mostrarClienteAtual() {
  const box = document.getElementById("cliente-atual");
  if (!box) return;
  const abas = document.getElementById("ca-abas");
  // com cliente escolhido, a busca e a lista somem (o usuário pediu); a lixeira tira o cliente e elas voltam
  const lista = [document.querySelector("#tela-busca .busca-header"), document.getElementById("lista-clientes"), document.getElementById("total-clientes")];
  const rotulo = box.querySelector(".ca-rotulo"), lixeira = document.getElementById("btn-ca-limpar");
  if (rotulo) rotulo.textContent = clienteTravado ? "Cliente da conta aberta no site" : "Cliente selecionado";
  if (lixeira) lixeira.style.display = clienteTravado ? "none" : "";
  if (!clienteCertidao) {
    box.style.display = "none"; if (abas) abas.style.display = "none";
    // travado (site da PF): sem lista para escolher outro cliente
    lista.forEach(el => { if (el) el.style.display = clienteTravado ? "none" : ""; });
  } else {
    document.getElementById("ca-nome").textContent = (clienteCertidao.nome || "").toUpperCase();
    document.getElementById("ca-cpf").textContent = clienteCertidao.cpf || "Sem CPF";
    box.style.display = "flex";
    if (abas) abas.style.display = "block";
    lista.forEach(el => { if (el) el.style.display = "none"; });
  }
  document.querySelectorAll("#lista-clientes .cliente-item").forEach(el =>
    el.classList.toggle("sel", !!clienteCertidao && el.dataset.id === clienteCertidao.id));
}
async function escolherClienteCertidao(c) {
  clienteCertidao = c;
  try { await chrome.storage.local.set({ certClienteAtual: c }); } catch (_) {}
  mostrarClienteAtual();
}
async function limparClienteCertidao() {
  if (clienteTravado) return; // no site da PF o cliente é o dono da conta: não se troca
  clienteCertidao = null;
  try { await chrome.storage.local.remove(["certClienteAtual"]); } catch (_) {}
  mostrarClienteAtual();
  const st = document.getElementById("status-msg");
  st.textContent = ""; st.className = "";
}

// No Firefox o popup fecha sozinho quando abre a janela de escolher arquivos;
// lá a escolha dos PDFs é feita numa aba (popup.html?aba=1). No Chrome nada muda.
const FIREFOX = navigator.userAgent.includes("Firefox");
const EM_ABA = new URLSearchParams(location.search).has("aba");
// Aberto no painel dentro da página do site (painel.js): ocupa a largura do painel e não fecha com o seletor de arquivos
const EM_PAINEL = new URLSearchParams(location.search).has("painel");
if (EM_PAINEL) document.documentElement.classList.add("painel");
// Na atualização automática a extensão se recarrega: o menu que estava na página perde a ligação com ela e o que
// estava em andamento falha com "Extension context invalidated". É esperado (o menu novo toma o lugar): não é erro
if (EM_PAINEL) window.addEventListener("unhandledrejection", e => {
  if (/context invalidated/i.test(String(e.reason?.message ?? e.reason))) e.preventDefault();
});
// No menu do Portal PF esta página roda num quadro dentro do site. Logo depois de instalar a extensão o Chrome criou
// esse quadro sem acesso às abas (chrome.tabs indefinido em iniciar): em vez de falhar calado, pede um F5
const SEM_ABAS = !chrome.tabs || !chrome.scripting;
// diagnóstico (2026-11-22): no Firefox o quadro dentro da página mostrava este aviso mesmo depois do F5; mostra o que
// falta (tabs / scripting, pelos dois nomes que o Firefox usa) para corrigir no lugar certo
const DIAG_ABAS = (() => {
  try {
    const b = typeof browser !== "undefined" ? browser : null;
    return `tabs:${chrome.tabs ? "sim" : "não"}/${b?.tabs ? "sim" : "não"} scripting:${chrome.scripting ? "sim" : "não"}/${b?.scripting ? "sim" : "não"} runtime:${chrome.runtime?.id ? "sim" : "não"}`;
  } catch (e) { return "diag-erro"; }
})();
const AVISO_SEM_ABAS = `⚠️ Aperte F5 nesta página para o Passarinho funcionar. (${DIAG_ABAS})`;
function avisarSemAbas() {
  const st = document.getElementById("pf-status");
  st.textContent = AVISO_SEM_ABAS;
  st.className = "erro";
}
// Aba da PF onde o preenchimento roda. A guardada (pfTabId) pode não existir mais ("No tab with id"), e no menu do
// portal a "aba ativa" na hora que o menu abriu nem sempre é a do portal: o menu pergunta ao background em qual aba ele está
async function abaDoPainel() {
  if (!EM_PAINEL) return null;
  try { return (await chrome.runtime.sendMessage({ action: "minhaAba" }))?.tabId ?? null; } catch (_) { return null; }
}
async function abaPfAtual() {
  const doPainel = await abaDoPainel();
  if (doPainel) return (pfTabId = doPainel);
  if (pfTabId && await chrome.tabs.get(pfTabId).catch(() => null)) return pfTabId;
  pfTabId = null;
  return (await chrome.tabs.query({ active: true, currentWindow: true }))[0]?.id ?? null;
}
function escolherNaAbaSeFirefox() {
  if (!FIREFOX || EM_ABA || EM_PAINEL) return false;
  chrome.tabs.create({ url: chrome.runtime.getURL("popup.html?aba=1") });
  window.close();
  return true;
}

// Portal slot numbers (1-12) indexed by Supabase tipo
const SLOT_PORTAL = {
  ant_federal: 1, ant_estadual: 2, ant_eleitoral: 3, ant_militar: 4,
  comp_ocupacao: 5, comp_residencia: 6, comp_2_end: 7, cap_tecnica: 8,
  laudo_psico: 9, decl_inquerito: 10, comp_filiacao: 11, decl_habitualidade: 12,
};
const SLOT_NOMES = {
  1:"Federal", 2:"Estadual", 3:"Eleit.", 4:"Militar",
  5:"Ocupação", 6:"Residên.", 7:"2ºEnd.", 8:"Cap.Téc.",
  9:"Laudo", 10:"Inquér.", 11:"Filiação", 12:"Habit.",
};

function computarArqPorSlot() {
  const res = {};
  for (const arq of arquivosCr) {
    const slot = arq.tipo ? SLOT_PORTAL[arq.tipo] : arq.numero;
    if (slot >= 1 && slot <= 12) res[slot] = arq.nome || `slot${slot}`;
  }
  return res;
}

function mostrarPreviewCr() {
  const arqPorSlot = computarArqPorSlot();
  const grid = document.getElementById("pf-preview-grid");
  if (!grid) return;
  grid.innerHTML = "";
  for (let s = 1; s <= 12; s++) {
    const pill = document.createElement("div");
    const tem = arqPorSlot[s];
    pill.className = "slot-pill " + (tem ? "tem" : "sem");
    pill.title = tem ? arqPorSlot[s] : `Slot ${s} — sem arquivo`;
    pill.textContent = (tem ? "✓ " : "– ") + SLOT_NOMES[s];
    grid.appendChild(pill);
  }
  document.getElementById("pf-preview").style.display = "block";
  document.getElementById("pf-resultado").style.display = "none";
}

function mostrarResultadoCr(slots) {
  const grid = document.getElementById("pf-resultado-grid");
  if (!grid || !slots) return;
  grid.innerHTML = "";
  for (let s = 1; s <= 12; s++) {
    const st = slots[s] || "sem";
    const pill = document.createElement("div");
    pill.className = "slot-pill " + st;
    const icon = st === "ok" ? "✓" : st === "err" ? "✗" : "–";
    pill.textContent = icon + " " + SLOT_NOMES[s];
    pill.title = `Slot ${s} — ${st === "ok" ? "enviado" : st === "err" ? "falhou" : "sem arquivo"}`;
    grid.appendChild(pill);
  }
  document.getElementById("pf-resultado").style.display = "block";
  document.getElementById("pf-preview").style.display = "none";
}

function limparSlotUI() {
  document.getElementById("pf-preview").style.display = "none";
  document.getElementById("pf-resultado").style.display = "none";
}

function mostrarPausa(desc) {
  const el = document.getElementById("pf-pausa");
  document.getElementById("pf-pausa-txt").textContent = desc;
  el.style.display = "flex";
}

function esconderPausa() {
  document.getElementById("pf-pausa").style.display = "none";
}

// Botões ⏸ Pausar / ▶ Retomar e ⏹ Parar, visíveis enquanto o preenchimento roda
function mostrarControles(rodando, pausado = false) {
  const box = document.getElementById("pf-controles");
  if (!box) return;
  box.style.display = rodando ? "flex" : "none";
  const b = document.getElementById("btn-pf-pausar");
  b.textContent = pausado ? "▶ Retomar" : "⏸ Pausar";
  b.dataset.pausado = pausado ? "1" : "";
}

// IndexedDB: persiste arquivos entre aberturas do popup
async function dbAbrir() {
  return new Promise((res, rej) => {
    const req = indexedDB.open("passarinho_cr", 1);
    req.onupgradeneeded = e => e.target.result.createObjectStore("arquivos", { keyPath: "numero" });
    req.onsuccess = e => res(e.target.result);
    req.onerror = e => rej(e.target.error);
  });
}
async function dbSalvarArquivos(arqs, nomePasta) {
  try {
    const db = await dbAbrir();
    const tx = db.transaction("arquivos", "readwrite");
    const store = tx.objectStore("arquivos");
    store.clear();
    arqs.forEach(a => store.put(a));
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = e => rej(e.target.error); });
    await chrome.storage.local.set({ crPastaNome: nomePasta, crTotal: arqs.length });
  } catch (_) {}
}
async function dbCarregarArquivos() {
  try {
    const db = await dbAbrir();
    const tx = db.transaction("arquivos", "readonly");
    const req = tx.objectStore("arquivos").getAll();
    return await new Promise((res, rej) => { req.onsuccess = e => res(e.target.result || []); req.onerror = () => res([]); });
  } catch { return []; }
}

async function dbAbrirAc() {
  return new Promise((res, rej) => {
    const req = indexedDB.open("passarinho_ac", 1);
    req.onupgradeneeded = e => e.target.result.createObjectStore("arquivos", { keyPath: "numero" });
    req.onsuccess = e => res(e.target.result);
    req.onerror = e => rej(e.target.error);
  });
}
async function dbSalvarArquivosAc(arqs, nomePasta) {
  try {
    const db = await dbAbrirAc();
    const tx = db.transaction("arquivos", "readwrite");
    const store = tx.objectStore("arquivos");
    store.clear();
    arqs.forEach(a => store.put(a));
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = e => rej(e.target.error); });
    await chrome.storage.local.set({ acPastaNome: nomePasta, acTotal: arqs.length });
  } catch (_) {}
}
async function dbCarregarArquivosAc() {
  try {
    const db = await dbAbrirAc();
    const tx = db.transaction("arquivos", "readonly");
    const req = tx.objectStore("arquivos").getAll();
    return await new Promise((res, rej) => { req.onsuccess = e => res(e.target.result || []); req.onerror = () => res([]); });
  } catch { return []; }
}

document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("btn-abrir-app").addEventListener("click", () => {
    chrome.tabs.create({ url: "https://rwinvestimentos.com.br" });
  });
  document.getElementById("input-busca").addEventListener("input", filtrar);
  document.getElementById("btn-ca-preencher").addEventListener("click", () => { if (clienteCertidao) preencherFormulario(clienteCertidao); });
  document.getElementById("btn-ca-limpar").addEventListener("click", limparClienteCertidao);
  // Pausar / Retomar a extensão (2026-11-22): pausada, nada acontece sozinho (menu da página escondido, sem leitura de
  // processos, sem conferir conta, sem abrir o sistema, sem pedido guardado). O ícone mostra ON / OFF (background.js)
  const btnPausarExt = document.getElementById("btn-pausar-ext");
  const mostrarPausada = p => {
    document.documentElement.classList.toggle("pausada", !!p);
    btnPausarExt.textContent = p ? "Retomar" : "Pausar";
    btnPausarExt.classList.toggle("pausada", !!p);
    btnPausarExt.title = p ? "Retomar a Passarinho" : "Pausar a Passarinho: ela para de fazer coisas sozinha";
  };
  try { mostrarPausada((await chrome.storage.local.get(["passarinhoPausado"])).passarinhoPausado); } catch (_) {}
  btnPausarExt.addEventListener("click", async () => {
    const agora = !document.documentElement.classList.contains("pausada");
    mostrarPausada(agora);
    try {
      await chrome.storage.local.set({ passarinhoPausado: agora });
      if (agora) await chrome.storage.local.remove(["acaoPendente"]); // pausar cancela o pedido guardado
    } catch (_) {}
  });
  // Atender a fila de consultas neste computador (2026-11-27): ligado por padrão; desligado (filaDesligada) o background
  // não pega pedidos nem manda o sinal de "ligada" ao sistema, e o Login PF continua normal
  const chkFila = document.getElementById("chk-fila");
  const mostrarFila = desligada => {
    chkFila.checked = !desligada;
    document.getElementById("linha-fila").classList.toggle("desligada", !!desligada);
  };
  try { mostrarFila((await chrome.storage.local.get(["filaDesligada"])).filaDesligada); } catch (_) {}
  chkFila.addEventListener("change", async () => {
    mostrarFila(!chkFila.checked);
    try { await chrome.storage.local.set({ filaDesligada: !chkFila.checked }); } catch (_) {}
  });
  // Abas Processo / Certidões do cliente escolhido (2026-11-22)
  document.querySelectorAll(".ca-tab").forEach(t => t.addEventListener("click", () => {
    document.querySelectorAll(".ca-tab").forEach(x => x.classList.toggle("ativa", x === t));
    document.getElementById("ca-painel-processo").style.display = t.dataset.aba === "processo" ? "" : "none";
    document.getElementById("ca-painel-certidoes").style.display = t.dataset.aba === "certidoes" ? "" : "none";
  }));
  // Processo: abre o site com este cliente já escolhido no menu da Passarinho de lá (pfClienteCache, que o menu restaura)
  document.querySelectorAll("[data-abrir]").forEach(b => b.addEventListener("click", async () => {
    if (!clienteCertidao) return;
    try { await chrome.storage.local.set({ pfClienteCache: clienteCertidao }); } catch (_) {}
    await abrirSiteDoCliente(b.dataset.abrir, clienteCertidao);
  }));
  // Processo: GT pede o evento (os mesmos cadastrados no menu da página, chrome.storage gtEventos)
  const selProc = document.getElementById("ca-processo"), selEv = document.getElementById("ca-evento");
  const EVENTO_PADRAO = { id: "ponta-negra", nome: "Clube de Tiro Ponta Negra", logradouro: "Av. Liberalina Loureiro",
    numero: "457", bairro: "Ponta Negra", cidade: "Manaus", uf: "AM", cep: "69037-216" };
  let eventosPopup = [EVENTO_PADRAO];
  selProc.addEventListener("change", async () => {
    const gt = selProc.value === "gt";
    selEv.style.display = gt ? "" : "none";
    // 2026-11-25: escolher o processo já começa (antes só escolhia e esperava o "Preencher agora"; o usuário escolheu
    // CR e nada aconteceu). O GT ainda espera o clique, porque precisa escolher o evento antes.
    if (selProc.value && !gt) { document.getElementById("ca-preencher-agora").click(); return; }
    if (gt) {
      try { const r = await chrome.storage.local.get(["gtEventos"]); if (Array.isArray(r.gtEventos) && r.gtEventos.length) eventosPopup = r.gtEventos; } catch (_) {}
      selEv.innerHTML = eventosPopup.map((ev, i) => `<option value="${i}">${String(ev.nome).replace(/</g, "")}</option>`).join("");
    }
  });
  // Preencher agora: o menu da aba da PF que está na frente escolhe o cliente e roda o processo (ele acompanha,
  // mostra o Continuar/Pausar e confere a conta); o popup fecha
  document.getElementById("ca-preencher-agora").addEventListener("click", async () => {
    const st = document.getElementById("status-msg");
    if (!clienteCertidao) return;
    if (!selProc.value) { st.textContent = "Escolha o processo."; st.className = "erro"; return; }
    const [modo, variante0] = selProc.value.split("|");
    const variante = modo === "gt" ? JSON.stringify(eventosPopup[Number(selEv.value) || 0]) : (variante0 || "");
    const [aba] = await chrome.tabs.query({ active: true, currentWindow: true });
    const site = modo === "gt" ? /servicos\.pf\.gov\.br/ : modo === "sisgcorp" ? /sisgcorp\.eb\.mil\.br/ : /portal\.pf\.gov\.br/;
    const nomeSite = modo === "gt" ? "Sinarm CAC" : modo === "sisgcorp" ? "SisGCorp" : "Portal PF";
    if (!aba?.url || !site.test(aba.url)) {
      // Site do processo não está na frente (o usuário pediu, 2026-11-22): abre o site certo e guarda o pedido; o menu
      // da página começa sozinho assim que a conta gov DO CLIENTE estiver logada (menu-painel.js, acaoPendente).
      // SisGCorp: não sei onde aparece o nome logado lá, então só abre o site
      const url = modo === "gt" ? "https://servicos.pf.gov.br/sisgcorp-cliente-web-externo/"
        : modo === "sisgcorp" ? "https://sisgcorp.eb.mil.br/" : "https://portal.pf.gov.br/portal-web-externo/";
      try {
        await chrome.storage.local.set({ pfClienteCache: clienteCertidao });
        if (modo !== "sisgcorp") await chrome.storage.local.set({ acaoPendente: { modo, variante, cliente: clienteCertidao, em: Date.now() } });
      } catch (_) {}
      await abrirSiteDoCliente(url, clienteCertidao);
      return;
    }
    try { await chrome.storage.local.set({ pfClienteCache: clienteCertidao }); } catch (_) {}
    let resp = null;
    try { resp = await chrome.runtime.sendMessage({ action: "menuExecutar", tabId: aba.id, cliente: clienteCertidao, modo, variante }); } catch (_) {}
    if (resp?.ok) { window.close(); return; }
    // O quadro da página não respondeu (2026-11-23: no Portal PF da janela anônima o "Preencher agora" dava "ainda não
    // carregou a Passarinho" mesmo depois do F5). Outro caminho: guarda o pedido (o quadro confere a cada 3 s e só começa
    // se a conta aberta for a do cliente) e põe o quadro na página se ele não estiver lá.
    try {
      await chrome.storage.local.set({ acaoPendente: { modo, variante, cliente: clienteCertidao, em: Date.now() } });
    } catch (_) {}
    let quadro = "?";
    try {
      quadro = (await chrome.scripting.executeScript({ target: { tabId: aba.id },
        func: () => !!document.getElementById("passarinho-painel") }))?.[0]?.result ? "sim" : "não";
      if (quadro === "não") await chrome.scripting.executeScript({ target: { tabId: aba.id }, files: ["painel.js"] });
    } catch (e) { quadro = "erro: " + String(e?.message || e).slice(0, 50); }
    st.textContent = "⏳ Começando…"; st.className = "ok";
    const fimEspera = Date.now() + 8000;
    while (Date.now() < fimEspera) {
      await new Promise(r => setTimeout(r, 500));
      const { acaoPendente } = await chrome.storage.local.get(["acaoPendente"]).catch(() => ({}));
      if (!acaoPendente) { window.close(); return; } // o quadro pegou o pedido
    }
    st.textContent = `O ${nomeSite} ainda não carregou a Passarinho. Aperte F5 nessa aba e tente de novo. (quadro na página: ${quadro})`;
    st.className = "erro";
  });
  // Certidões: abre e preenche (emitirCertidoes, a mesma do menu da página)
  const certidoesDoPopup = async quais => {
    if (!clienteCertidao) return;
    const st = document.getElementById("status-msg");
    st.textContent = `⏳ Abrindo e preenchendo ${quais.length === 1 ? "a certidão" : quais.length + " certidões"}… pode clicar fora, elas terminam sozinhas.`; st.className = "ok";
    const res = await emitirCertidoesNoFundo(clienteCertidao, quais).catch(e => [{ nome: "Certidões", ok: false, msg: String(e?.message || e) }]);
    const falhas = res.filter(r => !r.ok);
    st.textContent = res.map(r => `${r.ok ? "✓" : "⚠️"} ${r.nome}${r.ok ? (r.depois ? " (termina ao abrir a aba)" : "") : `: ${r.msg}`}`).join(" · ");
    st.className = falhas.length ? "erro" : "ok";
  };
  document.getElementById("ca-cert-todas").addEventListener("click", () => certidoesDoPopup(["federal", "estadual", "eleitoral", "militar"]));
  document.querySelectorAll("#ca-painel-certidoes [data-cert]").forEach(b =>
    b.addEventListener("click", () => certidoesDoPopup([b.dataset.cert])));
  try {
    const { certClienteAtual } = await chrome.storage.local.get(["certClienteAtual"]);
    if (certClienteAtual && !clienteTravado && !clienteCertidao) { clienteCertidao = certClienteAtual; mostrarClienteAtual(); }
  } catch (_) {}
  document.getElementById("btn-pf-cr").addEventListener("click", () => preencherPfCr());
  // Registrar Arma: mesmo fluxo e mesmos documentos do CR, só muda o serviço escolhido
  document.getElementById("btn-pf-reg").addEventListener("click", () => preencherPfCr("registro"));
  document.getElementById("btn-pf-ac").addEventListener("click", () => preencherPfCr("ac"));
  document.getElementById("btn-pf-pasta").addEventListener("click", selecionarPastaCr);
  document.getElementById("btn-pf-pasta-ac").addEventListener("click", selecionarPastaAc);
  document.getElementById("pf-input-files").addEventListener("change", async (e) => {
    await processarArquivosInput(Array.from(e.target.files));
    e.target.value = "";
  });
  document.getElementById("pf-input-files-ac").addEventListener("change", async (e) => {
    await processarArquivosInputAc(Array.from(e.target.files));
    e.target.value = "";
  });
  document.getElementById("btn-limpar-cr").addEventListener("click", async () => {
    arquivosCr = [];
    await chrome.storage.local.remove(["crPastaNome","crTotal"]);
    const db = await dbAbrir();
    const tx = db.transaction("arquivos","readwrite");
    tx.objectStore("arquivos").clear();
    document.getElementById("pf-pasta-info").textContent = "";
    document.getElementById("btn-limpar-cr").style.display = "none";
    limparSlotUI();
  });
  document.getElementById("btn-limpar-ac").addEventListener("click", async () => {
    arquivosAc = [];
    await chrome.storage.local.remove(["acPastaNome","acTotal"]);
    const db = await dbAbrirAc();
    const tx = db.transaction("arquivos","readwrite");
    tx.objectStore("arquivos").clear();
    document.getElementById("pf-pasta-info-ac").textContent = "";
    document.getElementById("btn-limpar-ac").style.display = "none";
  });
  // ⏸ Pausar / ▶ Retomar e ⏹ Parar: mudam o sinal na aba da PF; o preenchimento confere em toda espera
  document.getElementById("btn-pf-pausar").addEventListener("click", async e => {
    const tabId = await abaPfAtual();
    if (!tabId) return;
    const pausar = !e.currentTarget.dataset.pausado;
    mostrarControles(true, pausar);
    try {
      await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args: [pausar],
        func: p => { window.__passarinho_pausado = p; } });
    } catch (_) {}
  });
  document.getElementById("btn-pf-parar").addEventListener("click", async () => {
    const tabId = await abaPfAtual();
    if (!tabId) return;
    const statusEl = document.getElementById("pf-status");
    // Para NA HORA e zera tudo: o preenchimento em andamento morre na próxima espera/clique (confere o sinal e a sua
    // identificação), a página fica como "nada rodando" e o próximo clique começa do início
    try {
      await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN",
        func: () => {
          window.__passarinho_parar = true; window.__passarinho_pausado = false; window.__passarinho_waiting = false;
          window.__passarinho_exec = null;          // nenhum preenchimento vale mais
          window.__passarinho_rodando = false;
          window.__passarinho_step_desc = "";
          window.__passarinho_resultado = { n: 0, parado: true };
        } });
    } catch (_) {}
    acompanhamentoAtual?.cancelar();
    statusEl.textContent = "⏹ Parado. Clique de novo para começar do início.";
    statusEl.className = "erro";
  });

  document.getElementById("btn-continuar-etapa").addEventListener("click", async () => {
    const tabId = await abaPfAtual();
    if (!tabId) return;
    esconderPausa();
    const statusEl = document.getElementById("pf-status");
    statusEl.textContent = "⏳ Preenchendo…";
    statusEl.className = "ok";
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: () => { window.__passarinho_waiting = false; },
      });
    } catch (_) {}
  });

  document.getElementById("btn-usar-aba-atual").addEventListener("click", async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    pfTabId = tabs[0]?.id;
    if (pfTabId) mostrarPf();
  });

  // Busca no sistema
  document.getElementById("pf-input-sistema").addEventListener("input", (e) => {
    clearTimeout(buscaSistemaTimer);
    buscaSistemaTimer = setTimeout(() => filtrarSistema(e.target.value.trim()), 200);
  });
  document.getElementById("pf-input-sistema").addEventListener("focus", () => {
    if (clientesSistema.length === 0) carregarClientesSistema();
  });
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".pf-lista-wrap")) {
      document.getElementById("pf-lista-sistema").style.display = "none";
    }
  });
  document.getElementById("btn-limpar-sistema").addEventListener("click", limparClienteSistema);

  // Restaurar CR cache
  const cachedArqs = await dbCarregarArquivos();
  if (cachedArqs && cachedArqs.length > 0) {
    arquivosCr = cachedArqs;
    const { crPastaNome } = await chrome.storage.local.get(["crPastaNome"]);
    const pastaInfo = document.getElementById("pf-pasta-info");
    pastaInfo.textContent = `✓ ${arquivosCr.length} PDF(s) prontos — ${crPastaNome || "pasta selecionada"}`;
    pastaInfo.style.color = "#00c490";
    document.getElementById("btn-limpar-cr").style.display = "inline-block";
    mostrarPreviewCr();
  }
  // Restaurar AC cache
  const cachedArqsAc = await dbCarregarArquivosAc();
  if (cachedArqsAc && cachedArqsAc.length > 0) {
    arquivosAc = cachedArqsAc;
    const { acPastaNome } = await chrome.storage.local.get(["acPastaNome"]);
    const pastaInfoAc = document.getElementById("pf-pasta-info-ac");
    pastaInfoAc.textContent = `✓ ${arquivosAc.length} PDF(s) prontos — ${acPastaNome || "pasta selecionada"}`;
    pastaInfoAc.style.color = "#9090ff";
    document.getElementById("btn-limpar-ac").style.display = "inline-block";
  }
  // Restaurar último cliente selecionado do sistema
  try {
    const { pfClienteCache } = await chrome.storage.local.get(["pfClienteCache"]);
    // 2026-11-25: ela baixa todos os PDFs do cliente; no menu do ícone isso segurava a tela por vários segundos
    // (usuário viu: "pq vc demora a abrir agora"). Lá carrega por trás; no quadro da página continua esperando.
    if (pfClienteCache) {
      const carregar = selecionarClienteSistema(pfClienteCache).catch(() => {});
      if (EM_PAINEL) await carregar;
    }
  } catch (_) {}

  if (EM_ABA) {
    // Aba aberta só para escolher os PDFs (Firefox)
    mostrarPf();
    const st = document.getElementById("pf-status");
    st.textContent = "Escolha os PDFs da pasta do cliente. Depois feche esta aba e volte para a extensão.";
    st.className = "ok";
    return;
  }
  if (SEM_ABAS) { avisarSemAbas(); return; }
  await iniciar();
  await retomarAcompanhamento();
});

// URLs que indicam formulário da PF/SINARM CAC
const PF_URLS = ["portal.pf.gov.br", "servicos.pf.gov.br", "sisgcorp", "sinarm", "pf.gov.br", "preencher-formulario", "exercito.eb.mil.br", "sac.exercito", ".gov.br"];

async function iniciar() {
  // Menu do portal: a aba dele é a da PF, mesmo que outra estivesse na frente quando a página carregou
  const doPainel = await abaDoPainel();
  if (doPainel) { pfTabId = doPainel; mostrarPf(); return; }
  // 2026-11-22: o popup do ícone é sempre a tela nova (cliente → Processo / Certidões), em qualquer site. As telas
  // antigas (tela-pf e "sem sessão") continuam no arquivo, mas o ícone não as usa mais.
  if (!SEM_ABAS) {
    mostrarBusca();
    // Aba da PF / Sinarm / SisGCorp na frente: o cliente do popup é o do menu dessa página (o da conta aberta). Antes eram
    // dois "clientes escolhidos" separados, e o popup mostrava um enquanto o menu preenchia outro (2026-11-22)
    // E fica TRAVADO nele: não dá para escolher outro cliente com a conta de alguém aberta (usuário viu, 2026-11-22:
    // escolher outro cliente na lista preenchia os dados dele no formulário de outra pessoa)
    let conta = "";
    try {
      const [aba] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (/^https:\/\/(portal\.pf\.gov\.br|servicos\.pf\.gov\.br|sisgcorp\.eb\.mil\.br)\//.test(aba?.url || "")) {
        clienteTravado = true;
        conta = (await chrome.scripting.executeScript({ target: { tabId: aba.id },
          func: () => (document.querySelector(".profile-name, .user-info-name")?.textContent || "").replace(/\s+/g, " ").trim(),
        }).catch(() => null))?.[0]?.result || "";
        const r = await chrome.runtime.sendMessage({ action: "qualCliente", tabId: aba.id }).catch(() => null);
        const doMenu = r?.cliente?.id && (!conta || mesmoNome(conta, r.cliente.nome || "")) ? r.cliente : null;
        clienteCertidao = null;
        if (doMenu) await escolherClienteCertidao(doMenu);
        else mostrarClienteAtual();
      }
    } catch (_) {}
    await carregarClientes();
    // o menu ainda não tinha o cliente: pega pelo nome da conta aberta (um único cliente com esse nome)
    if (clienteTravado && !clienteCertidao) {
      const iguais = conta ? todosClientes.filter(c => mesmoNome(conta, c.nome || "")) : [];
      if (iguais.length === 1) await escolherClienteCertidao(iguais[0]);
      else {
        const st = document.getElementById("status-msg");
        st.textContent = conta
          ? `⚠️ A conta aberta é de ${conta.toUpperCase()}, que ${iguais.length ? "tem mais de um cadastro com esse nome" : "não está em Clientes Armas"}. Cadastre ou corrija no sistema.`
          : "⚠️ Entre na conta gov do cliente neste site: o cliente da Passarinho será o dono da conta.";
        st.className = "erro";
      }
    }
    return;
  }
  const tabs = await chrome.tabs.query({});
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Prioridade 1: aba ATIVA é PF/SINARM → mostra tela PF
  if (activeTab?.url && PF_URLS.some(u => activeTab.url.includes(u))) {
    pfTabId = activeTab.id;
    mostrarPf();
    return;
  }

  // Prioridade 2: Passarinho app aberto → tela de certidões
  const appTab = tabs.find(t => t.url && APP_URLS.some(u => t.url.includes(u)));
  if (appTab) {
    appTabId = appTab.id;
    mostrarBusca();
    carregarClientes();
    return;
  }

  // Prioridade 3: PF/SINARM em qualquer aba (Passarinho não está aberto)
  const pfTab = tabs.find(t => t.url && PF_URLS.some(u => t.url.includes(u)));
  if (pfTab) {
    pfTabId = pfTab.id;
    mostrarPf();
    return;
  }

  mostrarSemSessao();
}

async function carregarClientes() {
  const lista = document.getElementById("lista-clientes");
  lista.innerHTML = '<div class="carregando">Carregando clientes…</div>';
  try {
    // mesma consulta do menu (site-funcs.js): acha a aba do sistema RW (até na janela normal vista da anônima) e,
    // se não houver, abre o sistema sozinho numa aba de fundo
    const resp = await noSite("clientes");
    if (!resp?.ok) {
      lista.innerHTML = `<div class="vazio" style="font-size:11px;padding:14px">Não achei o sistema logado. Entre uma vez no rwinvestimentos.com.br numa janela normal do Chrome e abra a Passarinho de novo.<br><small style="opacity:.6">${(window.__passarinho_diag_sistema || "").replace(/</g, "")}</small></div>`;
      return;
    }
    todosClientes = resp.data;
    document.getElementById("total-clientes").textContent = `${todosClientes.length} clientes`;
    // o cliente guardado pega os dados atualizados do site (se o cadastro mudou)
    if (clienteCertidao) {
      const novo = todosClientes.find(x => x.id === clienteCertidao.id);
      if (novo) await escolherClienteCertidao(novo);
    }
    renderizar(todosClientes);
  } catch (e) {
    lista.innerHTML = `<div class="vazio" style="font-size:11px;padding:14px">Erro: ${e.message}</div>`;
  }
}

function filtrar() {
  renderizar(buscarClientesExt(todosClientes, document.getElementById("input-busca").value));
}

function renderizar(clientes) {
  const lista = document.getElementById("lista-clientes");
  if (!clientes.length) { lista.innerHTML = '<div class="vazio">Nenhum cliente encontrado.</div>'; return; }
  lista.innerHTML = clientes.map(c => `
    <div class="cliente-item" data-id="${c.id}">
      <div class="cliente-nome">${(c.nome || "").toUpperCase()}</div>
      <div class="cliente-cpf">${c.cpf || "Sem CPF"}</div>
    </div>`).join("");
  lista.querySelectorAll(".cliente-item").forEach(item =>
    item.addEventListener("click", async () => {
      const c = todosClientes.find(x => x.id === item.dataset.id);
      if (!c) return;
      // só ESCOLHE o cliente. Antes também preenchia na hora a aba aberta, e escolher outro cliente com o formulário de
      // alguém aberto na PF preenchia os dados errados lá (usuário viu, 2026-11-22). Preencher agora é sempre um botão.
      await escolherClienteCertidao(c);
    }));
  mostrarClienteAtual();
}

async function preencherFormulario(cliente) {
  const statusMsg = document.getElementById("status-msg");

  // Feedback imediato
  statusMsg.textContent = "⏳ Preenchendo…";
  statusMsg.className = "ok";

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];

  if (!tab?.url) {
    statusMsg.textContent = "⚠️ Nenhuma aba ativa.";
    statusMsg.className = "erro"; return;
  }
  // página do próprio Chrome (nova aba, configurações...): nenhuma extensão pode mexer nela. Antes aparecia o erro
  // em inglês "Cannot access a chrome:// URL"
  // só nos sites de certidão: em qualquer outro (PF, Sinarm, SisGCorp, sistema...) preencheria dados no lugar errado
  if (!/^https:\/\/([^/]*\.)?(trf1\.jus\.br|tjam\.jus\.br|tse\.jus\.br|stm\.jus\.br)\//i.test(tab.url)) {
    statusMsg.textContent = "⚠️ Esta aba não é o site de uma certidão. Use \"Emitir todas\" ou abra a certidão pela lista.";
    statusMsg.className = "erro"; return;
  }

  const dados = {
    nome: (cliente.nome || "").toUpperCase(),
    cpf: cliente.cpf || "",
    nomeMae: (cliente.nome_mae || "").toUpperCase(),
    nomePai: (cliente.nome_pai || "").toUpperCase(),
    dataNascimento: cliente.data_nascimento || "",
    email: "",
  };

  const isTrf1 = tab.url.includes("trf1.jus.br");
  const isStm  = tab.url.includes("stm.jus.br");
  const isTse  = tab.url.includes("tse.jus.br");

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: (isTrf1 || isTse) ? "MAIN" : "ISOLATED",
      func: isTrf1 ? injectarTrf1 : isStm ? injectarStm : isTse ? injectarTse : injectarDados,
      args: [dados],
    });
    const res = results?.[0]?.result;
    const n = typeof res === "object" ? (res?.n || 0) : (res || 0);
    const dbg = typeof res === "object" ? res?.dbg : "";

    statusMsg.textContent = n > 0
      ? `✓ ${n} campo(s) preenchido(s)! ${dbg}`
      : `⚠️ ${dbg || "Nenhum campo encontrado."}`;
    statusMsg.className = n > 0 ? "ok" : "erro";
  } catch (e) {
    statusMsg.textContent = `Erro: ${e.message}`;
    statusMsg.className = "erro";
  }
}

// Extrai texto de PDF com suporte a streams FlateDecode (deflate)
async function extrairTextoPdf(buffer) {
  try {
    const bytes = new Uint8Array(buffer);
    const LIMITE = Math.min(bytes.length, 800000);
    let raw = "";
    for (let i = 0; i < LIMITE; i += 8192) {
      raw += String.fromCharCode(...bytes.subarray(i, Math.min(i + 8192, LIMITE)));
    }

    const coletarStrings = (s) => {
      let t = "";
      for (const m of s.matchAll(/\(([^()\\\r\n]{2,200})\)/g)) t += " " + m[1];
      for (const m of s.matchAll(/\[([^\]]{0,400})\]\s*TJ/g)) {
        for (const inner of m[1].matchAll(/\(([^)]{1,100})\)/g)) t += " " + inner[1];
      }
      return t;
    };

    const descomprimir = async (strDados) => {
      const bts = new Uint8Array(strDados.length);
      for (let i = 0; i < strDados.length; i++) bts[i] = strDados.charCodeAt(i) & 0xFF;
      let melhor = "", melhorScore = 0;
      for (const fmt of ["deflate", "deflate-raw"]) {
        try {
          const ds = new DecompressionStream(fmt);
          const w = ds.writable.getWriter();
          w.write(bts); w.close();
          const chunks = [];
          const r = ds.readable.getReader();
          while (true) { const { done, value } = await r.read(); if (done) break; chunks.push(value); }
          let out = "";
          for (const c of chunks) out += String.fromCharCode(...c);
          const score = coletarStrings(out).length;
          if (score > melhorScore) { melhor = out; melhorScore = score; }
        } catch { continue; }
      }
      return melhor.length > 0 ? melhor : null;
    };

    let texto = coletarStrings(raw);
    // Hex strings não comprimidas
    for (const m of raw.matchAll(/<([0-9A-Fa-f]{6,300})>/g)) {
      const h = m[1]; let d = "";
      for (let i = 0; i < h.length - 1; i += 2) d += String.fromCharCode(parseInt(h.slice(i, i+2), 16));
      texto += " " + d;
    }
    // Descomprime cada stream FlateDecode
    const partes = raw.split(/stream\r?\n/);
    for (let i = 1; i < partes.length; i++) {
      const fim = partes[i].indexOf("\nendstream");
      if (fim < 1) continue;
      const dec = await descomprimir(partes[i].slice(0, fim));
      if (dec) texto += coletarStrings(dec);
    }

    return texto.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  } catch { return ""; }
}

// Identifica o slot (1-12) de um PDF pelo nome e/ou conteúdo (ordem portal.pf.gov.br)
async function identificarNumeroArquivo(nome, buffer) {
  function n(s) { return (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
  // Prioridade 1: prefixo numérico (ex: "1 Federal.pdf")
  const prefixo = parseInt(nome.match(/^(\d+)/)?.[1] || "0");
  if (prefixo >= 1 && prefixo <= 12) return prefixo;

  const mapa = [
    { num: 1,  nome: ["federal"],
               pdf:  ["justica federal", "tribunal regional federal", "certidao judicial criminal"] },
    { num: 2,  nome: ["estadual"],
               pdf:  ["justica estadual", "tribunal de justica", "antecedente criminal estadual"] },
    { num: 3,  nome: ["eleitoral"],
               pdf:  ["justica eleitoral", "tribunal regional eleitoral", "antecedente criminal eleitoral"] },
    { num: 4,  nome: ["militar"],
               pdf:  ["justica militar da uniao", "justica militar", "acoes criminais militares",
                      "acoes penais militares", "superior tribunal militar", "stm"] },
    { num: 5,  nome: ["ocupacao licita", "ocupacao", "licita", "trabalho", "emprego"],
               pdf:  ["ocupacao licita", "vinculo empregaticio", "ctps", "contrato de trabalho"] },
    { num: 6,  nome: ["residencia", "residencial"],
               pdf:  ["comprovante de residencia", "endereco residencial", "residencia fixa"] },
    { num: 7,  nome: ["segundo endereco", "guarda do acervo", "acervo"],
               pdf:  ["comprovante de segundo endereco", "segundo endereco de guarda"] },
    { num: 8,  nome: ["capacidade tecnica", "capacidade", "atestado"],
               pdf:  ["capacidade tecnica", "atestado de capacidade", "manuseio de arma"] },
    { num: 9,  nome: ["laudo", "psicolog", "aptidao"],
               pdf:  ["aptidao psicologica", "laudo psicologico", "avaliacao psicologica"] },
    { num: 10, nome: ["inquerito", "nao estar respond", "processo criminal"],
               pdf:  ["inquerito policial", "processo criminal", "nao esta respondendo a inquerito"] },
    { num: 11, nome: ["filiacao", "filia", "clube", "tiro desport"],
               pdf:  ["filiacao", "entidade de tiro", "clube de tiro", "associacao de tiro"] },
    { num: 12, nome: ["compromisso", "habitualidade"],
               pdf:  ["habitualidade", "compromisso de comprovar", "frequencia minima"] },
  ];

  // Prioridade 2: palavras-chave no nome do arquivo
  const nm = n(nome);
  for (const { num, nome: keys } of mapa) {
    if (keys.some(k => nm.includes(n(k)))) return num;
  }

  // Prioridade 3: conteúdo do PDF
  if (buffer) {
    const textoPdf = await extrairTextoPdf(buffer);
    if (textoPdf.length > 10) {
      for (const { num, pdf: keys } of mapa) {
        if (keys.some(k => textoPdf.includes(n(k)))) return num;
      }
    }
  }

  return 0;
}

async function processarArquivosInput(files) {
  const pastaInfo = document.getElementById("pf-pasta-info");
  pastaInfo.textContent = "Lendo arquivos…";
  pastaInfo.style.color = "#406050";
  arquivosCr = [];
  for (const file of files) {
    if (!file.name.toLowerCase().endsWith(".pdf")) continue;
    const buffer = await file.arrayBuffer();
    const num = await identificarNumeroArquivo(file.name, buffer);
    if (num < 1 || num > 12) continue;
    const bytes = new Uint8Array(buffer);
    let binary = "";
    const CHUNK = 8192;
    for (let i = 0; i < bytes.length; i += CHUNK)
      binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
    arquivosCr.push({ numero: num, nome: file.name, base64: btoa(binary) });
  }
  arquivosCr.sort((a, b) => a.numero - b.numero);
  const pastaNome = files[0]?.webkitRelativePath?.split('/')[0] || "arquivos selecionados";
  if (arquivosCr.length > 0) {
    const presentes = new Set(arquivosCr.map(a => a.numero));
    const faltando = [];
    for (let i = 1; i <= 12; i++) if (!presentes.has(i)) faltando.push(i);
    const linhaFalta = faltando.length ? ` — faltam: ${faltando.join(", ")}` : "";
    pastaInfo.textContent = `✓ ${arquivosCr.length}/12 prontos — ${pastaNome}${linhaFalta}`;
    pastaInfo.style.color = faltando.length ? "#d4a730" : "#00c490";
    document.getElementById("btn-limpar-cr").style.display = "inline-block";
    await dbSalvarArquivos(arquivosCr, pastaNome);
  } else {
    pastaInfo.textContent = "⚠️ Nenhum PDF com prefixo 1-12 encontrado.";
    pastaInfo.style.color = "#ef4444";
    document.getElementById("btn-limpar-cr").style.display = "none";
  }
}

async function processarArquivosInputAc(files) {
  const pastaInfo = document.getElementById("pf-pasta-info-ac");
  pastaInfo.textContent = "Lendo arquivos…";
  pastaInfo.style.color = "#406050";
  arquivosAc = [];
  for (const file of files) {
    if (!file.name.toLowerCase().endsWith(".pdf")) continue;
    const num = parseInt(file.name.match(/^(\d+)/)?.[1] || "0");
    if (num < 1 || num > 12) continue;
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = "";
    const CHUNK = 8192;
    for (let i = 0; i < bytes.length; i += CHUNK)
      binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
    arquivosAc.push({ numero: num, nome: file.name, base64: btoa(binary) });
  }
  arquivosAc.sort((a, b) => a.numero - b.numero);
  const pastaNome = files[0]?.webkitRelativePath?.split('/')[0] || "arquivos selecionados";
  if (arquivosAc.length > 0) {
    const presentes = new Set(arquivosAc.map(a => a.numero));
    const faltando = [];
    for (let i = 1; i <= 12; i++) if (!presentes.has(i)) faltando.push(i);
    const linhaFalta = faltando.length ? ` — faltam: ${faltando.join(", ")}` : "";
    pastaInfo.textContent = `✓ ${arquivosAc.length}/12 prontos — ${pastaNome}${linhaFalta}`;
    pastaInfo.style.color = faltando.length ? "#d4a730" : "#9090ff";
    document.getElementById("btn-limpar-ac").style.display = "inline-block";
    await dbSalvarArquivosAc(arquivosAc, pastaNome);
  } else {
    pastaInfo.textContent = "⚠️ Nenhum PDF com prefixo 1-12 encontrado.";
    pastaInfo.style.color = "#ef4444";
    document.getElementById("btn-limpar-ac").style.display = "none";
  }
}

async function selecionarPastaAc() {
  if (escolherNaAbaSeFirefox()) return;
  if (typeof window.showDirectoryPicker !== 'function') {
    document.getElementById("pf-input-files-ac").click();
    return;
  }
  const pastaInfo = document.getElementById("pf-pasta-info-ac");
  pastaInfo.textContent = "Selecionando…";
  pastaInfo.style.color = "#406050";
  try {
    const dirHandle = await window.showDirectoryPicker({ mode: "read" });
    arquivosAc = [];
    for await (const [name, handle] of dirHandle.entries()) {
      if (handle.kind !== "file") continue;
      if (!name.toLowerCase().endsWith(".pdf")) continue;
      const num = parseInt(name.match(/^(\d+)/)?.[1] || "0");
      if (num < 1 || num > 12) continue;
      const file = await handle.getFile();
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      const CHUNK = 8192;
      for (let i = 0; i < bytes.length; i += CHUNK)
        binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
      arquivosAc.push({ numero: num, nome: name, base64: btoa(binary) });
    }
    arquivosAc.sort((a, b) => a.numero - b.numero);
    if (arquivosAc.length > 0) {
      const presentes = new Set(arquivosAc.map(a => a.numero));
      const faltando = [];
      for (let i = 1; i <= 12; i++) if (!presentes.has(i)) faltando.push(i);
      const linhaFalta = faltando.length ? ` — faltam: ${faltando.join(", ")}` : "";
      pastaInfo.textContent = `✓ ${arquivosAc.length}/12 prontos — ${dirHandle.name}${linhaFalta}`;
      pastaInfo.style.color = faltando.length ? "#d4a730" : "#9090ff";
      document.getElementById("btn-limpar-ac").style.display = "inline-block";
      await dbSalvarArquivosAc(arquivosAc, dirHandle.name);
    } else {
      pastaInfo.textContent = "⚠️ Nenhum PDF com prefixo 1-12 encontrado.";
      pastaInfo.style.color = "#ef4444";
      document.getElementById("btn-limpar-ac").style.display = "none";
    }
  } catch (e) {
    if (e.name !== "AbortError") {
      pastaInfo.textContent = `Erro: ${e.message}`;
      pastaInfo.style.color = "#ef4444";
    } else {
      pastaInfo.textContent = "";
    }
  }
}

async function selecionarPastaCr() {
  if (escolherNaAbaSeFirefox()) return;
  if (typeof window.showDirectoryPicker !== 'function') {
    document.getElementById("pf-input-files").click();
    return;
  }
  const pastaInfo = document.getElementById("pf-pasta-info");
  pastaInfo.textContent = "Selecionando…";
  pastaInfo.style.color = "#406050";
  try {
    const dirHandle = await window.showDirectoryPicker({ mode: "read" });
    arquivosCr = [];
    for await (const [name, handle] of dirHandle.entries()) {
      if (handle.kind !== "file") continue;
      if (!name.toLowerCase().endsWith(".pdf")) continue;
      const file = await handle.getFile();
      const buffer = await file.arrayBuffer();
      const num = await identificarNumeroArquivo(name, buffer);
      if (num < 1 || num > 12) continue;
      const bytes = new Uint8Array(buffer);
      let binary = "";
      const CHUNK = 8192;
      for (let i = 0; i < bytes.length; i += CHUNK) {
        binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
      }
      arquivosCr.push({ numero: num, nome: name, base64: btoa(binary) });
    }
    arquivosCr.sort((a, b) => a.numero - b.numero);
    if (arquivosCr.length > 0) {
      const presentes = new Set(arquivosCr.map(a => a.numero));
      const faltando = [];
      for (let i = 1; i <= 12; i++) if (!presentes.has(i)) faltando.push(i);
      const linhaFalta = faltando.length ? ` — faltam: ${faltando.join(", ")}` : "";
      pastaInfo.textContent = `✓ ${arquivosCr.length}/12 prontos — ${dirHandle.name}${linhaFalta}`;
      pastaInfo.style.color = faltando.length ? "#d4a730" : "#00c490";
      document.getElementById("btn-limpar-cr").style.display = "inline-block";
      await dbSalvarArquivos(arquivosCr, dirHandle.name);
      mostrarPreviewCr();
    } else {
      pastaInfo.textContent = "⚠️ Nenhum PDF com prefixo 1-12 encontrado. Renomeie os arquivos como: 1 Documento.pdf, 2 Certidão.pdf ...";
      pastaInfo.style.color = "#ef4444";
      limparSlotUI();
    }
  } catch (e) {
    if (e.name !== "AbortError") {
      pastaInfo.textContent = `Erro: ${e.message}`;
      pastaInfo.style.color = "#ef4444";
    } else {
      pastaInfo.textContent = "";
    }
  }
}

// CR, Registrar Arma e AC usam o mesmo caminho (com as pausas "▶ Continuar");
// o AC só muda o serviço. Com cliente do sistema, todos usam os documentos dele no site (Clientes Armas); a pasta AC
// só vale na tela do popup sem cliente do sistema
// modo: "cr", "registro", "ac" ou "cadastro" (menu do painel: só os dados pessoais, sem abrir solicitação)
// variante: "caca" na Autorização de Compra Caça do menu (no portal muda só a escolha dos itens 11 e 12)
async function preencherPfCr(modo = "cr", variante = "") {
  if (SEM_ABAS) { avisarSemAbas(); return; }
  const statusEl = document.getElementById("pf-status");
  const btnCr = document.getElementById({ cr: "btn-pf-cr", registro: "btn-pf-reg", ac: "btn-pf-ac" }[modo])
    || { style: {} }; // "cadastro" não tem botão na tela do popup

  const tabId = await abaPfAtual();
  if (!tabId) {
    statusEl.textContent = "⚠️ Aba da PF não encontrada.";
    statusEl.className = "erro";
    return;
  }
  // Já tem um preenchimento esperando o usuário nessa aba: não começa outro por cima
  const estado = await lerEstadoPf(tabId);
  if (estado?.rodando) { acompanhar(tabId, estado.modo || modo, null, null); return; }

  // Cliente do sistema: busca de novo os dados e os documentos logo antes de preencher. Escolhido antes (o menu do
  // portal guarda o último), ele ficava com o que havia no site naquela hora: documento trocado depois no site ia o
  // arquivo antigo para o portal ("... - Outros.pdf" no lugar do novo). Arquivos escolhidos de uma pasta local ficam
  if (clienteSelecionado?.id) {
    statusEl.textContent = "⏳ Atualizando os dados do cliente…";
    statusEl.className = "ok";
    await carregarClientesSistema();
    const atual = clientesSistema.find(c => c.id === clienteSelecionado.id);
    const docsDoSistema = !arquivosCr.length || arquivosCr.every(a => a.tipo);
    if (atual && docsDoSistema && modo !== "cadastro" && modo !== "sisgcorp") await selecionarClienteSistema(atual);
    else if (atual) clienteSelecionado = { ...atual, genero: atual.genero || clienteSelecionado.genero };
  }
  // NUNCA documento de outra pessoa (o usuário: "não pode acontecer"): com cliente do sistema, só os documentos baixados
  // do cadastro DELE (marcados com o id dele); arquivos de uma pasta local só valem quando não há cliente do sistema
  const arquivos = modo === "ac" && !clienteSelecionado?.id ? arquivosAc
    : clienteSelecionado?.id ? arquivosCr.filter(a => a.cliente === clienteSelecionado.id) : arquivosCr;
  if (clienteSelecionado?.id && arquivosCr.some(a => a.cliente !== clienteSelecionado.id)) {
    console.warn("[Passarinho] documentos de outro cliente ignorados:", arquivosCr.filter(a => a.cliente !== clienteSelecionado.id).length);
  }

  statusEl.textContent = "⏳ Preenchendo…";
  statusEl.className = "ok";
  btnCr.disabled = true;
  btnCr.style.opacity = "0.5";
  esconderPausa();

  if (modo !== "ac" && arquivosCr.length > 0) mostrarPreviewCr();
  document.getElementById("pf-resultado").style.display = "none";

  const reabilitar = () => { btnCr.disabled = false; btnCr.style.opacity = ""; };

  try {
    if (clienteSelecionado && !clienteSelecionado.genero) {
      const g = await detectarGeneroNome(clienteSelecionado.nome);
      if (g) clienteSelecionado.genero = g;
    }
    if (clienteSelecionado?.id && clientesSistema.length > 0) {
      const fresh = clientesSistema.find(c => c.id === clienteSelecionado.id);
      if (fresh) clienteSelecionado = { ...fresh, genero: fresh.genero || clienteSelecionado.genero };
    }
    const tabInfo = await chrome.tabs.get(tabId);
    // Conta gov aberta é de outra pessoa (nome do Sinarm CAC / Portal PF diferente do cliente escolhido): para tudo,
    // para não preencher o processo de alguém com os dados de outro cliente
    if (clienteSelecionado?.nome) {
      const nomeNaPagina = await chrome.scripting.executeScript({
        target: { tabId }, func: () => (document.querySelector(".profile-name, .user-info-name")?.textContent || "").trim(),
      }).then(r => r?.[0]?.result || "").catch(() => "");
      if (nomeNaPagina && !mesmoNome(nomeNaPagina, clienteSelecionado.nome)) {
        reabilitar();
        statusEl.textContent = `⛔ Cliente errado: a conta aberta é de ${nomeNaPagina.toUpperCase()}, mas o cliente escolhido é ${String(clienteSelecionado.nome).toUpperCase()}. Nada foi preenchido. Troque o cliente ou entre na conta certa.`;
        statusEl.className = "erro";
        return;
      }
    }
    const isNovoPortal = tabInfo.url?.includes("portal.pf.gov.br");
    // SisGCorp (Exército): só o "Cadastro inicial SisGCorp", com o preenchimento próprio de lá
    const isSisgcorp = tabInfo.url?.includes("sisgcorp.eb.mil.br");
    // Sinarm CAC (servicos.pf.gov.br): GT – Guia de Tráfego, com o evento escolhido no menu (variante = evento em JSON)
    if (modo === "gt") {
      reabilitar();
      if (!tabInfo.url?.includes("servicos.pf.gov.br")) {
        statusEl.textContent = "⚠️ Abra o Sinarm CAC (servicos.pf.gov.br) nesta aba para o GT.";
        statusEl.className = "erro";
        return;
      }
      let evento = null;
      try { evento = JSON.parse(variante || "null"); } catch (_) {}
      // documento de identificação da ficha do cliente (tipo "doc_ident" em Clientes Armas)
      const ident = arquivosCr.find(a => a.tipo === "doc_ident" && a.cliente === clienteSelecionado?.id) || null;
      const injGt = chrome.scripting.executeScript({
        target: { tabId }, world: "MAIN", func: injectarSinarmGt, args: [clienteSelecionado, evento, ident],
      }).then(r => r?.[0]?.result);
      acompanhar(tabId, modo, injGt, reabilitar);
      return;
    }
    if (modo === "sisgcorp" || isSisgcorp) {
      if (modo !== "sisgcorp" || !isSisgcorp) {
        reabilitar();
        statusEl.textContent = modo === "sisgcorp" ? "⚠️ Abra o SisGCorp (sisgcorp.eb.mil.br) nesta aba." : "⚠️ No SisGCorp use \"Cadastro inicial SisGCorp\".";
        statusEl.className = "erro";
        return;
      }
      // Latitude/longitude pelo Google Maps (o usuário pediu): abre o endereço numa aba escondida e lê o pino
      statusEl.textContent = "⏳ Buscando a localização no Google Maps…";
      const coords = await coordenadasGoogleMaps(clienteSelecionado, tabInfo.windowId);
      statusEl.textContent = "⏳ Preenchendo…";
      const injSisg = chrome.scripting.executeScript({
        target: { tabId }, world: "MAIN", func: injectarSisgcorp, args: [clienteSelecionado, coords],
      }).then(r => r?.[0]?.result);
      acompanhar(tabId, modo, injSisg, reabilitar);
      return;
    }
    if ((modo === "registro" || modo === "cadastro") && !isNovoPortal) {
      reabilitar();
      statusEl.textContent = `⚠️ ${modo === "cadastro" ? "Cadastro inicial" : "Registrar Arma"} só funciona no portal novo (portal.pf.gov.br).`;
      statusEl.className = "erro";
      return;
    }

    // Fire-and-forget: não bloqueia o popup → permite pausas interativas
    const injecao = chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: isNovoPortal ? injectarPortalPf : injectarPf,
      args: isNovoPortal ? [clienteSelecionado, arquivos, modo, variante] : (modo === "ac" ? [arquivosAc, "ac"] : [arquivos]),
    }).then(r => r?.[0]?.result);
    acompanhar(tabId, modo, injecao, reabilitar);

  } catch (e) {
    reabilitar();
    statusEl.textContent = `Erro: ${e.message}`;
    statusEl.className = "erro";
  }
}

// Estado do preenchimento guardado na própria aba da PF
async function lerEstadoPf(tabId) {
  try {
    const r = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => ({
        // rodando de verdade: o CR marca a hora a cada meio segundo; marca velha (mais de 8 s) = preenchimento morto,
        // que antes deixava o menu em "Preenchendo…" para sempre e não deixava começar outro
        rodando: !!window.__passarinho_rodando && !(window.__passarinho_vivo && Date.now() - window.__passarinho_vivo > 8000),
        passo: window.__passarinho_passo || "",
        esperando: !!window.__passarinho_waiting,
        pausado: !!window.__passarinho_pausado,
        desc: window.__passarinho_step_desc || "",
        modo: window.__passarinho_modo || "",
        resultado: window.__passarinho_resultado || null,
      }),
    });
    return r?.[0]?.result || null;
  } catch (_) { return null; }
}

// Acompanha o preenchimento: mostra a pausa "▶ Continuar" e o resultado no fim.
// Funciona também com o popup reaberto no meio (ele fecha quando o usuário clica na página).
// Acompanhamento em andamento: o ⏹ Parar encerra na hora (sem esperar o preenchimento perceber)
let acompanhamentoAtual = null;
function acompanhar(tabId, modo, injecao, aoTerminar) {
  const statusEl = document.getElementById("pf-status");
  let terminou = false, timer = null;
  acompanhamentoAtual?.cancelar();
  acompanhamentoAtual = {
    cancelar: () => {
      if (terminou) return;
      terminou = true;
      clearInterval(timer);
      esconderPausa();
      mostrarControles(false);
      if (aoTerminar) aoTerminar();
    },
  };
  const fim = (res, erro) => {
    if (terminou) return;
    terminou = true;
    clearInterval(timer);
    esconderPausa();
    mostrarControles(false);
    if (res?.parado) { if (aoTerminar) aoTerminar(); statusEl.textContent = "⏹ Parado. Clique de novo para começar do início."; statusEl.className = "erro"; return; }
    if (aoTerminar) aoTerminar();
    if (erro) { statusEl.textContent = `Erro: ${erro}`; statusEl.className = "erro"; return; }
    const n = typeof res === "object" ? (res?.n || 0) : (res || 0);
    const slots = typeof res === "object" ? (res?.slots || null) : null;
    statusEl.textContent = n > 0 ? `✓ ${n} campo(s) preenchido(s)` : `⚠️ Campos não encontrados.`;
    statusEl.className = n > 0 ? "ok" : "erro";
    if (slots && modo !== "ac") mostrarResultadoCr(slots);
    // O preenchimento parou de propósito: mostra o motivo
    // (res.ok: deu tudo certo, a mensagem é só informativa, em verde — ex.: "GRU gerada")
    if (res?.msg) { statusEl.textContent = `${res.ok ? "✓" : "⚠️"} ${res.msg}`; statusEl.className = res.ok ? "ok" : "erro"; }
  };
  if (injecao) injecao.then(r => fim(r), e => fim(null, e.message));
  timer = setInterval(async () => {
    const est = await lerEstadoPf(tabId);
    if (!est || terminou) return;
    mostrarControles(est.rodando, est.pausado);
    if (est.pausado) {
      statusEl.textContent = "⏸ Pausado — clique ▶ Retomar para continuar";
      statusEl.className = "ok";
    } else if (est.esperando) {
      mostrarPausa(est.desc || "Aguardando…");
      statusEl.textContent = "⏸ Aguardando você…";
      statusEl.className = "ok";
    } else if (est.rodando) {
      if (document.getElementById("pf-pausa").style.display !== "none") esconderPausa();
      statusEl.textContent = "⏳ Preenchendo…" + (est.passo ? ` (${est.passo})` : "");
      statusEl.className = "ok";
    } else if (!injecao) {
      fim(est.resultado); // popup reaberto: terminou enquanto ele estava fechado
    }
  }, 700);
}

// Popup reaberto com um preenchimento em andamento na aba da PF → volta a acompanhar
async function retomarAcompanhamento() {
  if (!pfTabId) return;
  const est = await lerEstadoPf(pfTabId);
  if (!est?.rodando) return;
  mostrarPf();
  acompanhar(pfTabId, est.modo, null, null);
}

async function injectarPortalPf(cliente, arquivos, modo = "cr", variante = "") { try {
  // Estado para o popup acompanhar: ele fecha quando o usuário clica na página e pode ser reaberto
  window.__passarinho_rodando = true;
  window.__passarinho_resultado = null;
  window.__passarinho_waiting = false;
  window.__passarinho_modo = modo;
  // Botões ⏸ Pausar / ⏹ Parar da extensão: o preenchimento confere isso em toda espera
  window.__passarinho_pausado = false;
  window.__passarinho_parar = false;
  // identificação deste preenchimento: ⏹ Parar (ou um preenchimento novo) a troca, e este para de mexer na página
  var meuExec = Math.random().toString(36).slice(2);
  window.__passarinho_exec = meuExec;
  const encerrar = r => { if (window.__passarinho_exec !== meuExec) return r; window.__passarinho_resultado = r; window.__passarinho_rodando = false; return r; };

  // ── Esconde erros vermelhos do Angular durante todo o preenchimento ─────
  // Detecta qualquer elemento com cor vermelha via getComputedStyle (funciona
  // independente do nome de classe que o portal usar) e seta inline style !important,
  // que sempre ganha de qualquer CSS externo incluindo Angular component styles
  function __phIsRed(color) {
    if (!color) return false;
    const m = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (!m) return false;
    return +m[1] > 160 && +m[2] < 90 && +m[3] < 100; // R alto, G e B baixos = vermelho/danger
  }
  window.__passarinho_hiding = true;
  const __phInterval = setInterval(() => {
    if (!window.__passarinho_hiding) { clearInterval(__phInterval); return; }
    try {
      // Esconde elementos de erro por classe (inline style !important vence qualquer CSS)
      document.querySelectorAll(
        '.p-error,.p-message,.p-messages,.p-inline-message,small.p-error,' +
        '.ng-invalid .p-error,.ng-invalid .p-message'
      ).forEach(el => { el.style.setProperty('display', 'none', 'important'); el.dataset.phEsc = "1"; });
      // Scan visual: busca qualquer elemento com borda ou texto vermelhos
      const root = document.querySelector('app-root,main,[role="main"]') || document.body;
      root.querySelectorAll('div,label,span,p,li,small,button,input,p-dropdown,p-select,p-fileupload').forEach(el => {
        const cs = getComputedStyle(el);
        if (__phIsRed(cs.borderLeftColor) || __phIsRed(cs.borderColor) || __phIsRed(cs.borderTopColor)) {
          el.style.setProperty('border-left', 'none', 'important');
          el.style.setProperty('border-left-color', 'transparent', 'important');
          el.style.setProperty('border-color', 'transparent', 'important');
          el.style.setProperty('box-shadow', 'none', 'important');
          el.dataset.phEsc = "1";
        }
        if (__phIsRed(cs.color)) { el.style.setProperty('color', 'inherit', 'important'); el.dataset.phEsc = "1"; }
      });
    } catch(e) {}
  }, 40);

  // Para de esconder os erros do site e desfaz só o que a extensão mudou
  function pararDeEsconderErros() {
    window.__passarinho_hiding = false;
    document.getElementById("__passarinho_hide_err")?.remove();
    document.querySelectorAll("[data-ph-esc]").forEach(el => {
      ["border", "border-left", "border-left-color", "border-color", "box-shadow", "outline", "color", "display"]
        .forEach(p => el.style.removeProperty(p));
      delete el.dataset.phEsc;
    });
  }

  // Parar: interrompe na hora (cai no catch do fim). Pausar: fica parado aqui até Retomar (ou Parar).
  // Devolve quanto tempo ficou pausado, para as esperas não estourarem o prazo por causa da pausa.
  async function checarPausa() {
    if (window.__passarinho_parar || window.__passarinho_exec !== meuExec) throw new Error("__passarinho_parado__");
    const ini = Date.now();
    while (window.__passarinho_pausado) {
      await new Promise(r => setTimeout(r, 300));
      if (window.__passarinho_parar || window.__passarinho_exec !== meuExec) throw new Error("__passarinho_parado__");
    }
    return Date.now() - ini;
  }
  async function delay(ms) { await checarPausa(); await new Promise(r => setTimeout(r, ms)); await checarPausa(); }
  function norm(s) { return (s||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase(); }

  async function aguardarEl(pred, ms = 5000) {
    let fim = Date.now() + ms;
    while (Date.now() < fim) {
      fim += await checarPausa();
      const el = pred(); if (el) return el;
      await new Promise(r => setTimeout(r, 150));
    }
    return null;
  }

  // "Nome social" nunca é preenchido: o cliente já tem o nome
  // (a busca do nome do pai caía nesse campo)
  function ehNomeSocial(el) {
    const a = [el.placeholder, el.getAttribute("aria-label"), el.name, el.id, el.getAttribute("formcontrolname")].join(" ").toLowerCase();
    if (a.includes("social")) return true;
    // Sobe até o bloco do campo (só este input dentro) e confere o rótulo
    let p = el.parentElement;
    for (let i = 0; i < 4 && p && p !== document.body; i++, p = p.parentElement) {
      if (p.querySelectorAll("input:not([type=hidden]),textarea").length > 1) break;
      const lbl = p.querySelector("label,mat-label");
      if (lbl) return norm(lbl.textContent).replace(/\*/g, "").trim() === "nome social";
    }
    return false;
  }

  function setInput(el, valor) {
    if (!el || !valor || ehNomeSocial(el)) return false;
    el.focus();
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set
                || Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
    try { setter ? setter.call(el, valor) : (el.value = valor); } catch { el.value = valor; }
    ["input","change","blur"].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
    return true;
  }

  function acharInput(chaves) {
    for (const k of chaves) {
      for (const el of document.querySelectorAll("input:not([type=hidden]),textarea")) {
        const attrs = [el.placeholder, el.getAttribute("aria-label"), el.name, el.id, el.getAttribute("formcontrolname")].join(" ").toLowerCase();
        if (attrs.includes(k)) return el;
      }
      for (const el of document.querySelectorAll("input:not([type=hidden]),textarea")) {
        const lbl = el.closest("div,mat-form-field,label,p-floatlabel")?.querySelector("label,mat-label,span,legend");
        if (lbl && norm(lbl.textContent).includes(k)) return el;
      }
    }
    return null;
  }

  function acharSelect(chaves) {
    for (const k of chaves) {
      for (const el of document.querySelectorAll("select")) {
        const fc = el.getAttribute("formcontrolname") || el.name || el.id || "";
        if (fc.toLowerCase().includes(k)) return el;
      }
      for (const el of document.querySelectorAll("select")) {
        const lbl = el.closest("div,mat-form-field,p-floatlabel")?.querySelector("label,mat-label,span,legend");
        if (lbl && norm(lbl.textContent).includes(k)) return el;
      }
    }
    return null;
  }

  function setSelectOpt(el, valor) {
    if (!el || !valor) return false;
    const v = norm(valor);
    const opt = [...el.options].find(o => norm(o.text).includes(v) || norm(o.value).includes(v));
    if (!opt) return false;
    el.value = opt.value;
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  // Helper unificado: tenta <select> nativo, depois mat-select / p-dropdown
  async function preencherDropdown(chaves, valor) {
    if (!valor) return false;
    const v = norm(valor);
    // 1) Native select
    const sel = acharSelect(chaves);
    if (sel && setSelectOpt(sel, valor)) return true;
    // 2) mat-select / combobox
    const allMS = [...document.querySelectorAll("mat-select,[role='combobox'],p-dropdown")];
    const matSel = allMS.find(el => {
      const fc = norm(el.getAttribute("formcontrolname")||el.getAttribute("ng-reflect-name")||el.getAttribute("aria-label")||"");
      return chaves.some(k => fc.includes(k));
    }) || allMS.find(el => {
      const lbl = el.closest("mat-form-field,div,label,p-floatlabel")?.querySelector("label,mat-label,span,legend");
      return lbl && chaves.some(k => norm(lbl.textContent).includes(k));
    });
    if (!matSel) return false;
    const trigger = matSel.querySelector(".mat-select-trigger,mat-select-trigger") || matSel;
    trigger.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    trigger.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true, view: window }));
    trigger.click();
    const opt = await aguardarEl(() =>
      [...document.querySelectorAll("mat-option,.p-dropdown-item,[role='option']")].find(o => {
        const t = norm(o.textContent.trim());
        if (v.length <= 3) return t === v || t.startsWith(v + " ") || t.endsWith(" " + v) || t.includes("(" + v + ")");
        return t.includes(v);
      }), 3000);
    if (opt) { opt.click(); await delay(400); return true; }
    document.body.dispatchEvent(new MouseEvent("click", { bubbles: true })); // fecha painel
    return false;
  }

  let n = 0, dbg = "";
  // passo atual para o menu mostrar enquanto preenche (2026-11-25: o CR ficou em "Preenchendo…" sem sair do lugar e
  // não dava para saber onde parou). Também marca a hora: preenchimento que parou de dar sinal não trava os próximos
  const __phPasso = setInterval(() => {
    if (window.__passarinho_exec !== meuExec || !window.__passarinho_rodando) { clearInterval(__phPasso); return; }
    window.__passarinho_passo = dbg.slice(-60);
    window.__passarinho_vivo = Date.now();
  }, 500);
  window.__passarinho_vivo = Date.now();
  // Se o site não faz o que se espera, para tudo e mostra o motivo no popup
  // (em vez de seguir clicando na tela errada)
  let erroFluxo = "";
  function parar(motivo) {
    pararDeEsconderErros();
    return encerrar({ n, dbg, msg: motivo });
  }
  function avisoDoSite(seletor) {
    const el = document.querySelector(seletor);
    return el ? el.textContent.replace(/\s+/g, " ").trim() : "";
  }
  // Janela aberta de verdade: o portal PF tem um menu lateral ESCONDIDO com aria-modal="true"
  // em todas as telas, então só vale elemento visível (a janela "Editar dados pessoais" primeiro)
  function janelaAberta() {
    return [...document.querySelectorAll(".editar-dados-dialog,mat-dialog-container,[role='dialog'],[aria-modal='true'],.p-dialog,app-editar-dados,app-dados-pessoais-form")]
      .find(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }) || null;
  }

  // Detecta ponto de entrada: pula navegação se já está na página de upload de documentos
  // (input[type='file'] só existe na página de documentos, nunca no formulário de dados)
  const pularNav = document.querySelectorAll("input[type='file']").length > 0;
  dbg += pularNav ? "jump_docs>" : "";
  if (modo === "cadastro" && pularNav)
    return parar("Volte para a página inicial do Portal PF (Minhas solicitações) para fazer o Cadastro inicial.");
  // "Preencher documentos" (menu do portal): só anexa os documentos do cliente, na tela de Documentos já aberta
  if (modo === "documentos" && !pularNav)
    return parar("Abra a tela de Documentos da solicitação na PF e clique de novo em \"Preencher documentos\".");

  // ── PASSO 1: Iniciar nova solicitação (se na página principal) ───────────
  // Só conta o que é do PORTAL e está na tela (2026-11-25): outra extensão instalada ("Sinarm CAC – Assistente") põe
  // na página botões/textos escondidos; o "Continuar"/"Armas" dela fazia a Passarinho achar que já tinha passado da
  // tela inicial, pular o "Iniciar nova solicitação" e ficar parada (arm_nf)
  const doPortal = el => {
    const raiz = document.querySelector("app-root");
    if (raiz && !raiz.contains(el)) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const jaNoArmas = () => [...document.querySelectorAll("button,a,mat-card,div,span")]
    .some(el => { const t = el.textContent.trim(); return t.length < 20 && norm(t).includes("arma") && doPortal(el); });
  const jaNoStep1 = () => [...document.querySelectorAll("button")]
    .some(b => norm(b.textContent.trim()).includes("continuar") && doPortal(b));

  if (!jaNoStep1() && !jaNoArmas()) {
    const btnIniciar = await aguardarEl(() =>
      [...document.querySelectorAll("button,a")]
        .find(el => norm(el.textContent).includes("iniciar nova")), 5000);
    if (btnIniciar) { btnIniciar.click(); dbg += "ini>"; await delay(2500); }
  }

  // ── PASSO 2: Clicar card "Armas" ────────────────────────────────────────
  if (!jaNoStep1()) {
    const armasEl = await aguardarEl(() =>
      [...document.querySelectorAll("p,span,strong,h3,h4")]
        .find(el => norm(el.textContent.trim()) === "armas" && doPortal(el)), 8000);

    if (armasEl) {
      // Sobe até encontrar um <a> ou div clicável (card do Angular)
      let alvo = armasEl;
      for (let i = 0; i < 5; i++) {
        if (!alvo.parentElement) break;
        alvo = alvo.parentElement;
        if (alvo.tagName === "A" || alvo.onclick || alvo.getAttribute("routerlink") !== null ||
            alvo.getAttribute("ng-reflect-router-link") !== null ||
            (alvo.className && /card|item|categ|click/i.test(alvo.className))) break;
      }
      // Tenta clicar o <a> interno se existir
      const linkInterno = alvo.querySelector("a") || armasEl.closest("a");
      const alvoFinal = linkInterno || alvo;
      alvoFinal.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
      alvoFinal.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
      alvoFinal.dispatchEvent(new MouseEvent("click",     { bubbles: true, cancelable: true }));
      alvoFinal.click();
      dbg += "arm>";
    } else { dbg += "arm_nf>"; }

    const step1ok = await aguardarEl(() =>
      [...document.querySelectorAll("button")].find(el => norm(el.textContent.trim()).includes("continuar") && doPortal(el)), 10000);
    dbg += step1ok ? "step1>" : "step1_nf>";

    // ── PASSO 2.5: Selecionar tipo de serviço ────────────────────────────────
    // Só executa se step1ok é null — portal está na tela de seleção de serviço.
    // Se step1ok achou "continuar", o portal já foi direto ao formulário de dados;
    // rodar aqui clicaria o título/breadcrumb "Autorização" no próprio formulário.
    // O Cadastro inicial não escolhe serviço (só edita os dados pessoais)
    if (!step1ok && modo !== "cadastro") {
      const txtSrv = modo === "ac" ? "autoriza" : modo === "registro" ? "registrar" : "concess";
      const srvEl = await aguardarEl(() => {
        // Guarda adicional: se "continuar" aparecer durante a busca, para imediatamente
        if ([...document.querySelectorAll("button")].some(b => norm(b.textContent.trim()).includes("continuar") && doPortal(b)))
          return null;
        return [...document.querySelectorAll("button,mat-card,mat-card-title,div[role='button'],a")]
          .find(el => {
            const t = norm(el.textContent.trim());
            return t.length > 5 && t.length < 100 && t.includes(txtSrv);
          });
      }, 5000);
      if (srvEl) {
        srvEl.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
        srvEl.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
        srvEl.click();
        dbg += `srv(${modo})>`; await delay(1200);
      } else { dbg += `srv(${modo})_nf>`; }
    }

    await delay(800);
  }

  if (!pularNav) { // ── PASSOS 3-9: navegação e dados pessoais ──────────────

  // ── PASSO 3: Verificar dados pessoais → clicar "Editar Dados" ───────────
  // Conta inputs VISÍVEIS antes de clicar para detectar novos depois
  const contarVisíveis = () => [...document.querySelectorAll("input:not([type=hidden]),mat-select,[role='combobox']")]
    .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }).length;
  const inputsAntes = contarVisíveis();
  // Já está na tela do Formulário (o serviço foi escolhido antes): continua dali, sem Editar Dados,
  // sem escolher serviço e sem a pausa da Etapa 1; só para no fim, para conferir o formulário
  const jaNoFormulario = modo !== "cadastro" && location.href.includes("formulario");
  // Registrar Arma não clica "Editar Dados": o portal abre o modal depois do primeiro Continuar
  const btnEditar = (modo === "registro" || jaNoFormulario) ? null : await aguardarEl(() =>
    // Busca botão primeiro, depois outros elementos
    [...document.querySelectorAll("button")]
      .find(el => { const t = norm(el.textContent.trim()); return t.length < 35 && t.includes("editar dado"); }) ||
    [...document.querySelectorAll("a,span,div")]
      .find(el => { const t = norm(el.textContent.trim()); return t === "editar dados" || t === "editar"; }), 1500);
  if (btnEditar) {
    btnEditar.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    btnEditar.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
    btnEditar.dispatchEvent(new MouseEvent("click",     { bubbles: true, cancelable: true }));
    btnEditar.click();
    dbg += "edit(" + inputsAntes + ")>"; await delay(2000);
    dbg += "after(" + contarVisíveis() + ")>";
  } else if (modo !== "registro" && !jaNoFormulario) { dbg += "edit_nf>"; }

  // ── Helpers label→input/dropdown (usados em PASSO 4 e PASSO 8) ───────────
  function parentCom(lbl, seletor, maxDepth = 10) {
    let el = lbl.parentElement;
    for (let i = 0; i < maxDepth && el && el !== document.body; i++, el = el.parentElement) {
      if (el.querySelector(seletor)) return el;
    }
    return null;
  }
  function inputPorLabel(textos) {
    for (const texto of textos) {
      const t = norm(texto);
      for (const el of document.querySelectorAll("input:not([type=hidden])")) {
        const a = [el.getAttribute("formcontrolname"),el.name,el.id,el.placeholder,el.getAttribute("aria-label")].join(" ").replace(/ /g,"").toLowerCase();
        if (a.includes(t.replace(/ /g,""))) return el;
      }
      for (const lbl of document.querySelectorAll("label,mat-label,span,legend")) {
        if (!norm(lbl.textContent.trim()).includes(t)) continue;
        const parent = parentCom(lbl, "input:not([type=hidden]):not([type=checkbox]):not([type=radio])");
        if (!parent) continue;
        const inp = parent.querySelector("input:not([type=hidden]):not([type=checkbox]):not([type=radio])");
        if (inp) return inp;
      }
    }
    return null;
  }
  async function dropdownPorLabel(textos, valor, exato = false) {
    const v = norm(valor);
    for (const texto of textos) {
      const t = norm(texto);
      for (const lbl of document.querySelectorAll("label,mat-label,span,legend")) {
        const lblT = norm(lbl.textContent.trim());
        const match = exato
          ? (lblT === t || lblT === t + " *" || lblT === "* " + t || lblT === t + " " || lblT.replace(/\s*\*$/, "").trim() === t)
          : lblT.includes(t);
        if (!match) continue;
        const dropSel = "select,mat-select,p-dropdown,[role='combobox'],[role='listbox']";
        const parent = parentCom(lbl, dropSel);
        if (!parent) continue;
        const sel = parent.querySelector("select");
        if (sel && setSelectOpt(sel, valor)) return true;
        const matSel = parent.querySelector("mat-select,p-dropdown,[role='combobox']");
        if (matSel) {
          const trigger = matSel.querySelector(".mat-select-trigger,mat-select-trigger,.p-dropdown-trigger,.p-dropdown-label") || matSel;
          trigger.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
          trigger.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true, view: window }));
          trigger.click();
          const opt = await aguardarEl(() =>
            [...document.querySelectorAll("mat-option,.p-dropdown-item,[role='option']")].find(o => {
              const txt = norm(o.textContent.trim());
              if (v.length <= 3) return txt === v || txt.startsWith(v + " ") || txt.endsWith(" " + v) || txt.includes("(" + v + ")");
              return txt.includes(v);
            }), 3000);
          if (opt) { opt.click(); await delay(400); return true; }
          document.body.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        }
      }
    }
    return false;
  }

  // ── Dropdowns do PrimeNG no portal PF ──────────────────────────────────────
  // O id do campo fica no span do dropdown; a lista de opções abre no <body>
  const caixaPorId = id => () => document.getElementById(id)?.closest(".p-dropdown") || null;
  function textoEscolhido(caixa) {
    const t = (caixa?.querySelector(".p-dropdown-label")?.textContent || "").trim();
    return /^selecione/i.test(t) ? "" : t;
  }
  async function escolherNoDropdown(acharCaixa, valor) {
    if (!valor || !acharCaixa()) return false;
    const v = norm(valor);
    const casa = t => t === v || t.startsWith(v + " ") || (v.length > 3 && t.includes(v));
    // Espera o campo liberar (o site trava o campo enquanto carrega as opções)
    const caixa = await aguardarEl(() => { const c = acharCaixa(); return c && !c.classList.contains("p-disabled") ? c : null; }, 10000);
    if (!caixa) return false;
    if (casa(norm(textoEscolhido(caixa)))) return true; // já está escolhido
    (caixa.querySelector(".p-dropdown-label") || caixa).click();
    const opt = await aguardarEl(() => {
      const itens = [...document.querySelectorAll(".p-dropdown-panel [role='option'], .p-dropdown-panel .p-dropdown-item")]
        .map(o => ({ o, t: norm(o.textContent.trim()) }));
      const achou = itens.find(x => x.t === v) || itens.find(x => x.t.startsWith(v + " ")) ||
        (v.length > 3 && itens.find(x => x.t.includes(v)));
      return achou ? achou.o : null;
    }, 4000);
    if (!opt) { document.body.click(); return false; } // fecha a lista
    opt.click();
    await delay(500);
    return casa(norm(textoEscolhido(acharCaixa())));
  }

  // ── PASSO 4 & 5: Preencher modal e Salvar ───────────────────────────────
  async function preencherModal() {
    // Aguarda o form de edição abrir: mais inputs que antes, ou mat-dialog, ou dialog role,
    // ou portal já foi direto ao formulário completo (nova versão: qtd >= 8 sem modal)
    const formAberto = await aguardarEl(() => {
      const qtd = contarVisíveis();
      if (qtd > inputsAntes) return document.querySelector("input:not([type=hidden])");
      const dialog = janelaAberta();
      if (dialog && dialog.querySelector("input")) return dialog.querySelector("input");
      if (qtd >= 8) return document.querySelector("input:not([type=hidden])");
      return null;
    }, 6000);
    dbg += "vis(" + contarVisíveis() + "/" + inputsAntes + ")>";
    if (!formAberto) { dbg += "form_nf>"; return false; }
    await delay(500);
    dbg += "modal>";

    if (cliente) {
      // Data de nascimento: o portal (versão 0.3.52) passou a pedir na janela "Editar dados pessoais" (antes vinha
      // pronta, só leitura). Campo "dd/mm/aaaa" com máscara: escreve a data inteira; se o campo não guardar, digita
      // número por número, como uma pessoa. Confere no fim.
      if (cliente.data_nascimento) {
        const [ano, mes, dia] = String(cliente.data_nascimento).split("T")[0].split("-");
        const dataBr = `${dia}/${mes}/${ano}`;
        const raiz = janelaAberta() || document;
        const nascEl = [...raiz.querySelectorAll("input:not([type=hidden])")].find(el => {
          if (el.readOnly || el.disabled || !el.getClientRects().length) return false;
          if (/dd\/mm\/aaaa/i.test(el.placeholder || "")) return true;
          const lbl = el.closest("div,mat-form-field,label,p-floatlabel")?.querySelector("label,mat-label,span,legend");
          return lbl && /nascimento/.test(norm(lbl.textContent));
        });
        if (nascEl && !/\d{2}\/\d{2}\/\d{4}/.test(nascEl.value || "")) {
          setInput(nascEl, dataBr);
          await delay(300);
          if (!/\d{2}\/\d{2}\/\d{4}/.test(nascEl.value || "")) {
            // digitando: cada número com as teclas e o "input" que a máscara espera
            nascEl.focus();
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
            setter.call(nascEl, "");
            nascEl.dispatchEvent(new Event("input", { bubbles: true }));
            for (const ch of dia + mes + ano) {
              nascEl.dispatchEvent(new KeyboardEvent("keydown", { key: ch, bubbles: true }));
              nascEl.dispatchEvent(new KeyboardEvent("keypress", { key: ch, bubbles: true }));
              setter.call(nascEl, (nascEl.value || "") + ch);
              nascEl.dispatchEvent(new InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" }));
              nascEl.dispatchEvent(new KeyboardEvent("keyup", { key: ch, bubbles: true }));
              await delay(40);
            }
            nascEl.dispatchEvent(new Event("change", { bubbles: true }));
            nascEl.dispatchEvent(new Event("blur", { bubbles: true }));
            await delay(300);
          }
          const v = (nascEl.value || "").replace(/\D/g, "");
          if (v === dia + mes + ano) { n++; dbg += "nasc>"; } else dbg += "nasc_nf(" + (nascEl.value || "vazio") + ")>";
        }
      }

      // Nome da mãe
      const maeEl = acharInput(["mae","genitora","nome da mae"]);
      if (maeEl && cliente.nome_mae) { setInput(maeEl, (cliente.nome_mae||"").toUpperCase()); n++; }

      // Gênero — usa valor detectado antes ou fallback por lista de nomes
      const masc = ["joao","jose","carlos","paulo","pedro","marcos","lucas","andre","diego","felipe",
        "igor","thiago","guilherme","leandro","rodrigo","henrique","gustavo","leonardo","antonio",
        "eduardo","fernando","francisco","jorge","luis","luiz","marcelo","mario","miguel","renato",
        "roberto","sergio","tiago","william","gabriel","rafael","daniel","vinicius","mateus","jonas",
        "ruan","ryan","victor","samuel","arthur","murilo","alex","alan","ivan","caio",
        "renan","erick","eric","alisson","anderson","adriano","claudio","rogerio","vagner","wagner",
        "nilton","wilson","geraldo","arnaldo","sebastiao","benedito","nelson","davi","enzo","nicolas",
        "ramon","raimundo","manoel","manuel","walisson","wallisson","emerson","everson","edson",
        "elton","elvis","euler","evandro","ezequiel","fabio","fabricio","flavio","geovani","giovanni",
        "helder","helton","helio","heitor","hugo","ilton","iran","jair","jamison","jeferson",
        "jefferson","jeovani","joas","jonatas","jonatan","jonathan","junior","kelvin","laercio",
        "lazaro","lenilson","luan","maicon","marcio","mauro","maycon","messias","moises",
        "natanael","neilton","neto","newton","nilson","noaldo","odair","orlandino","orlando",
        "otavio","patricio","rene","renilson","robson","rogerio","romulo","ronaldo","ronilson",
        "rosivaldo","salomao","sidnei","sidney","silvio","sirlei","tercio","thales","thyago",
        "walmir","wander","wanderley","warley","wellington","weslley","wesley","wilian"];
      const prNome = norm((cliente.nome||"").split(" ")[0]);
      // Se API detectou → usa; senão, masculino se nome na lista, feminino caso contrário
      const generoFinal = cliente.genero || (masc.includes(prNome) ? "masculino" : "feminino");
      if (generoFinal) {
        if (await escolherNoDropdown(caixaPorId("genero"), generoFinal)) { n++; dbg += "gen>"; }
        else if (await preencherDropdown(["genero","gender","sexo"], generoFinal)) { n++; dbg += "gen2>"; }
        else dbg += "gen_nf>";
      }

      // Nacionalidade
      const nacEl = acharInput(["nacional"]);
      if (nacEl && !nacEl.value) { setInput(nacEl, "Brasileira"); n++; }

      // CEP — preenche primeiro: o site busca o endereço e escolhe UF e Município sozinho
      const cepEl = acharInput(["cep","00000-000"]);
      if (cepEl && cliente.cep) {
        const c = (cliente.cep||"").replace(/\D/g,"");
        setInput(cepEl, c.length === 8 ? c.slice(0,5)+"-"+c.slice(5) : c);
        n++; dbg += "cep>";
        cepEl.dispatchEvent(new Event("blur",{bubbles:true}));
        await delay(800);
        // Espera a busca do CEP (o campo fica travado enquanto busca) e a lista de municípios carregar
        await aguardarEl(() => !cepEl.disabled ? true : null, 10000);
        await aguardarEl(() => {
          const mun = caixaPorId("cidade")();
          return !mun || !mun.classList.contains("p-disabled") || !textoEscolhido(caixaPorId("uf")()) ? true : null;
        }, 10000);
        dbg += "cepok>";
      }

      // UF residencial — pelo id do campo; senão, match EXATO no label "UF" para não pegar "UF do documento"
      if (cliente.estado) {
        if (await escolherNoDropdown(caixaPorId("uf"), cliente.estado)) { n++; dbg += "uf>"; }
        else if (await dropdownPorLabel(["uf"], cliente.estado, true)) { n++; dbg += "uf2>"; await delay(1000); }
        else if (await preencherDropdown(["uf_end","uf_res","uf residencial","uf endereco"], cliente.estado)) { n++; dbg += "uf3>"; await delay(1000); }
        else dbg += "uf_nf>";
      }

      // Município residencial (o campo fica travado até a lista da UF carregar)
      if (cliente.cidade) {
        if (await escolherNoDropdown(caixaPorId("cidade"), cliente.cidade)) { n++; dbg += "mun>"; }
        else if (await dropdownPorLabel(["cidade","municipio"], cliente.cidade, true)) { n++; dbg += "mun2>"; }
        else if (await preencherDropdown(["municipio","munic","cidade"], cliente.cidade)) { n++; dbg += "mun3>"; }
        else dbg += "mun_nf>";
      }

      // Endereço residencial / logradouro
      const endEl = acharInput(["logradouro","endereco residencial","endereco"]);
      if (endEl && cliente.endereco) { setInput(endEl, (cliente.endereco||"").toUpperCase()); n++; dbg += "end>"; }

      // Número — fallback "S/N" se vazio (campo obrigatório no portal)
      const numEl = acharInput(["nº","numero","n°","num"]);
      if (numEl) { setInput(numEl, cliente.numero || "S/N"); n++; dbg += "num>"; }

      // Complemento
      const compEl = acharInput(["complemento"]);
      if (compEl && cliente.complemento) { setInput(compEl, (cliente.complemento||"").toUpperCase()); n++; }

      // Bairro
      const bairroEl = acharInput(["bairro"]);
      if (bairroEl && cliente.bairro) { setInput(bairroEl, (cliente.bairro||"").toUpperCase()); n++; dbg += "bairro>"; }

      // Profissão — usa execCommand para Angular reconhecer como digitação real
      const profModalEl = acharInput(["profissao","profissão","ocupacao","ocupação","profis"]);
      if (profModalEl && cliente.profissao && !ehNomeSocial(profModalEl)) {
        profModalEl.focus(); profModalEl.select();
        if (!document.execCommand("insertText", false, cliente.profissao)) {
          const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value")?.set;
          try { ns ? ns.call(profModalEl, cliente.profissao) : (profModalEl.value = cliente.profissao); } catch { profModalEl.value = cliente.profissao; }
          profModalEl.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"insertText",data:cliente.profissao}));
        }
        profModalEl.dispatchEvent(new Event("change",{bubbles:true}));
        n++; dbg += "prof>";
      }

      // E-mail
      const emailEl = acharInput(["e-mail","email","correio"]);
      if (emailEl && cliente.email) { setInput(emailEl, cliente.email); n++; dbg += "email>"; }

      // Nome do pai
      const paiModalEl = acharInput(["nome do pai","nome pai","nomepai","pai"]);
      if (paiModalEl && cliente.nome_pai) { setInput(paiModalEl, (cliente.nome_pai||"").toUpperCase()); n++; dbg += "pai>"; }

      // Telefone
      const telModalEl = acharInput(["telefone","celular","fone","phone","tel"]);
      if (telModalEl && cliente.telefone) { setInput(telModalEl, cliente.telefone); n++; dbg += "tel>"; }
    }

    // Salvar/Continuar — fluxo antigo: modal → Salvar; fluxo novo: sem modal → Continuar direto
    const temDialog = !!janelaAberta();
    if (temDialog) {
      // Fluxo antigo: busca Salvar dentro do modal
      const btnSalvar = await aguardarEl(() => {
        const scope = janelaAberta() || document;
        return [...scope.querySelectorAll("button")]
          .find(el => {
            const t = norm(el.textContent.trim());
            return t.includes("salvar") || t === "ok" || t === "confirmar" || t === "gravar";
          });
      }, 4000);
      if (btnSalvar) {
        btnSalvar.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
        btnSalvar.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
        btnSalvar.click();
        dbg += "salv>";
        const modalFechou = await aguardarEl(() =>
          !janelaAberta() ? true : null, 10000);
        if (modalFechou) { dbg += "ok>"; await delay(300); }
        else {
          // O site não salvou (falta algum campo): não fecha a janela nem segue em frente
          const aviso = avisoDoSite(".editar-dados-dialog .dialog-alert, [role='dialog'] .p-inline-message, [role='dialog'] .p-message");
          erroFluxo = "O site da PF não salvou os dados pessoais" + (aviso ? ": " + aviso : ".") +
            " Confira a janela \"Editar dados pessoais\", clique em Salvar e depois em Continuar.";
          dbg += "salv_falhou>";
          return false;
        }
      } else {
        dbg += "salv_nf>";
        erroFluxo = "Não achei o botão Salvar na janela \"Editar dados pessoais\".";
        return false;
      }
    } else {
      // Fluxo novo: formulário completo direto na página (sem modal)
      // Preenche TODOS os campos do Step 2 antes de avançar
      const fmtData2 = (d, el) => {
        if (!d) return "";
        const tipo = el?.getAttribute("type") || "text";
        const mDMY = d.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        if (mDMY) return tipo === "date" ? `${mDMY[3]}-${mDMY[2]}-${mDMY[1]}` : d;
        const mYMD = d.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (mYMD) return tipo === "date" ? d : `${mYMD[3]}/${mYMD[2]}/${mYMD[1]}`;
        return d;
      };

      // RG / Nº identidade
      const rgEl2 = inputPorLabel(["identidade","rg","nidentidade","numero identidade","n identidade"]);
      if (rgEl2 && cliente.rg) { setInput(rgEl2, cliente.rg); n++; dbg += "rg>"; }

      // Órgão emissor
      const partes2 = (cliente.orgao_emissor||"").split("-");
      const orgaoSigla2 = partes2[0]?.trim() || "";
      const ufDocVal2 = partes2[1]?.trim() || cliente.estado || "";
      const orgaoEl2 = inputPorLabel(["orgao emissor","orgao","emissor","emis"]);
      if (orgaoEl2 && orgaoSigla2) { setInput(orgaoEl2, orgaoSigla2); n++; dbg += "org>"; }

      // Data de expedição
      const expEl2 = inputPorLabel(["data de expedicao","data expedicao","expedicao","data de emissao","expedi"]);
      if (expEl2 && cliente.data_expedicao) { setInput(expEl2, fmtData2(cliente.data_expedicao, expEl2)); n++; dbg += "exp>"; }

      // UF do documento
      if (ufDocVal2) {
        if (await dropdownPorLabel(["uf do doc","uf documento","uf do documento"], ufDocVal2)) { n++; dbg += "ufdoc>"; }
        else if (await preencherDropdown(["uf do doc","ufdoc","ufdocumento","uf documento"], ufDocVal2)) { n++; dbg += "ufdoc2>"; }
      }

      // Data de nascimento
      const nascEl2 = inputPorLabel(["data de nascimento","data nascimento","datanascimento","nascimento","dt nasc"]);
      if (nascEl2 && cliente.data_nascimento) { setInput(nascEl2, fmtData2(cliente.data_nascimento, nascEl2)); n++; dbg += "nasc>"; }

      // UF de nascimento
      const ufNasc2 = cliente.uf_nascimento || cliente.estado;
      if (ufNasc2) {
        if (await dropdownPorLabel(["uf de nasc","uf nascimento","uf nasc"], ufNasc2)) { n++; dbg += "ufnasc>"; await delay(1200); }
        else if (await preencherDropdown(["uf de nasc","ufnasc","uf nascimento"], ufNasc2)) { n++; dbg += "ufnasc2>"; await delay(1200); }
      }

      // Local de nascimento
      if (cliente.local_nascimento) {
        if (await dropdownPorLabel(["local de nasc","local de nascimento","municipio nasc","municipio de nasc"], cliente.local_nascimento)) { n++; dbg += "munnasc>"; }
        else if (await preencherDropdown(["local de nasc","municipio nasc","municipionasc","localnasc"], cliente.local_nascimento)) { n++; dbg += "munnasc2>"; }
      }

      // Profissão — campo obrigatório: busca pelo formcontrolname primeiro (mais preciso),
      // depois por label com match EXATO para não pegar "Outra profissão"
      await delay(500);
      const profFinalEl =
        document.querySelector("input[formcontrolname='profissao'],input[formcontrolname='profissão'],input[formcontrolname='profissional']") ||
        (() => {
          for (const lbl of document.querySelectorAll("label,mat-label,span")) {
            const t = norm(lbl.textContent.trim()).replace(/\s*\*\s*$/, "").trim();
            if (t !== "profissao") continue; // exato: não pega "outra profissao"
            const parent = lbl.closest("mat-form-field,div,p-floatlabel,li");
            const inp = parent?.querySelector("input:not([type=hidden]):not([type=checkbox]):not([type=radio])");
            if (inp) return inp;
          }
          return null;
        })();
      dbg += profFinalEl ? "prof_el>" : "prof_el_nf>";
      if (profFinalEl) {
        if (cliente.profissao) {
          // Usa execCommand('insertText') — browser trata como digitação real,
          // Angular reactive forms aceita sem resetar
          profFinalEl.focus();
          profFinalEl.select();
          const ok = document.execCommand("insertText", false, cliente.profissao);
          if (!ok || !profFinalEl.value) {
            // Fallback: native setter + InputEvent
            const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
            try { nativeSetter ? nativeSetter.call(profFinalEl, cliente.profissao) : (profFinalEl.value = cliente.profissao); }
            catch { profFinalEl.value = cliente.profissao; }
            profFinalEl.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: cliente.profissao }));
          }
          profFinalEl.dispatchEvent(new Event("change", { bubbles: true }));
          await delay(300);
          profFinalEl.dispatchEvent(new FocusEvent("blur", { bubbles: true }));
          await delay(300);
          n++; dbg += "prof(" + (profFinalEl.value || "vazio") + ")>";
        } else {
          // Profissão não cadastrada — destaca campo e aborta sem clicar Continuar
          profFinalEl.scrollIntoView({ behavior: "smooth", block: "center" });
          profFinalEl.focus();
          profFinalEl.style.setProperty("border", "2px solid #ff6b00", "important");
          profFinalEl.style.setProperty("box-shadow", "0 0 0 4px rgba(255,107,0,0.35)", "important");
          dbg += "prof_obrig_nf>";
          return false;
        }
      }

      // Injeta CSS para suprimir erros Angular antes de avançar
      if (!document.getElementById("__passarinho_hide_err")) {
        const _s = document.createElement("style");
        _s.id = "__passarinho_hide_err";
        _s.textContent =
          ".p-error,.p-invalid .p-dropdown,.p-invalid .p-inputtext,.p-message,.p-messages," +
          ".p-inline-message,.ng-invalid~small,.ng-invalid~.p-error," +
          "[class*='field-error'],[class*='error-msg'],[class*='invalid-feedback']," +
          ".alert-danger,.text-danger,.error { display:none!important; visibility:hidden!important; }" +
          ".ng-invalid,.p-invalid,.ng-invalid>*,.p-invalid>*" +
          "{ border-color:transparent!important; box-shadow:none!important; outline:none!important; }";
        document.head.appendChild(_s);
      }

      await delay(400);
    }
    return true;
  }

  // ── PASSO 5.5: Selecionar tipo de serviço no dropdown "Serviço" ──────────
  // Deve ocorrer ANTES de Continuar. Step 1 tem dropdown "Serviço" na página.
  // AC → "Autorização de Aquisição de Arma de Fogo" | Registro → "Registrar Arma de Fogo"
  // CR → "Concessão de Certificado de Registro (CR)" (só aparece para quem ainda não tem CR)
  async function selecionarServico() {
    // Garante que modal está fechado antes de interagir com o dropdown da página
    await aguardarEl(() =>
      !janelaAberta() ? true : null, 8000);
    const txtSrvDrop = modo === "ac" ? "autoriza" : modo === "registro" ? "registrar arma" : "concess";
    // Campo "Serviço" do portal PF: escolhe uma vez só e confere (não fica tentando em outros campos)
    const caixaServico = () => document.querySelector(".servico-select .p-dropdown");
    if (caixaServico()) {
      if (await escolherNoDropdown(caixaServico, txtSrvDrop)) { dbg += `srv(${modo})>`; n++; await delay(800); return true; }
      dbg += `srv_nf(${modo})>`;
      return false;
    }
    const srvOk = await dropdownPorLabel(["servi", "tipo de servi", "selecione o servi"], txtSrvDrop);
    if (srvOk) { dbg += `srvDrop(${modo})>`; n++; await delay(800); return true; }
    // Fallback: opção visível (dropdown já aberto)
    const optEl = await aguardarEl(() =>
      [...document.querySelectorAll("mat-option,.p-dropdown-item,[role='option'],option")]
        .find(el => norm(el.textContent.trim()).includes(txtSrvDrop)), 1500);
    if (optEl) { optEl.click(); dbg += `srvOpt(${modo})>`; n++; await delay(600); return true; }
    dbg += `srvDrop_nf(${modo})>`;
    return false;
  }

  // ── Preenche modal ───────────────────────────────────────────────────────
  let pularCont1 = false;
  if (jaNoFormulario) {
    dbg += "ja_form>"; pularCont1 = true;
  } else if (modo === "registro") {
    // Registrar Arma: Serviço → Continuar → o portal abre "Editar dados pessoais"
    // → preenche → Salvar → Continuar de novo (PASSO 5)
    if (!await selecionarServico())
      return parar("Não consegui escolher o serviço \"Registrar Arma de Fogo\". Escolha o serviço na tela da PF e clique em Continuar.");
    const btnContR = await aguardarEl(() =>
      [...document.querySelectorAll("button")]
        .find(el => {
          const t = norm(el.textContent.trim());
          return t.includes("continuar") && !t.includes("doc");
        }), 5000);
    if (!btnContR) return parar("Não achei o botão Continuar na tela do Serviço.");
    btnContR.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    btnContR.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
    btnContR.click();
    dbg += "contR>";
    // Endereço incompleto → o site abre "Editar dados pessoais"; completo → já vai para o formulário
    const proximo = await aguardarEl(() =>
      janelaAberta() ? "modal"
        : location.href.includes("formulario") ? "form" : null, 15000);
    if (proximo === "modal") {
      dbg += "modalR>"; await delay(500);
      await preencherModal();
      if (erroFluxo) return parar(erroFluxo);
    } else if (proximo === "form") { dbg += "formR>"; pularCont1 = true; }
    else {
      const aviso = avisoDoSite("app-solicitacao-servico .p-inline-message, app-solicitacao-servico .p-message, .solicitacao-servico-alert");
      return parar("O site da PF não avançou depois de Continuar" + (aviso ? ": " + aviso : "."));
    }
  } else if (modo === "cadastro") {
    // Cadastro inicial (menu do painel): abre "Editar dados pessoais", preenche, salva e para aqui,
    // sem escolher serviço nem clicar Continuar (nenhuma solicitação é criada)
    if (!btnEditar) return parar("Não achei o botão \"Editar Dados\". Abra o Portal PF em \"Iniciar nova solicitação\" → Armas e tente de novo.");
    const salvou = await preencherModal();
    if (erroFluxo) return parar(erroFluxo);
    if (!salvou) return parar(dbg.includes("prof_obrig_nf")
      ? "O cliente está sem profissão no sistema: preencha o campo Profissão (destacado no site) e clique em Salvar."
      : "Não abriu a janela \"Editar dados pessoais\".");
    return encerrar({ n, dbg, msg: n > 0 ? "" : "Nenhum campo preenchido." });
  } else {
    await preencherModal();
    if (erroFluxo) return parar(erroFluxo);
    await selecionarServico();
  }

  // ── PAUSA 1: dados pessoais salvos e serviço escolhido; o usuário confere na tela e segue pela extensão ──
  if (!pularCont1) {
    window.__passarinho_waiting = true;
    window.__passarinho_step_desc = "✅ Etapa 1 de 2 — Dados pessoais salvos e serviço escolhido. Confira na tela da PF " +
      "e clique ▶ Continuar na extensão para preencher o formulário.";
    await aguardarEl(() => !window.__passarinho_waiting ? true : null, 3600000);
    window.__passarinho_waiting = false;
    dbg += "pausa1>";
  }

  // ── PASSO 5: Continuar (step 1 → step 2) — ignora botão "para documentos" ──
  // (o usuário pode já ter clicado Continuar no site durante a pausa: aí o formulário já está aberto)
  if (location.href.includes("formulario")) pularCont1 = true;
  const btnCont1 = pularCont1 ? null : await aguardarEl(() =>
    [...document.querySelectorAll("button")]
      .find(el => {
        const t = norm(el.textContent.trim());
        return t.includes("continuar") && !t.includes("doc");
      }), 5000);
  if (btnCont1) {
    btnCont1.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    btnCont1.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
    btnCont1.click();
    dbg += "cont1>"; n++;
    // O site cria a solicitação e abre o formulário; se não abrir, para e mostra o motivo
    const abriuForm = await aguardarEl(() => location.href.includes("formulario") ? true : null, 15000);
    if (!abriuForm) {
      const aviso = avisoDoSite("app-solicitacao-servico .p-inline-message, app-solicitacao-servico .p-message, .solicitacao-servico-alert");
      return parar("O site da PF não avançou depois de Continuar" + (aviso ? ": " + aviso : "."));
    }
    await delay(2500);
  } else if (!pularCont1) { dbg += "cont1_nf>"; }

  // ── Formulário com dados da ARMA (AC, Registrar Arma): o usuário preenche à mão ──
  // A extensão para e só segue (Continuar para Documentos) quando ele clicar ▶ Continuar no popup
  const folhaCom = re => [...document.querySelectorAll("h1,h2,h3,h4,h5,legend,label,span,div,p")]
    .some(el => !el.children.length && re.test(norm(el.textContent.trim())));
  const tipoForm = await aguardarEl(() =>
    folhaCom(/^(definicao da arma|caracteristicas da arma|registro da arma|armas selecionadas)$/) ? "arma"
      : folhaCom(/^(dados pessoais|atirador desportivo|atividade|tipo de atividade|atividades do certificado de registro)$/) ? "outro" : null, 10000);
  if (tipoForm === "arma") {
    dbg += "arma_manual>";
    pararDeEsconderErros(); // deixa os avisos do site aparecerem enquanto o usuário preenche
    window.__passarinho_waiting = true;
    window.__passarinho_step_desc = "✋ Preencha à mão os dados da arma na tela da PF (Espécie, Configuração, Calibre…). " +
      "Quando terminar, abra a extensão e clique ▶ Continuar para ir para Documentos.";
    await aguardarEl(() => !window.__passarinho_waiting ? true : null, 3600000);
    window.__passarinho_waiting = false;
  } else {

  // ── PASSO 6: Selecionar "Atirador Desportivo" (checkbox ou radio) ────────
  const atiradorEl = await aguardarEl(() =>
    [...document.querySelectorAll("mat-checkbox,mat-radio-button,label,span,div")]
      .find(el => {
        const t = norm(el.textContent.trim());
        return t.length < 50 && t.includes("atirador") && t.includes("desport");
      }), 6000);
  if (atiradorEl) {
    // Procura o input (checkbox ou radio) dentro ou próximo ao elemento
    const input = atiradorEl.querySelector("input[type='checkbox'],input[type='radio']") ||
      atiradorEl.closest("mat-checkbox,mat-radio-button")?.querySelector("input") ||
      (atiradorEl.tagName === "INPUT" ? atiradorEl : null);
    if (input && !input.checked) { input.click(); }
    atiradorEl.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    atiradorEl.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
    atiradorEl.click();
    dbg += "atir>"; n++; await delay(800);
  } else { dbg += "atir_nf>"; }

  // ── PASSO 7: Continuar (Atividade → Dados pessoais) ────────────────────────
  // Só clica se ainda NÃO estamos na página de dados pessoais (≥4 text/date inputs)
  const jaNaDadosPessoais = () =>
    [...document.querySelectorAll("input[type='text'],input[type='date'],input:not([type]):not([type='hidden']):not([type='checkbox']):not([type='radio'])")
    ].filter(el => el.getBoundingClientRect().width > 0).length >= 4;

  if (!jaNaDadosPessoais()) {
    const btnCont2 = await aguardarEl(() =>
      [...document.querySelectorAll("button")]
        .find(el => {
          const t = norm(el.textContent.trim());
          return t.includes("continuar") && !t.includes("doc");
        }), 5000);
    if (btnCont2) {
      btnCont2.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
      btnCont2.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
      btnCont2.click();
      dbg += "cont2>";
      // Aguarda a página de dados pessoais aparecer (até 10s)
      await aguardarEl(() => jaNaDadosPessoais() ? true : null, 10000);
      await delay(400);
    } else { dbg += "cont2_nf>"; }
  } else { dbg += "cont2_skip>"; }

  // ── PASSO 8: Preencher formulário Dados pessoais (página 2) ─────────────
  if (cliente) {
    // Aguarda ≥5 inputs texto/data visíveis (exclui checkboxes da tela anterior)
    const form2Ok = await aguardarEl(() => {
      const vis = [...document.querySelectorAll(
        "input[type='text'],input[type='date'],input:not([type]):not([type='hidden']):not([type='checkbox']):not([type='radio'])"
      )].filter(el => el.getBoundingClientRect().width > 0);
      return vis.length >= 4 ? vis[0] : null;
    }, 7000);

    if (form2Ok) {
      const qtdInputs = document.querySelectorAll("input:not([type=hidden])").length;
      dbg += "form2(" + qtdInputs + ")>";
      const partes = (cliente.orgao_emissor||"").split("-");
      const orgaoSigla = partes[0]?.trim() || "";
      const ufDocVal   = partes[1]?.trim() || cliente.estado || "";

      // Converte data para o formato certo conforme tipo do input
      const fmtData = (d, el) => {
        if (!d) return "";
        const tipo = el?.getAttribute("type") || "text";
        // BD guarda como dd/mm/yyyy
        const mDMY = d.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        if (mDMY) return tipo === "date" ? `${mDMY[3]}-${mDMY[2]}-${mDMY[1]}` : d;
        // BD guarda como yyyy-mm-dd
        const mYMD = d.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (mYMD) return tipo === "date" ? d : `${mYMD[3]}/${mYMD[2]}/${mYMD[1]}`;
        return d;
      };

      // Campo pelo rótulo EXATO ("E-mail", "Endereço", "Nº", "Bairro"...). O "*" vermelho do site fica DENTRO do
      // rótulo ("E-mail <span>*</span>"): antes rótulo com algo dentro era ignorado e o campo ficava sem preencher.
      // Pelo pedaço do texto, "endereco" pegaria o título "Endereço residencial" e cairia no CEP.
      // Tudo aqui preenche por cima do que já estiver lá: a ideia é corrigir o formulário inteiro com o sistema.
      const SEL_TXT = "input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file])";
      const inputPorRotulo = (...textos) => {
        for (const lbl of document.querySelectorAll("label,mat-label,span,legend")) {
          if (lbl.querySelector("input,select,textarea,label")) continue;
          const t = norm(lbl.textContent.trim()).replace(/\s*\*\s*$/, "").trim();
          if (!textos.includes(t)) continue;
          // label for="id" aponta direto para o campo
          const porFor = lbl.getAttribute("for") && document.getElementById(lbl.getAttribute("for"));
          if (porFor && porFor.matches(SEL_TXT)) return porFor;
          // senão: o primeiro campo DEPOIS do rótulo, dentro do mesmo bloco
          const par = parentCom(lbl, SEL_TXT, 4);
          const inp = par && [...par.querySelectorAll(SEL_TXT)]
            .find(i => lbl.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING);
          if (inp) return inp;
        }
        return null;
      };
      const campo = (rotulos, chaves) => inputPorRotulo(...rotulos) || (chaves ? inputPorLabel(chaves) : null);

      // RG / Nº identidade
      const rgEl = campo(["nº identidade", "n° identidade", "numero identidade", "identidade", "rg"], ["identidade","rg","nidentidade","numero identidade","n identidade"]);
      if (rgEl && cliente.rg) { setInput(rgEl, cliente.rg); n++; dbg += "rg>"; }

      // Órgão emissor (só a sigla: "SSP")
      const orgaoEl = campo(["orgao emissor"], ["orgao emissor","orgao","emissor","emis"]);
      if (orgaoEl && orgaoSigla) { setInput(orgaoEl, orgaoSigla); n++; dbg += "org>"; }

      // Data de expedição
      const expEl = campo(["data de expedicao", "data de emissao"], ["data de expedicao","data expedicao","expedicao","data de emissao","expedi"]);
      if (expEl && cliente.data_expedicao) { setInput(expEl, fmtData(cliente.data_expedicao, expEl)); n++; dbg += "exp>"; }

      // UF do documento
      if (ufDocVal) {
        if (await dropdownPorLabel(["uf do doc","uf documento","uf do documento"], ufDocVal)) { n++; dbg += "ufdoc>"; }
        else if (await preencherDropdown(["uf do doc","ufdoc","ufdocumento","uf documento"], ufDocVal)) { n++; dbg += "ufdoc2>"; }
      }

      // Data de nascimento
      const nascEl = campo(["data de nascimento"], ["data de nascimento","data nascimento","datanascimento","nascimento","dt nasc"]);
      if (nascEl && cliente.data_nascimento) { setInput(nascEl, fmtData(cliente.data_nascimento, nascEl)); n++; dbg += "nasc>"; }

      // País de nascimento (os clientes são brasileiros; sem ele a UF/Local de nascimento ficam travados)
      if (await dropdownPorLabel(["pais de nascimento"], "Brasil", true)) { n++; dbg += "pais>"; await delay(600); }

      // UF de nascimento — usa uf_nascimento do cadastro (não o estado residencial)
      const ufNasc = cliente.uf_nascimento || cliente.estado;
      if (ufNasc) {
        if (await dropdownPorLabel(["uf de nasc","uf nascimento","uf nasc"], ufNasc)) { n++; dbg += "ufnasc>"; await delay(1200); }
        else if (await preencherDropdown(["uf de nasc","ufnasc","uf nascimento"], ufNasc)) { n++; dbg += "ufnasc2>"; await delay(1200); }
      }

      // Local de nascimento — usa local_nascimento do cadastro (não a cidade residencial)
      const localNasc = cliente.local_nascimento;
      if (localNasc) {
        if (await dropdownPorLabel(["local de nasc","local de nascimento","municipio nasc","municipio de nasc"], localNasc)) { n++; dbg += "munnasc>"; }
        else if (await preencherDropdown(["local de nasc","municipio nasc","municipionasc","localnasc"], localNasc)) { n++; dbg += "munnasc2>"; }
      }

      // Sexo / Gênero (campo obrigatório — sem ele o portal bloqueia o Continuar)
      {
        const _mNames = ["joao","jose","carlos","paulo","pedro","marcos","lucas","andre","diego","felipe",
          "igor","thiago","guilherme","leandro","rodrigo","henrique","gustavo","leonardo","antonio",
          "eduardo","fernando","francisco","jorge","luis","luiz","marcelo","mario","miguel","renato",
          "roberto","sergio","tiago","william","gabriel","rafael","daniel","vinicius","mateus","jonas",
          "ruan","ryan","victor","samuel","arthur","murilo","alex","alan","ivan","caio","renan","erick",
          "eric","alisson","anderson","adriano","claudio","vagner","wagner","nilton","wilson","geraldo",
          "arnaldo","sebastiao","benedito","nelson","davi","enzo","nicolas","ramon","raimundo","manoel",
          "manuel","emerson","everson","edson","elton","hugo","jefferson","jeferson","luan","maicon",
          "marcio","mauro","moises","newton","nilson","orlando","otavio","robson","ronaldo","silvio",
          "walmir","wanderley","warley","wellington","weslley","wesley"];
        const _pn = norm((cliente.nome||"").split(" ")[0]);
        const _gen = cliente.genero || (_mNames.includes(_pn) ? "masculino" : "feminino");
        if (await dropdownPorLabel(["sexo","genero","gender"], _gen)) { n++; dbg += "sex>"; }
        else if (await preencherDropdown(["sexo","genero","gender"], _gen)) { n++; dbg += "sex2>"; }
        else dbg += "sex_nf>";
      }

      // Nome do pai
      const paiEl = campo(["nome do pai"], ["nome do pai","nome pai","nomepai","pai"]);
      if (paiEl && cliente.nome_pai) { setInput(paiEl, (cliente.nome_pai||"").toUpperCase()); n++; dbg += "pai>"; }

      // Profissão
      const profEl = campo(["profissao"], ["profissao","profissão","ocupacao","ocupação","profis"]);
      if (profEl && cliente.profissao) { setInput(profEl, cliente.profissao); n++; dbg += "prof>"; }

      // Telefone 1
      const telEl = campo(["telefone 1", "telefone", "celular"], ["telefone","celular","fone","phone","tel"]);
      if (telEl && cliente.telefone) { setInput(telEl, cliente.telefone); n++; dbg += "tel>"; }

      // Nome da mãe
      const maeEl = inputPorRotulo("nome da mae");
      if (maeEl && cliente.nome_mae) { setInput(maeEl, cliente.nome_mae.toUpperCase()); n++; dbg += "mae>"; }

      // E-mail
      const emailEl = inputPorRotulo("e-mail", "email");
      if (emailEl && cliente.email) { setInput(emailEl, cliente.email.trim()); n++; dbg += "email>"; }

      // Endereço residencial: CEP primeiro (o site pode buscar o endereço pelo CEP), depois o resto por cima
      const cepEl = inputPorRotulo("cep");
      const cepNum = (cliente.cep || "").replace(/\D/g, "");
      if (cepEl && cepNum) {
        setInput(cepEl, cepEl.maxLength === 8 ? cepNum : (cepNum.length === 8 ? cepNum.slice(0, 5) + "-" + cepNum.slice(5) : cepNum));
        n++; dbg += "cep>";
        await delay(800);
        await aguardarEl(() => !cepEl.disabled ? true : null, 10000);
        await delay(1500);
      }
      if (cliente.estado) {
        if (await dropdownPorLabel(["uf"], cliente.estado, true)) { n++; dbg += "ufend>"; await delay(1200); }
        else dbg += "ufend_nf>";
      }
      if (cliente.cidade) {
        if (await dropdownPorLabel(["cidade", "municipio"], cliente.cidade, true)) { n++; dbg += "cidend>"; await delay(800); }
        else dbg += "cidend_nf>";
      }
      const endEl = inputPorRotulo("endereco", "logradouro");
      if (endEl && cliente.endereco) { setInput(endEl, cliente.endereco.toUpperCase()); n++; dbg += "end>"; }
      const numEl = inputPorRotulo("nº", "n°", "numero");
      if (numEl) { setInput(numEl, cliente.numero || "S/N"); n++; dbg += "num>"; }
      const compEl = inputPorRotulo("complemento");
      if (compEl && cliente.complemento) { setInput(compEl, cliente.complemento.toUpperCase()); n++; dbg += "comp>"; }
      if (cliente.bairro) {
        const bairroEl = inputPorRotulo("bairro");
        if (bairroEl) { setInput(bairroEl, cliente.bairro.toUpperCase()); n++; dbg += "bairro>"; }
        else if (await dropdownPorLabel(["bairro"], cliente.bairro, true)) { n++; dbg += "bairro2>"; }
        else dbg += "bairro_nf>";
      }

    } else { dbg += "form2_nf>"; }
  }

  // Campos que o cliente não tem no sistema: a extensão não tem o que pôr neles, então avisa na pausa
  const semNoSistema = !cliente ? [] : [
    ["E-mail", cliente.email], ["Nome da mãe", cliente.nome_mae], ["Telefone", cliente.telefone],
    ["Nº identidade", cliente.rg], ["Data de expedição", cliente.data_expedicao], ["Data de nascimento", cliente.data_nascimento],
    ["Profissão", cliente.profissao], ["CEP", cliente.cep], ["Endereço", cliente.endereco], ["Bairro", cliente.bairro],
  ].filter(([, v]) => !String(v || "").trim()).map(([nome]) => nome);
  const avisoSemNoSistema = semNoSistema.length
    ? ` ⚠️ Vazio no cadastro do sistema (preencha à mão ou corrija no site): ${semNoSistema.join(", ")}.` : "";

  // ── CHECKPOINT 1: para depois de preencher os dados do cliente, para conferir antes de ir para Documentos ────
  // (antes só parava se achasse 4 campos de texto visíveis; em algumas telas não achava e seguia direto)
  if (n > 0 || jaNaDadosPessoais()) {
    window.__passarinho_waiting = true;
    window.__passarinho_step_desc = "✅ Etapa 2 de 2 — Formulário preenchido. Confira todos os campos (especialmente Local de nascimento e UF do documento) e clique ▶ Continuar para ir para Documentos." + avisoSemNoSistema;
    await aguardarEl(() => !window.__passarinho_waiting ? true : null, 600000);
  }

  } // ── FIM do formulário de atividade/dados pessoais (CR) ──────────────────

  // ── PASSO 9: Clicar em "Continuar para Documentos" ───────────────────────
  // Roda sempre — sem cliente os passos anteriores são pulados mas precisa avançar

  // Injeta CSS ANTES de navegar para o passo 3 — assim os erros vermelhos do Angular
  // nunca aparecem (o portal é SPA Angular, o style persiste na navegação de rota)
  if (!document.getElementById("__passarinho_hide_err")) {
    const _s = document.createElement("style");
    _s.id = "__passarinho_hide_err";
    _s.textContent =
      ".p-error,.p-invalid .p-dropdown,.p-invalid .p-inputtext,.p-message,.p-messages," +
      ".p-inline-message,.ng-invalid~small,.ng-invalid~.p-error," +
      "[class*='field-error'],[class*='error-msg'],[class*='invalid-feedback']," +
      ".alert-danger,.text-danger,.error { display:none!important; visibility:hidden!important; }" +
      ".ng-invalid,.p-invalid,.ng-invalid>*,.p-invalid>*" +
      "{ border-color:transparent!important; box-shadow:none!important; outline:none!important; }";
    document.head.appendChild(_s);
  }

  const btnCont3 = await aguardarEl(() =>
    [...document.querySelectorAll("button,a")].find(el => {
      const t = norm(el.textContent.trim());
      return t.includes("continuar para doc") || t.includes("continuar para documentos") || (t.includes("continuar") && t.includes("doc"));
    }), 5000);
  if (btnCont3) {
    await delay(600);
    btnCont3.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    btnCont3.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
    btnCont3.click();
    dbg += "cont3>"; n++;
  } else { dbg += "cont3_nf>"; }

  } // ── FIM PASSOS 3-9 (pularNav) ────────────────────────────────────────

  // ── PASSO 10: Upload de documentos (passo 3 do portal) ───────────────────
  // Roda sempre, com ou sem cliente selecionado no sistema
  const slotPortal = {
    ant_federal: 1, ant_estadual: 2, ant_eleitoral: 3, ant_militar: 4,
    comp_ocupacao: 5, comp_residencia: 6, comp_2_end: 7, cap_tecnica: 8,
    laudo_psico: 9, decl_inquerito: 10, comp_filiacao: 11, decl_habitualidade: 12,
  };
  // Palavras-chave para escolher a opção certa em cada slot (alguns têm múltiplas opções)
  function normT(s) { return (s||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase(); }
  const slotChaves = {
    1: ["federal"], 2: ["estadual"], 3: ["eleitoral"], 4: ["militar"],
    5: ["ocupacao licita","ocupacao","aposentad","trabalho"],
    6: ["residencia","residencia fixa"],
    7: ["segundo endereco","acervo"],
    8: ["capacidade tecnica"],
    9: ["aptidao psicologica","aptidao","psicolog"],
    10: ["inquerito","processo criminal"],
    11: ["filiacao","clube de tiro","entidade de tiro"],
    12: ["habitualidade"],
  };
  // Para slots de comprovante de endereço (6 e 7), identifica tipo pelo nome do arquivo
  const tipoEnderecoMapas = [
    // txt: textos aceitos na opção do portal, na ordem (no portal a de energia é "Conta de luz": com só "energia"
    // não achava e caía no padrão "Conta de água")
    { chaves: ["luz","energia","eletric","coelba","cemig","copel","cpfl","enel","equatorial","ampla","light"], txt: ["luz","energia","eletric"] },
    { chaves: ["telefone","celular","tim","vivo","claro","oi","telefonia","nextel","internet","banda larga"], txt: ["telefon","celular","internet"] },
    { chaves: ["agua","saneam","saae","caema","cagece","casan","embasa","corsan","sabesp","cedae"], txt: ["agua"] },
    { chaves: ["gas","comgas","naturgy","liquigas"], txt: ["gas"] },
  ];
  const tipoOcupacaoMapas = [
    { chaves: ["contracheque","holerite","ctps"], txt: "contracheque" },
    { chaves: ["decore","registros municipais"], txt: "registros municipais" },
    { chaves: ["oab"], txt: "oab" },
    { chaves: ["junta comercial","cnpj"], txt: "junta comercial" },
    { chaves: ["mei","ccmei","das-mei","simei"], txt: "ccmei" },
    { chaves: ["inss"], txt: "inss" },
    { chaves: ["instituicao publica","instituicao p"], txt: "instituicao publica" },
    { chaves: ["outros"], txt: "outros" },
  ];
  function melhorOpcao(panel, slot, arq) {
    const items = [...panel.querySelectorAll(".p-dropdown-item, li[role='option']")]
      .filter(o => !o.classList.contains("p-disabled") && o.textContent.trim() !== "");
    // Slot 5: o site guarda o tipo escolhido ao anexar com o texto exato da opção do portal no nome do arquivo
    // ("Comprovante de ocupação lícita ou aposentadoria - Comprovante de rendimento do INSS (60 dias).pdf"):
    // vale a opção igual. Arquivo antigo, com nome curto ("- INSS"), cai nas regras de baixo
    if (slot === 5 && arq && arq.nome) {
      const limpo = s => normT(s).replace(/\s+/g, " ").trim();
      const sufixo = limpo(arq.nome).match(/\s-\s(.+?)(?:\.pdf)?$/)?.[1];
      const igual = sufixo && items.find(o => limpo(o.textContent) === sufixo);
      if (igual) return igual;
    }
    // Slot 5: usa tipo de ocupação do cadastro do cliente
    if (slot === 5 && arq && arq.tipoDoc) {
      const opt = items.find(o => normT(o.textContent).includes(normT(arq.tipoDoc)));
      if (opt) return opt;
    }
    // Slot 5: fallback por sufixo do nome do arquivo (ex: "Comprovante... - INSS.pdf" → só busca em "inss")
    if (slot === 5 && arq && arq.nome) {
      const nm = normT(arq.nome);
      // Extrai só o sub-tipo (parte após " - " antes do .pdf) para evitar palavras do nome base
      const sufixoMatch = nm.match(/\s-\s(.+?)(?:\.pdf)?$/);
      const sufixo = sufixoMatch ? sufixoMatch[1] : nm;
      for (const m of tipoOcupacaoMapas) {
        if (m.chaves.some(k => sufixo.includes(normT(k)))) {
          const opt = items.find(o => normT(o.textContent).includes(m.txt));
          if (opt) return opt;
        }
      }
    }
    // Slots 6 e 7: identifica tipo pelo nome do arquivo (água/energia/telefone/gás)
    if ((slot === 6 || slot === 7) && arq) {
      const nm = normT(arq.nome || "");
      // o tipo escolhido no site vai no fim do nome ("... - Luz.pdf"): confere ele primeiro, depois o nome inteiro
      const sufixo = nm.match(/\s-\s([^-]+?)(?:\.pdf)?$/)?.[1] || "";
      for (const parte of [sufixo, nm].filter(Boolean)) {
        for (const m of tipoEnderecoMapas) {
          if (m.chaves.some(k => parte.includes(normT(k)))) {
            for (const t of m.txt) {
              const opt = items.find(o => normT(o.textContent).includes(t));
              if (opt) return opt;
            }
          }
        }
      }
      // Sem keyword no nome: inferir pela coincidência de palavras entre filename e opção
      const optPorNome = items.find(o => {
        const palavrasOpt = normT(o.textContent).split(/\s+/).filter(p => p.length > 3);
        return palavrasOpt.some(p => nm.includes(p));
      });
      if (optPorNome) return optPorNome;
      // Default para água quando não há keyword no nome
      const optAgua = items.find(o => normT(o.textContent).includes("agua"));
      if (optAgua) return optAgua;
    }
    // Autorização de Compra Caça: no portal, o 11 é "Comprovante de filiação a entidade de caça" e o 12 "Documento
    // expedido pelo Ibama para abate a fauna invasora" (no lugar de filiação a clube de tiro e habitualidade).
    // Vale a opção com mais palavras em comum com o nome do arquivo; senão, a que fala do documento de caça
    if (variante === "caca" && (slot === 11 || slot === 12)) {
      if (arq && arq.nome) {
        const palavras = s => normT(s).replace(/\.pdf$/, "").split(/[^a-z0-9]+/).filter(p => p.length > 3);
        const doArquivo = new Set(palavras(arq.nome));
        let melhor = null, pontos = 0;
        for (const o of items) {
          const p = palavras(o.textContent).filter(w => doArquivo.has(w)).length;
          if (p > pontos) { melhor = o; pontos = p; }
        }
        if (melhor) return melhor;
      }
      const chavesCaca = slot === 11 ? ["entidade de caca", "caca", "filiacao"] : ["ibama", "abate", "fauna invasora", "fauna", "manejo"];
      for (const k of chavesCaca) {
        const o = items.find(o => normT(o.textContent).includes(k));
        if (o) return o;
      }
      return items[0] || null;
    }
    // Demais slots: usa palavras-chave fixas por slot
    const kws = slotChaves[slot] || [];
    for (const k of kws) {
      const match = items.find(o => normT(o.textContent).includes(k));
      if (match) return match;
    }
    // Fallback geral: coincidência de palavras do filename contra textos das opções
    if (arq && arq.nome) {
      const nm = normT(arq.nome);
      const optPorNome = items.find(o => {
        const palavrasOpt = normT(o.textContent).split(/\s+/).filter(p => p.length > 3);
        return palavrasOpt.some(p => nm.includes(p));
      });
      if (optPorNome) return optPorNome;
    }
    return items[0] || null;
  }
  function reconstruirFile(arq) {
    const bin = atob(arq.base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes.buffer], arq.nome, { type: "application/pdf" });
  }
  // Suporta arquivos do sistema (com tipo) e arquivos locais (com numero 1-12)
  const arqPorSlot = {};
  for (const arq of (arquivos || [])) {
    if (arq.tipo) {
      const s = slotPortal[arq.tipo];
      if (s) arqPorSlot[s] = arq;
    } else if (arq.numero >= 1 && arq.numero <= 12) {
      arqPorSlot[arq.numero] = arq;
    }
  }
  dbg += `,arqDisp=${Object.keys(arqPorSlot).length}`;
  // Injeta tipo de ocupação do cadastro no slot 5 para seleção automática
  if (arqPorSlot[5] && cliente && cliente.tipo_ocupacao) {
    arqPorSlot[5] = { ...arqPorSlot[5], tipoDoc: cliente.tipo_ocupacao };
  }

  // Espera a URL mudar para "documentos" (garante que passo 3 carregou, não passo 2)
  const urlOk = await aguardarEl(() => location.href.includes("documentos") ? true : null, 15000);
  dbg += `,url=${urlOk ? "ok" : "nok"}`;
  // Fora da tela de Documentos não mexe em nenhum campo (antes abria o "Serviço" várias vezes)
  if (!urlOk && !document.querySelector("input[type='file']"))
    return parar("Não cheguei na tela de Documentos. Confira a tela da PF e continue por lá.");

  const nArqsDisp = Object.keys(arqPorSlot).length;

  // sem delay: detectarDropdowns() já aguarda Angular renderizar

  // Detecta tipo de dropdown: native select, p-dropdown (PrimeNG) ou mat-select
  function detectarDropdowns() {
    const sels = document.querySelectorAll("select");
    if (sels.length >= 1) return { tipo: "native", els: [...sels] };
    const pdropTag = document.querySelectorAll("p-dropdown, p-select");
    if (pdropTag.length >= 1) return { tipo: "pdrop", els: [...pdropTag] };
    const pdropDiv = document.querySelectorAll("div.p-dropdown:not(.p-dropdown-panel)");
    if (pdropDiv.length >= 1) return { tipo: "pdrop", els: [...pdropDiv] };
    const matsel = document.querySelectorAll("mat-select");
    if (matsel.length >= 1) return { tipo: "mat", els: [...matsel] };
    return null;
  }
  const dropResult = await aguardarEl(() => detectarDropdowns(), 10000);
  dbg += `,dr=${dropResult ? dropResult.tipo + dropResult.els.length : "none"}`;

  const slotsRes = {};
  for (let s = 1; s <= 12; s++) slotsRes[s] = arqPorSlot[s] ? "pendente" : "sem";

  if (dropResult) {
    const drops = dropResult.els;
    // A PF muda a lista de itens (2026-11-20: tirou o "segundo endereço" e o 7 virou capacidade técnica). Antes o
    // documento ia pela POSIÇÃO e foi tudo deslocado (filiação no lugar da habitualidade...). Agora cada caixa lê o
    // TÍTULO do item ("7 - Comprovante de capacidade técnica...") e recebe o documento desse assunto; título que não
    // dá para reconhecer fica sem documento (nunca chuta). "slot" continua sendo o número antigo do documento
    // (SLOT_PORTAL), que escolhe as opções do "Tipo de documento enviado".
    // títulos "N - Assunto": texto curto começando com número e traço
    const titulos = [...document.querySelectorAll("h1,h2,h3,h4,h5,h6,label,legend,p,span,div,strong,b")]
      .filter(el => { const t = (el.textContent || "").trim(); return t.length < 160 && /^\d{1,2}\s*-\s*\S/.test(t); });
    // o título do item é o último que vem ANTES da caixa (e que não a contém)
    const tituloElDe = drop => {
      let ultimo = null;
      for (const t of titulos) {
        if (t.contains(drop)) continue;
        if (t.compareDocumentPosition(drop) & Node.DOCUMENT_POSITION_FOLLOWING) ultimo = t;
      }
      return ultimo;
    };
    const tituloDe = drop => { const u = tituloElDe(drop); return u ? normT(u.textContent) : ""; };
    const slotDoTitulo = t => {
      if (!t) return 0;
      if (/justica federal/.test(t)) return slotPortal.ant_federal;
      if (/justica estadual/.test(t)) return slotPortal.ant_estadual;
      if (/justica eleitoral/.test(t)) return slotPortal.ant_eleitoral;
      if (/justica militar/.test(t)) return slotPortal.ant_militar;
      if (/ocupacao|aposentadoria/.test(t)) return slotPortal.comp_ocupacao;
      if (/segundo endereco|guarda do acervo/.test(t)) return slotPortal.comp_2_end;
      if (/residencia/.test(t)) return slotPortal.comp_residencia;
      if (/capacidade tecnica/.test(t)) return slotPortal.cap_tecnica;
      if (/aptidao psicologica|psicolog/.test(t)) return slotPortal.laudo_psico;
      if (/inquerito|processo criminal/.test(t)) return slotPortal.decl_inquerito;
      if (/habitualidade|ibama|fauna|abate/.test(t)) return slotPortal.decl_habitualidade;
      if (/filiacao|entidade de caca/.test(t)) return slotPortal.comp_filiacao;
      return 0;
    };
    const temTitulos = drops.some(d => slotDoTitulo(tituloDe(d)));
    dbg += `,titulos=${temTitulos ? "sim" : "nao"}`;
    if (!temTitulos) return parar("Não reconheci os itens de documentos da PF (a tela mudou). Nada foi anexado: anexe à mão e me avise para eu ajustar.");
    const usados = new Set();
    for (let i = 0; i < drops.length && i < 12; i++) {
      const drop = drops[i];
      const slot = slotDoTitulo(tituloDe(drop));
      if (!slot) { dbg += `,i${i + 1}=titulo?`; continue; }
      if (usados.has(slot)) { dbg += `,i${i + 1}=repetido`; continue; }
      usados.add(slot);

      // Pula slot completamente se não há arquivo cadastrado para ele
      if (!arqPorSlot[slot]) { dbg += `,s${slot}=sem`; continue; }

      // Item que JÁ tem arquivo (de uma vez anterior, ou anexado à mão): não anexa de novo. Antes o 1 ficou com a
      // certidão Federal duas vezes (usuário viu, 2026-11-25). Arquivo anexado = botão "Excluir" entre o título deste
      // item e o do próximo
      const tEl = tituloElDe(drop);
      const prox = tEl && titulos.find(t => t !== tEl && !t.contains(tEl) && !tEl.contains(t) &&
        (tEl.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING) && slotDoTitulo(normT(t.textContent)));
      const jaTem = tEl && [...document.querySelectorAll("button,a,span")].some(el =>
        /^excluir$/i.test((el.textContent || "").trim()) &&
        (tEl.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) &&
        (!prox || (el.compareDocumentPosition(prox) & Node.DOCUMENT_POSITION_FOLLOWING)));
      if (jaTem) { dbg += `,s${slot}=ja`; slotsRes[slot] = "ok"; continue; }

      // 1) Seleciona o tipo de documento no dropdown
      if (dropResult.tipo === "native") {
        const optReal = [...drop.options].find(o => o.value !== "" && o.value != null && o.value !== "0");
        if (optReal) {
          drop.value = optReal.value;
          drop.dispatchEvent(new Event("change", { bubbles: true }));
          await delay(400);
          dbg += `,d${slot}=ok`;
        } else { dbg += `,d${slot}=sem`; }
      } else if (dropResult.tipo === "pdrop") {
        // Clica no trigger (seta) do p-dropdown
        const trigger = drop.querySelector(".p-dropdown-trigger, [role='button'][aria-label*='trigger']") || drop;
        trigger.click();
        // Painel PrimeNG é anexado ao body — aguarda qualquer painel aberto
        const panel = await aguardarEl(() =>
          document.querySelector(".p-dropdown-panel, .p-select-overlay, .p-overlay-open"), 3000);
        if (panel) {
          // Aguarda opções renderizarem e escolhe a melhor pelo texto do slot (e nome do arquivo)
          const optReal = await aguardarEl(() => melhorOpcao(panel, slot, arqPorSlot[slot]), 2000);
          if (optReal) { optReal.click(); await delay(300); dbg += `,d${slot}=ok`; }
          else { document.body.click(); dbg += `,d${slot}=sem`; }
        } else { dbg += `,d${slot}=nopanel`; }
      } else if (dropResult.tipo === "mat") {
        const trigger = drop.querySelector(".mat-mdc-select-trigger,.mat-select-trigger") || drop;
        trigger.click();
        const optReal = await aguardarEl(() =>
          [...document.querySelectorAll("mat-option")].find(o => !o.classList.contains("mat-option-disabled")), 2000);
        if (optReal) { optReal.click(); await delay(300); dbg += `,d${slot}=ok`; }
        else { document.body.click(); dbg += `,d${slot}=sem`; }
      }

      // 2) Anexa o arquivo (rápido, como antes: 400 ms entre um e outro). Só o "change": com o "input" junto, o portal
      // enviava o mesmo arquivo duas vezes, o segundo dava "Erro ao enviar" e o portal tirava o arquivo
      const arq = arqPorSlot[slot];
      const allInps = [...document.querySelectorAll("input[type='file'], input[accept]")];
      const inp = allInps[i] || null;
      if (!inp) { dbg += `,s${slot}=noinp(${allInps.length})`; slotsRes[slot] = "err"; continue; }
      const dt = new DataTransfer();
      dt.items.add(reconstruirFile(arq));
      try { inp.files = dt.files; } catch (e) {}
      inp.dispatchEvent(new Event("change", { bubbles: true }));
      await delay(400);
      dbg += `,s${slot}=ok`;
      slotsRes[slot] = "ok";
      n++;
    }
  }

  // Slots que ainda são "pendente" após o loop = dropResult era null ou slot não encontrado no portal
  for (let s = 1; s <= 12; s++) {
    if (slotsRes[s] === "pendente") slotsRes[s] = "err";
  }

  // Para o intervalo de ocultamento e restaura estilos
  setTimeout(pararDeEsconderErros, 1000);

  return encerrar({ n, dbg, slots: slotsRes });
  } catch(e) {
    const parado = e.message === "__passarinho_parado__";
    if (parado) { // para de esconder os avisos do site, como no fim normal
      window.__passarinho_hiding = false;
      document.getElementById("__passarinho_hide_err")?.remove();
    }
    const r = parado ? { n: 0, dbg: "parado", parado: true }
      : { n: 0, dbg: `ERRO:${e.message?.slice(0,100)}` };
    // um preenchimento NOVO já começou: não mexe no estado dele
    if (window.__passarinho_exec === meuExec || window.__passarinho_exec === null) {
      window.__passarinho_pausado = false; window.__passarinho_parar = false; window.__passarinho_waiting = false;
      window.__passarinho_resultado = r; window.__passarinho_rodando = false;
    }
    return r;
  }
}

// ── Sinarm CAC (servicos.pf.gov.br/sisgcorp-cliente-web-externo): "GT Sinarm CAC" – Guia de Tráfego ──
// Caminho do usuário: Solicitação de Serviço › Pessoa Física › Listar Processo › Novo Processo. No formulário
// (accordion, código lido do site): "2. Escolha as Atividades e os Serviços" → Serviço "Emitir Guia de Tráfego Pessoa
// Física (CAC)", Tipo de Atividade (p-multiSelect tipoAtividade) "Tiro Desportivo - Atirador Desportivo", Tipo de PCE
// (p-multiSelect pces) "ARMA DE FOGO", Finalidade (p-dropdown finalidade) "TREINAMENTO TIRO DESPORTIVO"; depois
// Local de origem (p-dropdown enderecoSigma: o endereço do cliente), Local de destino (nomeEvento, uf, cidade,
// logradouro, numero = o evento escolhido) e o documento de identificação: tipo "Carteira de identidade" + arquivo
// (p-fileUpload customUpload, PDF/JPG até 1 MB). A tabela PCE (armamento) fica para o usuário. PARA antes de enviar.
async function injectarSinarmGt(cliente, evento, ident) {
  window.__passarinho_rodando = true; window.__passarinho_vivo = 0; window.__passarinho_passo = ""; // só o CR marca a hora
  window.__passarinho_waiting = false;
  window.__passarinho_modo = "gt";
  window.__passarinho_resultado = null;
  window.__passarinho_step_desc = "";
  window.__passarinho_parar = false;
  window.__passarinho_pausado = false;
  // identificação deste preenchimento: ⏹ Parar (ou um preenchimento novo) a troca, e este para na próxima espera/clique
  var meuExec = Math.random().toString(36).slice(2);
  window.__passarinho_exec = meuExec;
  const parou = () => window.__passarinho_parar || window.__passarinho_exec !== meuExec;
  const encerrar = r => { if (window.__passarinho_exec !== meuExec) return r; window.__passarinho_resultado = r; window.__passarinho_rodando = false; return r; };
  try {
    const esperar = async ms => {
      if (parou()) throw new Error("__passarinho_parado__");
      await new Promise(r => setTimeout(r, ms));
      while (window.__passarinho_pausado && !parou()) await new Promise(r => setTimeout(r, 300));   // ⏸ Pausar
      if (parou()) throw new Error("__passarinho_parado__");
    };
    const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
    const visivel = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
    const ate = async (fn, ms = 10000) => { const fim = Date.now() + ms; while (Date.now() < fim) { const r = fn(); if (r) return r; await esperar(200); } return null; };
    const clicar = el => {
      if (parou()) throw new Error("__passarinho_parado__");
      el.scrollIntoView({ block: "center" });
      for (const t of ["mousedown", "mouseup", "click"]) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    };
    const porTexto = (txts, raiz = document) => {
      for (const txt of [].concat(txts)) {
        const alvo = norm(txt);
        const els = [...raiz.querySelectorAll("a, button, li, span, p, div, label, h3, [role=menuitem], [role=tab]")].filter(visivel);
        let c = els.filter(e => norm(e.innerText) === alvo);
        if (!c.length) c = els.filter(e => { const t = norm(e.innerText); return t.includes(alvo) && t.length <= alvo.length + 30; });
        c = c.filter(e => !c.some(o => o !== e && e.contains(o)));   // o mais de dentro: o clique sobe dele
        c.sort((a, b) => a.innerText.length - b.innerText.length);
        if (c[0]) return c[0];
      }
      return null;
    };
    const escrever = (el, valor) => {
      if (!el || valor == null || valor === "" || el.disabled || el.readOnly) return false;
      el.focus();
      el.dispatchEvent(new KeyboardEvent("keydown", { key: "0", keyCode: 48, bubbles: true }));
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, String(valor));
      for (const t of ["input", "change"]) el.dispatchEvent(new Event(t, { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent("keyup", { key: "0", keyCode: 48, bubbles: true }));
      el.dispatchEvent(new Event("blur", { bubbles: true }));
      return true;
    };
    let n = 0;
    const faltou = [];

    // ── 1. Lista de processos › Novo Processo ──
    const noFormulario = () => /preencher-formulario/.test(location.hash) || !!porTexto("Escolha as Atividades");
    if (!noFormulario()) {
      window.__passarinho_step_desc = "Abrindo Novo Processo…";
      if (!/listar-processo/.test(location.hash)) {
        for (const txt of [["Solicitação de Serviço", "Solicitações"], ["Pessoa Física"], ["Listar Processo", "Lista de Processo", "Listar Processos"]]) {
          if (/listar-processo/.test(location.hash)) break;
          const el = await ate(() => porTexto(txt), 4000);
          if (!el) break;
          clicar(el);
          await esperar(900);
        }
        if (!await ate(() => /listar-processo/.test(location.hash), 4000)) location.hash = "#/listar-processos";
      }
      const novo = await ate(() => porTexto(["Novo Processo", "Novo processo", "Novo"]), 15000);
      if (!novo) return encerrar({ n: 0, msg: "Não achei o botão \"Novo Processo\" na lista de processos." });
      clicar(novo);
      if (!await ate(() => porTexto("Escolha as Atividades"), 20000)) return encerrar({ n: 0, msg: "O formulário do novo processo não abriu." });
      await esperar(1000);
    }

    // ── Ajudantes: abas (accordion) e listas PrimeNG antigas (ui-dropdown / ui-multiselect) ──
    const abrirAba = async texto => {
      const cab = porTexto(texto);
      if (!cab) return false;
      const header = cab.closest(".ui-accordion-header") || cab;
      // etapa bloqueada: o site só libera a próxima com a anterior completa
      if (header.classList.contains("ui-state-disabled") || header.closest(".ui-state-disabled")) return "bloqueada";
      if (!header.classList.contains("ui-state-active")) { clicar(header.querySelector("a") || header); await esperar(800); }
      if (!header.classList.contains("ui-state-active")) { await esperar(800); if (!header.classList.contains("ui-state-active")) clicar(header.querySelector("a") || header); await esperar(800); }
      return header.classList.contains("ui-state-active") ? true : "fechada";
    };
    // a lista: pelo name/id, ou pelo rótulo escrito em cima dela (o Serviço não tem name no site)
    const acharLista = (nome, rotulo, raiz = document) => {
      const porNome = nome && [...raiz.querySelectorAll(`[name='${nome}'], #${nome}`)].find(visivel);
      if (porNome) return porNome.matches(".ui-dropdown, .ui-multiselect") ? porNome : porNome.querySelector(".ui-dropdown, .ui-multiselect") || porNome;
      if (!rotulo) return null;
      const r = norm(rotulo);
      for (const lab of [...raiz.querySelectorAll("label, span, legend")].filter(l => visivel(l) && norm(l.innerText) === r)) {
        for (let p = lab.parentElement, i = 0; p && i < 4; p = p.parentElement, i++) {
          const dd = p.querySelector(".ui-dropdown, .ui-multiselect");
          if (dd && visivel(dd)) return dd;
        }
      }
      return null;
    };
    // Opções da lista ABERTA AGORA. Antes pegava qualquer lista visível na página: logo depois do Tipo de Atividade,
    // a lista dela ainda estava fechando e o Tipo de PCE lia as opções erradas (sem "ARMA DE FOGO") e ficava vazio.
    // No PrimeNG antigo o painel fica dentro da própria lista; se o site o puser no fim da página, vale o último aberto
    const SEL_ITENS = ".ui-dropdown-items li, .ui-dropdown-item, .ui-multiselect-items li, .ui-multiselect-item";
    const itensDe = dd => {
      const dentro = [...dd.querySelectorAll(SEL_ITENS)].filter(visivel);
      if (dentro.length) return dentro;
      const paineis = [...document.querySelectorAll(".ui-dropdown-panel, .ui-multiselect-panel")].filter(p => visivel(p) && !p.closest(".ui-dropdown, .ui-multiselect"));
      const painel = paineis[paineis.length - 1];
      if (painel) return [...painel.querySelectorAll(SEL_ITENS)].filter(visivel);
      // último recurso: opções visíveis que não pertencem a OUTRA lista da página
      return [...document.querySelectorAll(SEL_ITENS)].filter(li => { if (!visivel(li)) return false; const dono = li.closest(".ui-dropdown, .ui-multiselect"); return !dono || dono === dd; });
    };
    const melhor = (itens, textos) => {
      const alvos = textos.map(norm);
      for (const a of alvos) { const x = itens.find(li => norm(li.innerText) === a); if (x) return x; }
      for (const a of alvos) { const x = itens.find(li => norm(li.innerText).startsWith(a)); if (x) return x; }
      for (const a of alvos) { const x = itens.find(li => norm(li.innerText).includes(a)); if (x) return x; }
      return null;
    };
    // espera as opções carregarem (o site busca pelo serviço/atividade escolhidos) até achar a desejada
    const abrirEAchar = async (dd, textos, primeiro) => {
      for (let tentativa = 0; tentativa < 3; tentativa++) {
        clicar(dd);
        const li = await ate(() => {
          const l = itensDe(dd);
          return melhor(l, textos) || (primeiro && l.find(x => !/^selecione/.test(norm(x.innerText)) && norm(x.innerText))) || null;
        }, 4000);
        if (li) return li;
        clicar(dd);                 // fecha e tenta de novo (as opções podem ter chegado depois)
        await esperar(1200);
      }
      return null;
    };
    const escolher = async (dd, textos, { primeiro = false } = {}) => {
      if (!dd) return null;
      if (!await ate(() => !dd.matches(".ui-state-disabled") && !dd.closest(".ui-state-disabled"), 8000)) return null;
      const li = await abrirEAchar(dd, textos, primeiro);
      if (!li) return null;
      const txt = li.innerText.trim();
      clicar(li);
      await esperar(500);
      return txt;
    };
    // caixinhas (multiSelect, como o Tipo de PCE): marca a opção e CONFERE. O usuário viu a lista abrir com
    // "ARMA DE FOGO" e a caixinha continuar vazia; agora tenta a linha, a caixinha dela e, por fim, a busca da lista +
    // a caixinha "marcar todas" do topo (com o filtro só sobra a opção desejada)
    let vistoNaLista = "";
    const marcar = async (dd, textos, espera = 8000) => {
      if (!dd) { vistoNaLista = "lista não encontrada"; return null; }
      if (!await ate(() => !dd.matches(".ui-state-disabled") && !dd.closest(".ui-state-disabled"), espera)) { vistoNaLista = "lista desabilitada"; return null; }
      const li = await abrirEAchar(dd, textos, false);
      if (!li) { vistoNaLista = `opções vistas: ${itensDe(dd).map(x => x.innerText.trim()).join(" / ") || "nenhuma"}`; clicar(dd); return null; }
      const txt = li.innerText.trim();
      // a caixinha em si (.ui-chkbox-box); a moldura .ui-chkbox em volta dela não marca
      const caixa = () => li.querySelector(".ui-chkbox-box") || li.querySelector("input[type=checkbox]") || li.querySelector(".ui-chkbox");
      const marcado = () => li.classList.contains("ui-state-highlight") || li.getAttribute("aria-checked") === "true" ||
        !!li.querySelector(".ui-state-active, .fa-check, .ui-icon-check, .pi-check, input[type=checkbox]:checked");
      const rotuloTem = () => norm(dd.querySelector(".ui-multiselect-label")?.innerText).includes(norm(txt).slice(0, 8));
      const tentativas = [
        () => clicar(li),
        () => { const c = caixa(); if (c) clicar(c); },
        () => { const l = li.querySelector("label, span"); if (l) clicar(l); },
        async () => {   // busca da lista + "marcar todas" do topo
          const painel = li.closest(".ui-multiselect-panel") || dd;
          const busca = painel.querySelector(".ui-multiselect-filter-container input, input[type=text]");
          if (busca) { escrever(busca, txt.split(" ")[0]); await esperar(500); }
          const todas = painel.querySelector(".ui-multiselect-header .ui-chkbox-box, .ui-multiselect-header .ui-chkbox");
          if (todas && itensDe(dd).length === 1) clicar(todas);
        },
      ];
      for (const t of tentativas) {
        if (marcado() || rotuloTem()) break;
        await t();
        await esperar(600);
      }
      const ok = marcado() || rotuloTem();
      if (!ok) vistoNaLista = `achei "${txt}" mas a caixinha não marcou (classes: ${li.className} | ${caixa()?.className || "sem caixinha"})`;
      const fechar = dd.querySelector(".ui-multiselect-close") || [...document.querySelectorAll(".ui-multiselect-close")].find(visivel);
      if (fechar && visivel(fechar)) clicar(fechar); else clicar(dd);
      await esperar(600);
      return ok || rotuloTem() ? txt : null;
    };

    // ── 2. Atividades e Serviços ──
    window.__passarinho_step_desc = "Atividades e Serviços…";
    await abrirAba("Escolha as Atividades");
    const serv = await escolher(acharLista("servico", "Serviço"), ["Emitir Guia de Tráfego Pessoa Física (CAC)", "Emitir Guia de Tráfego Pessoa Física", "Guia de Tráfego"]);
    if (serv) n++; else faltou.push("Serviço (Guia de Tráfego)");
    await esperar(1200);   // o site carrega taxa, atividades e PCE do serviço
    if (await marcar(await ate(() => acharLista("tipoAtividade", "Tipo de Atividade"), 8000), ["Tiro Desportivo - Atirador Desportivo", "Tiro Desportivo", "Atirador Desportivo"])) n++;
    else faltou.push(`Tipo de Atividade (${vistoNaLista})`);
    await esperar(800);
    // Finalidade ANTES do PCE: no site real o Tipo de PCE fica bloqueado até escolher a finalidade
    // (o menu mostrou "Tipo de PCE (lista desabilitada)" com a finalidade ainda vazia)
    if (await escolher(await ate(() => acharLista("finalidade", "Tipo de Finalidade"), 8000), ["TREINAMENTO TIRO DESPORTIVO", "Treinamento"])) n++;
    else faltou.push("Tipo de Finalidade");
    await esperar(800);
    if (await marcar(await ate(() => acharLista("pces", "Tipo de PCE"), 8000), ["ARMA DE FOGO"], 15000)) n++; else faltou.push(`Tipo de PCE (${vistoNaLista})`);
    await esperar(800);

    // ── 3. Local de origem, Local de destino e documento ──
    window.__passarinho_step_desc = "Locais e documento…";
    let aba3 = false;
    for (const aba of ["Condições de Exigência", "Condições", "3."]) { aba3 = await abrirAba(aba); if (aba3) break; }
    if (aba3 !== true) {
      // sem a etapa 3 aberta não adianta seguir: avisa o motivo (normalmente falta algo na etapa 2)
      faltou.unshift(aba3 === "bloqueada" ? "a etapa 3 está bloqueada pelo site: falta completar a etapa 2" : "não consegui abrir a etapa 3");
      const msg = `Parei na etapa 3. Confira: ${faltou.join(", ")}.`;
      return encerrar({ n, msg });
    }
    await esperar(800);
    // Local de origem: o endereço do próprio cliente já vem na lista "Endereço Sigma"
    const sigma = await ate(() => acharLista("enderecoSigma", "Endereço Sigma"), 8000);
    if (sigma) {
      // No site o Endereço Sigma ficou vazio (vermelho): a lista vazia mostra algum texto ("-- Selecione --") e a extensão
      // achava que já havia endereço. Agora sempre escolhe o do cliente (ou o 1º da lista) e confere no rótulo
      const rotulo = () => norm(sigma.querySelector(".ui-dropdown-label")?.innerText).replace(/[^a-z0-9 ,]/g, "").trim();
      const rua = norm(String(cliente?.endereco || "").split(/[,-]/)[0]).replace(/^(rua|r\.|avenida|av\.?|travessa|tv\.?|estrada)\s+/, "");
      let ok = false;
      for (let t = 0; t < 2 && !ok; t++) {
        const escolhido = await escolher(sigma, rua ? [rua] : [], { primeiro: true });
        await esperar(500);
        ok = !!escolhido && rotulo().includes(norm(escolhido).replace(/[^a-z0-9 ,]/g, "").trim().slice(0, 6));
      }
      if (ok) n++; else faltou.push("Endereço Sigma (origem)");
    } else faltou.push("Endereço Sigma (origem)");

    // Local de destino: dentro do quadro "Local de destino" (origem e destino têm campos com o mesmo nome)
    if (evento) {
      const quadro = [...document.querySelectorAll("fieldset, p-fieldset, .ui-fieldset")].find(f => /local de destino/.test(norm(f.querySelector("legend")?.innerText)))
        || document;
      const campo = nome => [...quadro.querySelectorAll(`input[name='${nome}']`)].find(visivel);
      if (escrever(campo("nomeEvento"), evento.nome)) n++; else faltou.push("Nome Evento");
      const UFS = { AM: "Amazonas", PA: "Pará", SP: "São Paulo", RJ: "Rio de Janeiro", RR: "Roraima", AC: "Acre", RO: "Rondônia" };
      const uf = String(evento.uf || "").toUpperCase();
      if (await escolher(acharLista("uf", "UF", quadro), [uf, UFS[uf] || uf, `${uf} - ${UFS[uf] || ""}`])) { n++; await esperar(1500); } else faltou.push("UF do destino");
      if (await escolher(await ate(() => acharLista("cidade", "Cidade", quadro), 6000), [evento.cidade])) { n++; await esperar(800); }
      else if (escrever(campo("cidade"), evento.cidade)) n++; else faltou.push("Cidade do destino");
      if (evento.bairro) {
        const bai = acharLista("bairro", "Bairro", quadro);
        if (bai) { if (await escolher(bai, [evento.bairro])) n++; } else escrever(campo("bairro"), evento.bairro);
      }
      if (escrever(campo("logradouro"), evento.logradouro)) n++; else faltou.push("Logradouro do destino");
      if (evento.numero && escrever(campo("numero"), String(evento.numero).replace(/\D/g, ""))) n++;
    } else faltou.push("evento (não escolhido)");

    // Documento de identificação: na linha do documento, tipo "Carteira de identidade" e o arquivo da ficha do cliente
    window.__passarinho_step_desc = "Documento de identificação…";
    const linhaDoc = await ate(() => [...document.querySelectorAll("tr, .ui-g, .ui-g-12, div")].filter(visivel)
      .filter(el => /identifica/.test(norm(el.innerText)) && el.querySelector(".ui-fileupload, p-fileupload, input[type=file]"))
      .sort((a, b) => a.innerText.length - b.innerText.length)[0], 8000);
    if (!linhaDoc) faltou.push("Documento de identificação (linha não encontrada)");
    else {
      const tipo = linhaDoc.querySelector(".ui-dropdown");
      if (tipo) { if (await escolher(tipo, ["Carteira de identidade", "Carteira de Identidade", "identidade", "RG"])) n++; else faltou.push("tipo do documento (Carteira de identidade)"); }
      if (!ident?.base64) faltou.push("arquivo de identidade (anexe o RG/CNH na ficha do cliente em Clientes Armas)");
      else {
        const nomeArq = ident.nome || "identidade.pdf";
        const ehPdf = /\.pdf$/i.test(nomeArq) || ident.base64.startsWith("JVBER");
        let bytes = Uint8Array.from(atob(ident.base64), c => c.charCodeAt(0));
        let arquivo = new File([bytes], ehPdf ? nomeArq : nomeArq.replace(/\.\w+$/, "") + ".jpg", { type: ehPdf ? "application/pdf" : "image/jpeg" });
        // o site aceita até 1 MB: imagem grande é reduzida aqui (JPG); PDF grande não dá para reduzir
        if (!ehPdf && (arquivo.size > 1000000 || !/\.jpe?g$/i.test(nomeArq))) {
          const img = await createImageBitmap(new Blob([bytes]));
          let escala = Math.min(1, 2200 / Math.max(img.width, img.height)), q = 0.85, blob = null;
          for (let i = 0; i < 6; i++) {
            const cv = document.createElement("canvas");
            cv.width = Math.round(img.width * escala); cv.height = Math.round(img.height * escala);
            cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
            blob = await new Promise(r => cv.toBlob(r, "image/jpeg", q));
            if (blob.size <= 950000) break;
            escala *= 0.8; q = Math.max(0.6, q - 0.08);
          }
          arquivo = new File([blob], arquivo.name, { type: "image/jpeg" });
        }
        if (arquivo.size > 1000000) faltou.push(`identidade: o PDF tem ${(arquivo.size / 1e6).toFixed(1)} MB e o site aceita até 1 MB (anexe à mão uma versão menor)`);
        else {
          const inp = linhaDoc.querySelector("input[type=file]");
          const dt = new DataTransfer(); dt.items.add(arquivo);
          inp.files = dt.files;
          inp.dispatchEvent(new Event("change", { bubbles: true }));
          await esperar(800);
          // customUpload: depois de escolher o arquivo é preciso clicar no botão de enviar da própria linha
          const enviar = [...linhaDoc.querySelectorAll(".ui-fileupload-buttonbar button, button")].find(b => visivel(b) && !b.disabled &&
            /upload|enviar|carregar|ui-icon-file-upload|fa-upload/i.test(b.innerText + " " + b.className + " " + (b.getAttribute("icon") || "") + " " + (b.querySelector("[class*=upload]")?.className || "")));
          if (enviar) clicar(enviar);
          if (await ate(() => /\.(pdf|jpe?g)/i.test(linhaDoc.innerText) && !linhaDoc.querySelector(".ui-fileupload-content .ui-fileupload-row"), 6000)) n++;
          else faltou.push("arquivo de identidade (confira se foi anexado)");
        }
      }
    }

    // PCE: clica em "Cadastrar" do quadro PCE para abrir a escolha da arma (o usuário escolhe e faz o resto à mão)
    window.__passarinho_step_desc = "Abrindo o cadastro do PCE…";
    const quadroPce = [...document.querySelectorAll("fieldset, p-fieldset, .ui-fieldset")]
      .find(f => norm(f.querySelector("legend")?.innerText) === "pce");
    const cadastrarEm = raiz => [...raiz.querySelectorAll("button, a")].filter(b => visivel(b) && !b.disabled && norm(b.innerText) === "cadastrar");
    // sem o quadro: só se houver um único "Cadastrar" na página (não arrisca clicar no botão errado)
    const btnCadastrar = quadroPce ? cadastrarEm(quadroPce)[0] : (cadastrarEm(document).length === 1 ? cadastrarEm(document)[0] : null);
    let abriuPce = false;
    if (btnCadastrar) { clicar(btnCadastrar); abriuPce = true; await esperar(800); }
    else faltou.push("botão Cadastrar do PCE (clique à mão)");

    const msg = `GT preenchido: ${abriuPce ? "abri o Cadastrar do PCE, escolha a arma" : "escolha o armamento na tabela PCE"}, confira e envie.${faltou.length ? " Confira: " + faltou.join(", ") + "." : ""}`;
    return encerrar({ n, msg });
  } catch (e) {
    if (e.message === "__passarinho_parado__") { if (window.__passarinho_exec === meuExec || window.__passarinho_exec === null) { window.__passarinho_rodando = false; window.__passarinho_waiting = false; window.__passarinho_parar = false; window.__passarinho_resultado = { n: 0, parado: true }; } return { n: 0, parado: true }; }
    return encerrar({ n: 0, msg: `Erro no GT: ${e.message?.slice(0, 120)}` });
  }
}

// ── SisGCorp (sisgcorp.eb.mil.br): "Cadastro inicial SisGCorp" ──
// Caminho que o usuário passou: Solicitação de Serviço → Pessoa Física → (Informar) Dados Iniciais → Incluir Cadastro.
// Na tela "Incluir Cadastro do Solicitante" preenche os dados do cliente e o Endereço Residencial (CEP + lupa),
// clica em "Buscar no Mapa" do 1º endereço e PARA: o segundo endereço fica em branco, quem salva é o usuário.
// Campos (lidos do código do site, PrimeNG antigo): rg, dtExpedicao (p-calendar), orgaoEmissor, ufRg (p-dropdown),
// dtNascimento (p-calendar), pais, profissoes (p-dropdown), ocupacao (Outra Profissão), telefone (máscara), email,
// nomeMae, nomePai, cep1 (máscara), endereco1, ufEndereco1/cidade1/bairro1 (p-dropdown), n1, complemento1.
// Coordenadas do endereço do cliente pelo Google Maps, sem chave de API: abre a busca numa aba escondida (na mesma
// janela do SisGCorp, para valer também na janela anônima), espera o Google ir para o lugar achado e lê o pino da
// URL (!3d<lat>!4d<lon> é o ponto exato; @lat,lon é só o centro da tela). Fecha a aba. Sem resultado: null.
async function coordenadasGoogleMaps(c, windowId) {
  if (!c) return null;
  const limpar = r => String(r || "").replace(/\s+-\s+.*$/, "").replace(/\(.*?\)/g, "").replace(/\s+/g, " ").trim();
  const rua = limpar(c.endereco);
  if (!rua || !c.cidade) return null;
  const cep = String(c.cep || "").replace(/\D/g, "");
  const endereco = [
    [rua, String(c.numero || "").trim()].filter(Boolean).join(", "),
    c.bairro, [c.cidade, c.estado].filter(Boolean).join(" - "),
    cep.length === 8 ? `${cep.slice(0, 5)}-${cep.slice(5)}` : "", "Brasil",
  ].filter(Boolean).join(", ");
  let aba = null;
  try {
    aba = await chrome.tabs.create({ url: "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(endereco), active: false, ...(windowId ? { windowId } : {}) });
    const fim = Date.now() + 25000;
    let centro = null;
    while (Date.now() < fim) {
      await new Promise(r => setTimeout(r, 700));
      const url = decodeURIComponent((await chrome.tabs.get(aba.id).catch(() => null))?.url || "");
      const pino = url.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
      if (pino) return { lat: Number(pino[1]), lon: Number(pino[2]), fonte: "google" };
      // lugar achado sem o pino na URL: usa o centro, que no lugar achado é o próprio endereço
      const m = url.match(/\/maps\/place\/[^@]*@(-?\d+\.\d+),(-?\d+\.\d+),(\d+(?:\.\d+)?)z/);
      if (m && Number(m[3]) >= 15) centro = { lat: Number(m[1]), lon: Number(m[2]), fonte: "google" };
      if (centro && Date.now() > fim - 20000) return centro;
    }
    return centro;
  } catch (_) {
    return null;
  } finally {
    if (aba) chrome.tabs.remove(aba.id).catch(() => {});
  }
}

async function injectarSisgcorp(cliente, coordsGoogle = null) {
  window.__passarinho_rodando = true; window.__passarinho_vivo = 0; window.__passarinho_passo = ""; // só o CR marca a hora
  window.__passarinho_waiting = false;
  window.__passarinho_modo = "sisgcorp";
  window.__passarinho_resultado = null;
  window.__passarinho_step_desc = "";
  window.__passarinho_parar = false;
  window.__passarinho_pausado = false;
  // identificação deste preenchimento: ⏹ Parar (ou um preenchimento novo) a troca, e este para na próxima espera/clique
  var meuExec = Math.random().toString(36).slice(2);
  window.__passarinho_exec = meuExec;
  const parou = () => window.__passarinho_parar || window.__passarinho_exec !== meuExec;
  const encerrar = r => { if (window.__passarinho_exec !== meuExec) return r; window.__passarinho_resultado = r; window.__passarinho_rodando = false; return r; };
  try {
    const esperar = async ms => {
      if (parou()) throw new Error("__passarinho_parado__");
      await new Promise(r => setTimeout(r, ms));
      while (window.__passarinho_pausado && !parou()) await new Promise(r => setTimeout(r, 300));   // ⏸ Pausar
      if (parou()) throw new Error("__passarinho_parado__");
    };
    const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
    const visivel = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
    const ate = async (fn, ms = 10000) => { const fim = Date.now() + ms; while (Date.now() < fim) { const r = fn(); if (r) return r; await esperar(200); } return null; };
    const clicar = el => {
      if (parou()) throw new Error("__passarinho_parado__");
      el.scrollIntoView({ block: "center" });
      for (const t of ["mousedown", "mouseup", "click"]) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    };
    const dataBr = v => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v || ""); return m ? `${m[3]}/${m[2]}/${m[1]}` : (v || ""); };
    const so = v => String(v || "").replace(/\D/g, "");
    let n = 0;
    const faltou = [];

    // Elemento clicável com o texto (o menor que bate: o item, não o menu inteiro)
    const porTexto = txt => {
      const alvo = norm(txt);
      const els = [...document.querySelectorAll("a, button, li, span, p, div, label, [role=menuitem]")].filter(visivel);
      let c = els.filter(e => norm(e.innerText) === alvo);
      if (!c.length) c = els.filter(e => { const t = norm(e.innerText); return t.includes(alvo) && t.length <= alvo.length + 30; });
      // o mais de dentro (o item em si): o clique sobe dele para o link/menu; no de fora não chegaria no item
      c = c.filter(e => !c.some(o => o !== e && e.contains(o)));
      c.sort((a, b) => a.innerText.length - b.innerText.length);
      return c[0] || null;
    };
    const temForm = () => visivel(document.querySelector("input[name='rg']"));

    // ── 1. Abrir a tela "Incluir Cadastro do Solicitante" ──
    if (!temForm()) {
      window.__passarinho_step_desc = "Abrindo o cadastro inicial…";
      if (!/manter-cadastro-inicial/.test(location.hash)) {
        // pelo menu, como o usuário faz; o 3º item pode se chamar "Informar Dados Iniciais" ou "Cadastrar Dados Iniciais"
        for (const txt of ["Solicitação de Serviço", "Pessoa Física", "Dados Iniciais"]) {
          if (/manter-cadastro-inicial/.test(location.hash)) break;
          const el = await ate(() => porTexto(txt), 4000);
          if (!el) break;
          clicar(el);
          await esperar(900);
        }
        // menu com outro nome: vai direto pelo endereço da página
        if (!await ate(() => /manter-cadastro-inicial/.test(location.hash), 4000)) location.hash = "#/cadastro/manter-cadastro-inicial";
      }
      const incluir = await ate(() => porTexto("Incluir Cadastro"), 15000);
      if (!incluir) return encerrar({ n: 0, msg: "Não achei o botão \"Incluir Cadastro\". Abra a tela do cadastro inicial e tente de novo." });
      clicar(incluir);
      if (!await ate(temForm, 15000)) return encerrar({ n: 0, msg: "A tela \"Incluir Cadastro do Solicitante\" não abriu." });
      await esperar(800);
    }
    window.__passarinho_step_desc = "Preenchendo…";

    // ── Ajudantes dos campos ──
    const campo = nome => {
      const els = [...document.querySelectorAll(`[name='${nome}']`)].filter(visivel);
      return els.find(e => e.matches("input, textarea")) || els[0] || null;
    };
    const entrada = nome => { const c = campo(nome); return !c ? null : c.matches("input, textarea") ? c : c.querySelector("input"); };
    // o primeiro nome que existe na tela (o site usa nomes diferentes na caixa e no campo de dentro)
    const qual = (...nomes) => nomes.find(nm => campo(nm)) || nomes[0];
    const bloqueado = el => el.disabled || el.readOnly || el.closest(".ui-state-disabled");
    const escrever = (el, valor, { soSeVazio = false } = {}) => {
      if (!el || valor == null || valor === "" || bloqueado(el)) return false;
      if (soSeVazio && el.value.trim()) return false;
      el.focus();
      // keydown antes: o calendário do site (PrimeNG) só aceita o que foi digitado depois de uma tecla; sem ela
      // ignorava a data e apagava o campo ao sair dele ("Preenchimento obrigatório")
      el.dispatchEvent(new KeyboardEvent("keydown", { key: "0", code: "Digit0", keyCode: 48, which: 48, bubbles: true }));
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, valor);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent("keyup", { key: "0", code: "Digit0", keyCode: 48, which: 48, bubbles: true }));
      el.dispatchEvent(new Event("blur", { bubbles: true }));
      el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
      return true;
    };
    const texto = (nome, valor, rotulo, op) => {
      if (!valor) return;
      if (escrever(entrada(nome), String(valor), op)) n++;
      else if (!op?.soSeVazio) faltou.push(rotulo);
    };
    // Calendário PrimeNG: digita dd/mm/aaaa no campo e fecha o calendário que abre
    const data = async (nome, valor, rotulo) => {
      if (!valor) return;
      const el = entrada(nome);
      if (!escrever(el, dataBr(valor))) { faltou.push(rotulo); return; }
      n++;
      await esperar(300);
      document.body.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      document.body.click();
      el.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    };
    // Lista PrimeNG (p-dropdown): abre, escolhe a opção que mais combina e fecha. textos: do mais exato ao mais solto
    const itensAbertos = () => [...document.querySelectorAll(".ui-dropdown-items li, li.ui-dropdown-item, .ui-dropdown-item")].filter(visivel);
    const escolher = async (nome, textos, { aceitar, antes } = {}) => {
      const host = campo(nome);
      const dd = host && (host.matches(".ui-dropdown") ? host : host.querySelector(".ui-dropdown") || host);
      if (!dd) return null;
      if (!await ate(() => !dd.matches(".ui-state-disabled") && !dd.closest(".ui-state-disabled"), 8000)) return null;
      clicar(dd);
      if (!await ate(() => itensAbertos().length, 6000)) return null;
      if (antes) await antes();
      const itens = await ate(() => { const l = itensAbertos(); return l.length ? l : null; }, 3000);
      if (!itens) { clicar(dd); return null; }
      const alvos = textos.filter(Boolean).map(norm);
      let achado = null;
      for (const a of alvos) { achado = itens.find(li => norm(li.innerText) === a); if (achado) break; }
      if (!achado) for (const a of alvos) { achado = itens.find(li => norm(li.innerText).startsWith(a)); if (achado) break; }
      if (!achado) for (const a of alvos) { if (a.length >= 4) achado = itens.find(li => norm(li.innerText).includes(a)); if (achado) break; }
      if (!achado && aceitar) achado = aceitar(itens);
      if (!achado) { clicar(dd); await esperar(200); return null; }
      clicar(achado);
      await esperar(400);
      return achado.innerText.trim();
    };
    const UFS = { AC: "Acre", AL: "Alagoas", AP: "Amapá", AM: "Amazonas", BA: "Bahia", CE: "Ceará", DF: "Distrito Federal",
      ES: "Espírito Santo", GO: "Goiás", MA: "Maranhão", MT: "Mato Grosso", MS: "Mato Grosso do Sul", MG: "Minas Gerais",
      PA: "Pará", PB: "Paraíba", PR: "Paraná", PE: "Pernambuco", PI: "Piauí", RJ: "Rio de Janeiro", RN: "Rio Grande do Norte",
      RS: "Rio Grande do Sul", RO: "Rondônia", RR: "Roraima", SC: "Santa Catarina", SP: "São Paulo", SE: "Sergipe", TO: "Tocantins" };
    const siglaUf = v => { const t = norm(v).toUpperCase(); if (UFS[t]) return t; return Object.keys(UFS).find(k => norm(UFS[k]) === norm(v)) || ""; };
    const textosUf = sigla => sigla ? [sigla, UFS[sigla], `${sigla} - ${UFS[sigla]}`] : [];

    // ── 2. Documento e nascimento ──
    // Órgão emissor "SSP-AM" / "SSP/AM": no SisGCorp o órgão e a UF são campos separados
    const orgaoTxt = String(cliente.orgao_emissor || "").trim();
    const mOrg = /^(.*?)[\s\/\-]+([A-Za-z]{2})$/.exec(orgaoTxt);
    const ufDoOrgao = mOrg && siglaUf(mOrg[2]) ? siglaUf(mOrg[2]) : "";
    texto("rg", cliente.rg, "Nº Identidade");
    await data("dtExpedicao", cliente.data_expedicao, "Data de Expedição");
    texto("orgaoEmissor", ufDoOrgao ? mOrg[1].trim().toUpperCase() : orgaoTxt.toUpperCase(), "Órgão Emissor");
    const ufRg = ufDoOrgao || siglaUf(cliente.estado);
    if (ufRg) { if (await escolher("ufRg", textosUf(ufRg))) n++; else faltou.push("UF do RG"); }
    await data("dtNascimento", cliente.data_nascimento, "Data de Nascimento");
    if (await escolher("pais", ["Brasil", "Brazil"])) n++; else faltou.push("País");
    // Com Brasil aparecem UF (uf2) e Local de Nascimento (local, lista de cidades que carrega depois da UF)
    const ufNasc = siglaUf(cliente.uf_nascimento);
    if (ufNasc) {
      await ate(() => campo("uf2"), 5000);
      if (await escolher("uf2", textosUf(ufNasc))) {
        n++;
        if (cliente.local_nascimento) {
          await esperar(1200);
          if (await escolher("local", [cliente.local_nascimento])) n++; else faltou.push("Local de Nascimento");
        }
      } else faltou.push("UF de nascimento");
    } else if (cliente.local_nascimento) faltou.push("UF de nascimento (sem UF no sistema)");

    // ── 3. Profissão: sempre "Outra" na lista (o usuário pediu) e a profissão do cliente em "Outra Profissão" ──
    // A lista é longa e tem busca no topo: digita "Outra" na busca para a opção aparecer
    const prof = String(cliente.profissao || "").trim();
    if (prof) {
      const filtrar = async () => {
        const f = [...document.querySelectorAll(".ui-dropdown-filter, .ui-dropdown-filter-container input")].find(visivel);
        if (f) { escrever(f, "Outra"); f.focus(); await esperar(500); }
      };
      const escolhida = await escolher("profissoes", ["Outra", "Outras", "Outro", "Outros"], { antes: filtrar,
        aceitar: itens => itens.find(li => /^outr/.test(norm(li.innerText))) || null });
      if (escolhida) {
        n++;
        await ate(() => { const o = entrada("ocupacao"); return o && !bloqueado(o); }, 4000);
        texto("ocupacao", prof.toUpperCase(), "Outra Profissão");
      } else faltou.push("Profissão (não achei \"Outra\")");
    }

    // Título de eleitor (campo da ficha do cliente em Clientes Armas)
    texto("nTituloEleitor", String(cliente.titulo_eleitor || "").replace(/\D/g, ""), "Nº Título de Eleitor");

    // ── 4. Contato e filiação (telefone e e-mail o site já traz do gov.br: só preenche se estiverem vazios) ──
    texto("telefone", cliente.telefone, "Telefone 1", { soSeVazio: true });
    texto("email", cliente.email, "Email", { soSeVazio: true });
    texto("nomeMae", String(cliente.nome_mae || "").toUpperCase(), "Nome da Mãe");
    texto("nomePai", String(cliente.nome_pai || "").toUpperCase(), "Nome do Pai");

    // ── 5. Endereço Residencial: CEP + lupa; o que a busca não trouxer, preenche com os dados do sistema ──
    const cep = so(cliente.cep);
    if (cep.length === 8) {
      const elCep = entrada("cep1");
      // a máscara do site é "99-999-999": digita só os números e ela formata (69054110 → 69-054-110)
      if (escrever(elCep, cep)) {
        n++;
        await esperar(600);
        // A busca do CEP (buscaEndereco no site) roda com Enter no campo ou na lupa. A lupa é só ícone, sem texto:
        // por isso a busca não rodava e UF/Cidade ficavam vazias. Enter primeiro; se não vier nada, a lupa pelo ícone
        const carregando = () => [...document.querySelectorAll(".block-ui-wrapper, .block-ui-spinner, [class*='blockui'], [class*='block-ui']")].some(visivel);
        const veio = () => entrada(qual("endereco1", "endereco"))?.value.trim();
        const enter = t => elCep.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
        elCep.focus(); enter("keydown"); enter("keypress"); enter("keyup");
        if (!await ate(veio, 5000)) {
          const lupa = [...document.querySelectorAll("button")].filter(b => visivel(b) &&
            (/search/.test(b.innerText) || /search/.test(b.className + " " + (b.getAttribute("icon") || "") + " " + (b.querySelector("[class*='search']")?.className || ""))) &&
            (elCep.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING))[0];
          if (lupa) { clicar(lupa); await ate(veio, 10000); }
        }
        if (veio()) {
          // depois do endereço o site carrega a lista de cidades e a de bairros: espera terminar
          await esperar(800);
          await ate(() => !carregando(), 15000);
          await esperar(800);
        } else faltou.push("busca do CEP (o site não trouxe o endereço)");
      } else faltou.push("CEP");
    } else if (cliente.cep) faltou.push("CEP (inválido no sistema)");

    // No formulário do site o bloco do endereço se chama endereco1/ufEndereco1/cidade1/bairro1 (caixa em volta)
    // e as listas dentro dele uf/cidade/bairro: vale o que existir
    const nEnd = qual("endereco1", "endereco"), nUf = qual("ufEndereco1", "uf"), nCid = qual("cidade1", "cidade"), nBai = qual("bairro1", "bairro");
    const elEnd = entrada(nEnd);
    if (elEnd && !elEnd.value.trim()) texto(nEnd, String(cliente.endereco || "").toUpperCase(), "Endereço Residencial");
    const selecionado = nome => norm(campo(nome)?.querySelector(".ui-dropdown-label")?.innerText || "");
    const vazioDd = nome => { const s = selecionado(nome); return !s || /^selecione/.test(s); };
    const ufEnd = siglaUf(cliente.estado);
    if (vazioDd(nUf) && ufEnd) { if (await escolher(nUf, textosUf(ufEnd))) { n++; await esperar(1500); } else faltou.push("UF do endereço"); }
    if (vazioDd(nCid) && cliente.cidade) { if (await escolher(nCid, [cliente.cidade])) { n++; await esperar(1200); } else faltou.push("Cidade"); }
    if (vazioDd(nBai) && cliente.bairro) { if (await escolher(nBai, [cliente.bairro])) n++; else faltou.push("Bairro"); }
    // Nº: o campo cujo rótulo é "Nº" (n1 ou n2 no código do site)
    const rotuloDe = el => norm(el?.closest(".md-inputfield, .ui-g-12, [class*='ui-md'], [class*='col']")?.querySelector("label")?.innerText || "");
    const elNum = ["n1", "n2"].map(entrada).find(el => el && /^n[ºo°]?$/.test(rotuloDe(el).replace(/[^a-zºo°]/g, ""))) || entrada("n1");
    if (cliente.numero) { if (escrever(elNum, String(cliente.numero))) n++; else faltou.push("Nº"); }
    texto("complemento1", String(cliente.complemento || "").toUpperCase(), "Complemento");

    // ── 6. Latitude e longitude pelo endereço (OpenStreetMap, o mesmo serviço que o próprio site usa), depois "Buscar no Mapa" ──
    // O mapa do site só funciona com as coordenadas preenchidas. Procura do mais exato (rua + número + CEP) ao menos;
    // só aceita resultado de rua/casa: coordenada só da cidade ficaria errada, aí deixa para o usuário
    const elLat = entrada("latitude1"), elLon = entrada("longitude1");
    let avisoMapa = "";
    if (!elLat || !elLon) faltou.push("Latitude/Longitude (campos não encontrados)");
    else if (!elLat.value.trim() && coordsGoogle && isFinite(coordsGoogle.lat) && isFinite(coordsGoogle.lon)) {
      // achadas no Google Maps antes de começar (coordenadasGoogleMaps, no popup)
      if (escrever(elLat, Number(coordsGoogle.lat).toFixed(7)) && escrever(elLon, Number(coordsGoogle.lon).toFixed(7))) n += 2;
      else faltou.push("Latitude/Longitude (campo bloqueado)");
    } else if (!elLat.value.trim()) {
      // reserva: o Google Maps não achou → OpenStreetMap
      // nome da rua limpo: a busca de CEP traz coisas como "Avenida X - até 500/501" ou "Rua Y (Lot Z)"
      const limpar = r => String(r || "").replace(/\s+-\s+.*$/, "").replace(/\(.*?\)/g, "").replace(/,.*$/, "").replace(/\s+/g, " ").trim();
      const ruas = [...new Set([limpar(elEnd?.value), limpar(cliente.endereco)].filter(Boolean))];
      const cidade = (campo(nCid)?.querySelector(".ui-dropdown-label")?.innerText || "").trim();
      const cidadeOk = cidade && !/^selecione/i.test(cidade) ? cidade : (cliente.cidade || "");
      const ufNome = UFS[ufEnd] || cliente.estado || "";
      const bairro = (campo(nBai)?.querySelector(".ui-dropdown-label")?.innerText || "").trim();
      const bairroOk = bairro && !/^selecione/i.test(bairro) ? bairro : (cliente.bairro || "");
      const num = String(cliente.numero || "").replace(/\D.*$/, "");
      const cepFmt = cep.length === 8 ? `${cep.slice(0, 5)}-${cep.slice(5)}` : "";
      const tentativas = [];
      for (const rua of ruas) {
        if (num) tentativas.push({ street: `${num} ${rua}`, city: cidadeOk, state: ufNome });
        tentativas.push({ street: rua, city: cidadeOk, state: ufNome });
        tentativas.push({ q: [rua, bairroOk, cidadeOk, ufNome].filter(Boolean).join(", ") });
      }
      if (cepFmt) tentativas.push({ postalcode: cepFmt, city: cidadeOk });
      const buscar = async t => {
        const p = new URLSearchParams({ ...Object.fromEntries(Object.entries(t).filter(([, v]) => v)), countrycodes: "br", format: "json", limit: "1", addressdetails: "1" });
        try { return (await (await fetch("https://nominatim.openstreetmap.org/search?" + p)).json())?.[0] || null; } catch (_) { return null; }
        finally { await esperar(1100); } // o OpenStreetMap pede no máximo 1 busca por segundo
      };
      let ponto = null;
      if (cidadeOk) for (const t of tentativas) {
        const a = await buscar(t);
        // achou a rua (ou a casa); resultado só de cidade não serve (ficaria longe da casa)
        if (a && (a.address?.road || a.address?.house_number || ["highway", "building"].includes(a.class) || a.type === "house")) { ponto = a; break; }
      }
      // último recurso: o ponto do bairro (aproximado), para o mapa abrir perto; o usuário ajusta no mapa
      if (!ponto && bairroOk && cidadeOk) {
        const a = await buscar({ q: [bairroOk, cidadeOk, ufNome].filter(Boolean).join(", ") });
        if (a && (a.address?.suburb || a.address?.neighbourhood || a.address?.quarter || /suburb|neighbourhood|quarter/.test(a.addresstype || a.type))) {
          ponto = a; avisoMapa = "Coordenada aproximada (do bairro): ajuste o ponto no mapa.";
        }
      }
      if (ponto) {
        if (escrever(elLat, Number(ponto.lat).toFixed(7)) && escrever(elLon, Number(ponto.lon).toFixed(7))) n += 2;
        else faltou.push("Latitude/Longitude (campo bloqueado)");
      } else faltou.push("Latitude/Longitude (endereço não achado no mapa)");
    }
    const mapa = [...document.querySelectorAll("button")].find(b => visivel(b) && norm(b.innerText).includes("buscar no mapa"));
    if (mapa) { clicar(mapa); await esperar(1500); }

    const msg = [faltou.length ? `Preenchi ${n} campo(s). Confira: ${faltou.join(", ")}.` : "", avisoMapa].filter(Boolean).join(" ");
    return encerrar({ n, msg });
  } catch (e) {
    if (e.message === "__passarinho_parado__") { if (window.__passarinho_exec === meuExec || window.__passarinho_exec === null) { window.__passarinho_rodando = false; window.__passarinho_waiting = false; window.__passarinho_parar = false; window.__passarinho_resultado = { n: 0, parado: true }; } return { n: 0, parado: true }; }
    return encerrar({ n: 0, msg: `Erro no SisGCorp: ${e.message?.slice(0, 120)}` });
  }
}

async function injectarPf(arquivos, modo = "cr") {
  try {
  const config = {
    cr: {
      servico: "concess", atividade: "tiro desport", pce: "arma de fogo",
      opcoesSec3: ["capacidade","federal","declaracao","identidade","laudo","residencia","ocupacao","endereco","estadual","seguranca","compromisso","filia","militar","eleitoral"],
      mapaArq: [1,2,3,4,5,6,7,8,9,10,11,12,13,14],
    },
    ac: {
      servico: "autoriza", atividade: "tiro desport", pce: "arma de fogo",
      opcoesSec3: ["capacidade","habitual","seguranca","federal","declaracao","identidade","laudo","residencia","ocupacao","militar","estadual","eleitoral"],
      mapaArq: [1,2,3,4,5,6,7,8,9,10,11,12],
    },
  };
  const cfg = config[modo] || config.cr;
  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
  function norm(s) { return (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }

  async function aguardarEl(pred, ms = 4000) {
    const fim = Date.now() + ms;
    while (Date.now() < fim) { const el = pred(); if (el) return el; await delay(150); }
    return null;
  }

  async function aguardarOpcao(pred, ms = 4000) {
    return aguardarEl(() => {
      // Cobre: Angular Material, PrimeNG (ui-/p- prefix), Select2, nativos
      const opts = [...document.querySelectorAll(
        "mat-option, .mat-option, li[role='option'], option, " +
        "li.ui-dropdown-item, li.p-dropdown-item, " +
        ".ui-dropdown-item, .p-dropdown-item, " +
        "li.ui-multiselect-item, li.p-multiselect-item, " +
        ".select2-results__option, .chosen-result"
      )];
      return opts.find(o => pred(o));
    }, ms);
  }

  async function selecionar(labelTxt, opcaoTxt) {
    const labels = [...document.querySelectorAll("label, mat-label, span, div, legend, th, td")];
    for (const lbl of labels) {
      if (!norm(lbl.textContent).includes(norm(labelTxt))) continue;
      const cont = lbl.closest("mat-form-field, .form-group, .field, fieldset, td, div") || lbl.parentElement;
      if (!cont) continue;
      const ms = cont.querySelector("mat-select, [role='listbox'], [role='combobox']");
      if (ms) {
        ms.click(); await delay(400);
        const opt = await aguardarOpcao(o => norm(o.textContent).includes(norm(opcaoTxt)));
        if (opt) { opt.click(); await delay(300); return true; }
        document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); await delay(200);
      }
      const ns = cont.querySelector("select");
      if (ns) {
        const opt = [...ns.options].find(o => norm(o.text).includes(norm(opcaoTxt)));
        if (opt) { ns.value = opt.value; ns.dispatchEvent(new Event("change", { bubbles: true })); return true; }
      }
    }
    return false;
  }

  let n = 0, dbg = "";

  // Detecta se já está na tela do formulário (seções 1-5 visíveis)
  function noFormulario() {
    return [...document.querySelectorAll("*")].some(el => {
      const t = el.textContent.trim();
      return t.length > 5 && t.length < 100 && (
        norm(t).includes("escolha as atividades") ||
        norm(t).includes("preencha as condicoes") ||
        norm(t).includes("confira os dados do solicitante") ||
        norm(t).includes("gere gru")
      );
    });
  }

  async function clicarTexto(texto, timeout = 3000) {
    // Prioriza elementos interativos (a, button) antes de divs genéricos
    const prioridade = ["a", "button", "[role='menuitem']", "[role='button']", "li", "span", "div"];
    const el = await aguardarEl(() => {
      for (const sel of prioridade) {
        const found = [...document.querySelectorAll(sel)]
          .filter(el => {
            const t = el.textContent.trim();
            return t.length > 1 && t.length < 120 && norm(t).includes(norm(texto));
          })
          .sort((a, b) => a.textContent.trim().length - b.textContent.trim().length)[0];
        if (found) return found;
      }
      return null;
    }, timeout);
    if (el) {
      el.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      el.click();
      dbg += `>${texto.slice(0, 5)}`;
      return true;
    }
    dbg += `>x${texto.slice(0, 5)}`; return false;
  }

  function naListaProcessos() {
    // Só considera "Lista de Processos" se for o título principal da página (h1/h2)
    // ou se o breadcrumb mostrar "Listar Processos" como destino final
    const porHeading = [...document.querySelectorAll("h1, h2, h3, .page-title, [class*='titulo'], [class*='title']")]
      .some(el => {
        const t = el.textContent.trim();
        return t.length < 60 && norm(t).includes("lista de processo");
      });
    if (porHeading) return true;

    // Verifica breadcrumb: último item deve ser "Listar Processos"
    const breadcrumb = document.querySelector(".ui-breadcrumb, .breadcrumb, [class*='breadcrumb']");
    if (breadcrumb) {
      const items = [...breadcrumb.querySelectorAll("li, span, a")];
      const last = items[items.length - 1];
      return last && norm(last.textContent).includes("listar processo");
    }
    return false;
  }

  if (!noFormulario()) {
    if (naListaProcessos()) {
      // Já está na Lista de Processos → só clica Novo
      dbg += "lst";
      await clicarTexto("novo");
      await delay(2500);
    } else {
      // Navega do início: Solicitação → PF → Listar → Novo
      await clicarTexto("solicitacao de servico"); await delay(1200);
      await clicarTexto("pessoa fisica");          await delay(1200);
      await clicarTexto("listar processo");        await delay(1800);
      // Aguarda botão Novo aparecer (pode demorar para carregar a lista)
      await aguardarEl(() =>
        [...document.querySelectorAll("button, a")]
          .find(b => norm(b.textContent.trim()).includes("novo")), 6000);
      await clicarTexto("novo"); await delay(3000);
    }

    await aguardarEl(() => noFormulario() || null, 4000);
    if (!noFormulario()) return { n: 0, dbg: `NAO_NO_FORM${dbg}` };
  }
  dbg += ",form_ok";

  // PASSO 2: Expandir Seção 2 e preencher dropdowns

  // Encontra o cabeçalho real do accordion (PrimeNG, Angular Material, Bootstrap)
  function encontrarHeaderAccordion(texto) {
    // 1. PrimeNG: div.ui-accordion-header ou div.p-accordion-header
    const prime = [...document.querySelectorAll(".ui-accordion-header, .p-accordion-header")]
      .find(el => norm(el.textContent).includes(norm(texto)));
    if (prime) return prime;

    // 2. Angular Material
    const mat = [...document.querySelectorAll("mat-expansion-panel-header")]
      .find(el => norm(el.textContent).includes(norm(texto)));
    if (mat) return mat;

    // 3. [role='tab'], [role='button'], button
    const role = [...document.querySelectorAll("[role='tab'], [role='button'], button, .accordion-header, .panel-heading")]
      .find(el => { const t = el.textContent.trim(); return t.length < 200 && norm(t).includes(norm(texto)); });
    if (role) return role;

    return null;
  }

  // Clica no cabeçalho da seção e aguarda o conteúdo aparecer
  async function expandirSecao(texto) {
    const hdr = encontrarHeaderAccordion(texto);
    if (!hdr) return "nao_achou";

    const tag = hdr.tagName.toLowerCase();
    const cls = [...hdr.classList].slice(0, 2).join(" ");

    // Verifica se já está expandido (PrimeNG: ui-state-active; Angular Material: mat-expanded)
    const jaAberto = hdr.classList.contains("ui-state-active") ||
      hdr.classList.contains("p-highlight") ||
      hdr.getAttribute("aria-expanded") === "true" ||
      hdr.closest("mat-expansion-panel")?.classList.contains("mat-expanded") ||
      hdr.parentElement?.classList.contains("mat-expanded") ||
      hdr.parentElement?.getAttribute("aria-expanded") === "true" ||
      hdr.parentElement?.classList.contains("ui-state-active");

    if (!jaAberto) {
      // Para PrimeNG, clicar no <a> dentro do header abre a seção
      const clickTarget = hdr.querySelector("a, button") || hdr;
      clickTarget.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
      clickTarget.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
      clickTarget.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
      clickTarget.click();
      await delay(2500);
    }
    return `${jaAberto ? "ja_aberto" : "clicou"}(${tag} ${cls})`;
  }

  // Busca dropdowns dentro do conteúdo de uma seção específica
  function dropdownsDaSecao(textoSecao) {
    const hdr = encontrarHeaderAccordion(textoSecao);
    if (!hdr) return [];

    // No PrimeNG accordion, os irmãos seguintes até o próximo header são o conteúdo
    const parent = hdr.parentElement;
    if (parent) {
      const siblings = [...parent.children];
      const hdrIdx = siblings.indexOf(hdr);
      const drops = [];
      for (let i = hdrIdx + 1; i < siblings.length; i++) {
        const sib = siblings[i];
        // Para quando encontrar o próximo cabeçalho de seção
        if (sib.classList.contains("ui-accordion-header") ||
            sib.classList.contains("p-accordion-header") ||
            sib.tagName === "MAT-EXPANSION-PANEL-HEADER") break;
        drops.push(...sib.querySelectorAll("p-dropdown, mat-select, .ui-dropdown:not(.ui-dropdown-panel)"));
      }
      if (drops.length > 0) return drops;
    }

    // Fallback: próximo irmão direto
    const content = hdr.nextElementSibling ||
      hdr.closest("mat-expansion-panel")?.querySelector("mat-expansion-panel-content");
    if (content) return [...content.querySelectorAll("p-dropdown, mat-select")];
    return [];
  }

  const r2 = await expandirSecao("escolha as atividades");
  dbg += `,sec2=${r2}`;
  await delay(1500);

  // Busca dropdowns especificamente dentro da seção 2
  const drops = await aguardarEl(() => {
    const d = dropdownsDaSecao("escolha as atividades");
    return d.length >= 1 ? d : null;
  }, 4000) || dropdownsDaSecao("escolha as atividades");
  dbg += `,dr=${drops.length}`;
  if (drops[0]) dbg += `,tag=${drops[0].tagName.toLowerCase()},cls=${[...drops[0].classList].find(c => !c.startsWith("ng-")) || ""}`;

  async function clicarDropdown(el, textoOpcao) {
    if (!el) return false;

    // SELECT nativo
    if (el.tagName === "SELECT") {
      const opt = [...el.options].find(o => norm(o.text).includes(norm(textoOpcao)));
      if (opt) {
        try {
          const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
          setter ? setter.call(el, opt.value) : (el.value = opt.value);
        } catch (_) { el.value = opt.value; }
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.dispatchEvent(new Event("input", { bubbles: true }));
        return true;
      }
      return false;
    }

    // PrimeNG p-dropdown ou .ui-dropdown
    const isPrime = el.tagName === "P-DROPDOWN" ||
      el.classList.contains("ui-dropdown") || el.classList.contains("p-dropdown");
    if (isPrime) {
      // PrimeNG renderiza um div.ui-dropdown dentro do tag <p-dropdown>
      // É esse div que tem o event handler do Angular — não o tag externo
      const innerDiv = el.querySelector("div.ui-dropdown, div.p-dropdown") || el;
      innerDiv.click();
      await delay(800);
      // Conta quantas opções apareceram (para debug)
      const allOpts = [...document.querySelectorAll(
        "li.ui-dropdown-item, li.p-dropdown-item, .ui-dropdown-item, " +
        "mat-option, .mat-option, li[role='option'], li.ui-state-highlight"
      )];
      if (allOpts.length === 0) {
        // Painel não abriu — tenta clicar no trigger arrow
        const trig = innerDiv.querySelector(".ui-dropdown-trigger, .p-dropdown-trigger, span.pi") || innerDiv;
        trig.click(); await delay(800);
      }
      const opt = await aguardarOpcao(o => norm(o.textContent).includes(norm(textoOpcao)), 5000);
      if (opt) { opt.click(); await delay(500); return true; }
      document.body.click(); await delay(200); return false;
    }

    // Select2 / Chosen
    if (el.classList.contains("select2-container") || el.classList.contains("chosen-container")) {
      const trigger = el.querySelector(".select2-selection, .chosen-single") || el;
      trigger.click(); await delay(600);
      const opt = await aguardarOpcao(o => norm(o.textContent).includes(norm(textoOpcao)));
      if (opt) { opt.click(); await delay(400); return true; }
      document.body.click(); await delay(200); return false;
    }

    // Angular Material mat-select / ng-select
    const trigger = el.querySelector(".mat-select-trigger, .mat-mdc-select-trigger, .ng-arrow-wrapper") || el;
    trigger.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    trigger.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
    trigger.click(); el.click();
    await delay(600);
    const opt = await aguardarOpcao(o => norm(o.textContent).includes(norm(textoOpcao)));
    if (opt) { opt.click(); await delay(400); return true; }
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    await delay(200); return false;
  }

  // Clica p-dropdown pelo índice dentro da seção e seleciona opção
  async function clicarDropPosicao(textoSecao, idxDrop, opcaoBusca) {
    const hdr = encontrarHeaderAccordion(textoSecao);
    if (!hdr) { dbg += `(sec?nf)`; return false; }
    const seccontent = hdr.nextElementSibling || hdr.parentElement;
    const drops = [...seccontent.querySelectorAll("p-dropdown, p-multiSelect")];
    dbg += `(nd=${drops.length})`;
    if (!drops[idxDrop]) { dbg += `(d${idxDrop}?nf)`; return false; }
    const el = drops[idxDrop];
    const inner = el.querySelector("div.ui-dropdown, div.p-dropdown, div.ui-multiselect, div.p-multiselect") || el;
    inner.click(); await delay(1000);
    const getOpts = () => [...document.querySelectorAll(
      "li.ui-dropdown-item, li.p-dropdown-item, .ui-dropdown-item, " +
      "li.ui-multiselect-item, li.p-multiselect-item, .ui-multiselect-item, " +
      "mat-option, .mat-option, li[role='option']"
    )];
    let opts = getOpts();
    if (opts.length === 0) {
      const trig = inner.querySelector(".ui-dropdown-trigger, .ui-multiselect-trigger, span.pi") || inner;
      trig.click(); await delay(800);
      opts = getOpts();
    }
    dbg += `(oo=${opts.length})`;
    if (opts.length > 0) dbg += `[${opts[0].textContent.trim().slice(0,12)}]`;
    const opt = opts.find(o => norm(o.textContent).includes(norm(opcaoBusca)));
    if (opt) {
      const clickEl = opt.querySelector("span:not(.ui-chkbox-icon), label") || opt;
      clickEl.click(); await delay(500);
      document.body.click(); await delay(400);
      return true;
    }
    document.body.click(); await delay(200); return false;
  }

  // Clica p-multiSelect pelo índice (somente multiselects, índice estável após re-render)
  async function clicarMultiSelect(textoSecao, idxMs, opcaoBusca) {
    const hdr = encontrarHeaderAccordion(textoSecao);
    if (!hdr) { dbg += `(mssec?nf)`; return false; }
    const seccontent = hdr.nextElementSibling || hdr.parentElement;
    const ms = [...seccontent.querySelectorAll("p-multiSelect, p-multiselect")];
    dbg += `(ms=${ms.length})`;
    if (!ms[idxMs]) { dbg += `(ms${idxMs}?nf)`; return false; }
    const el = ms[idxMs];
    const inner = el.querySelector("div.ui-multiselect, div.p-multiselect") || el;
    inner.click(); await delay(1200);
    const getOpts = () => [...document.querySelectorAll(
      "li.ui-multiselect-item, li.p-multiselect-item, .ui-multiselect-item"
    )];
    let opts = getOpts();
    if (opts.length === 0) {
      const trig = inner.querySelector(".ui-multiselect-trigger, span.pi") || inner;
      trig.click(); await delay(1000);
      opts = getOpts();
    }
    dbg += `(ms_oo=${opts.length})`;
    if (opts.length > 0) dbg += `[${opts[0].textContent.trim().slice(0,14)}]`;
    const opt = opts.find(o => norm(o.textContent).includes(norm(opcaoBusca)));
    if (opt) {
      const clickEl = opt.querySelector("span:not(.ui-chkbox-icon), label") || opt;
      clickEl.click(); await delay(500);
      document.body.click(); await delay(500);
      return true;
    }
    document.body.click(); await delay(200); return false;
  }

  // Serviço: primeiro p-dropdown da seção
  const r1 = await clicarDropPosicao("escolha as atividades", 0, cfg.servico);
  dbg += r1 ? ",srv=ok" : ",srv=x"; if (r1) n++;
  await delay(1000);
  const rAtv = await clicarMultiSelect("escolha as atividades", 0, cfg.atividade);
  dbg += rAtv ? ",atv=ok" : ",atv=x"; if (rAtv) n++;
  await delay(2500);
  const rPce = await clicarMultiSelect("escolha as atividades", 1, cfg.pce);
  dbg += rPce ? ",pce=ok" : ",pce=x"; if (rPce) n++;
  await delay(400);

  // PASSO 2.5: Expandir Seção 3
  const r3sec = await expandirSecao("preencha as condicoes");
  dbg += `,sec3=${r3sec}`;
  await delay(1000);

  // PASSO 3: Seção 3 — Selecionar tipos e anexar PDFs
  function reconstruirFile(arq) {
    const bin = atob(arq.base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes.buffer], arq.nome, { type: "application/pdf" });
  }

  dbg += `,arqs=${arquivos ? arquivos.length : 0}`;

  const hdr3 = encontrarHeaderAccordion("preencha as condicoes");
  const sec3 = hdr3 ? (hdr3.nextElementSibling || hdr3.parentElement) : document;

  const sec3uploads = await aguardarEl(() => {
    const fus = [...sec3.querySelectorAll("p-fileupload")];
    return fus.length >= 1 ? fus : null;
  }, 8000) || [...sec3.querySelectorAll("p-fileupload")];

  const sec3drops = [...sec3.querySelectorAll("p-dropdown")];
  dbg += `,s3u=${sec3uploads.length},s3d=${sec3drops.length}`;

  const opcoesSec3 = cfg.opcoesSec3;

  async function processarLinha(drop, fu, idx) {
    // Dropdown (esquerda): abre e seleciona
    if (drop) {
      const innerDiv = drop.querySelector("div.ui-dropdown, div.p-dropdown") || drop;
      innerDiv.click(); await delay(900);
      const opts = [...document.querySelectorAll(
        "li.ui-dropdown-item, li.p-dropdown-item, .ui-dropdown-item, li[role='option']"
      )];
      dbg += `,d${idx+1}=${opts.length}`;
      if (opts.length > 0) {
        const buscaTxt = opcoesSec3[idx] || "";
        const optEscolhida = (buscaTxt && opts.find(o => norm(o.textContent).includes(norm(buscaTxt)))) || opts[0];
        optEscolhida.click(); await delay(400);
        dbg += `[${optEscolhida.textContent.trim().slice(0, 12)}]`;
      } else {
        document.body.click(); await delay(300);
      }
    }
    // Fileupload (direita): injeta arquivo e clica Carregar
    if (fu && arquivos && arquivos.length > 0) {
      const arq = arquivos.find(a => a.numero === (cfg.mapaArq[idx] ?? idx + 1));
      if (arq) {
        const inp = fu.querySelector("input[type='file'], input[accept]");
        if (!inp) { dbg += `,f${idx+1}=noinp`; }
        else {
          const dt = new DataTransfer();
          dt.items.add(reconstruirFile(arq));
          try { inp.files = dt.files; } catch (e) {}
          inp.dispatchEvent(new Event("change", { bubbles: true }));
          await delay(700);
          const carr = fu.querySelector(".ui-fileupload-upload, .p-fileupload-upload") ||
            [...fu.querySelectorAll("button")].find(b =>
              norm(b.textContent).includes("carregar") || norm(b.textContent).includes("enviar")
            );
          if (carr) { carr.click(); await delay(1200); dbg += `,f${idx+1}=ok`; n++; }
          else { dbg += `,f${idx+1}=nocarr`; }
        }
      }
    }
  }

  if (modo === "ac") {
    // AC: ordena drops e uploads pela posição no DOM e emparelha cada upload com seu drop precedente
    const sorted = [
      ...sec3drops.map(d => ({ el: d, kind: 'd' })),
      ...sec3uploads.map(u => ({ el: u, kind: 'u' })),
    ].sort((a, b) => (a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);
    const pairs = [];
    let lastDrop = null;
    for (const item of sorted) {
      if (item.kind === 'd') { lastDrop = item.el; }
      else { pairs.push({ drop: lastDrop, fu: item.el }); lastDrop = null; }
    }
    dbg += `,acpairs=${pairs.length}`;
    for (let i = 0; i < Math.min(pairs.length, cfg.mapaArq.length); i++) {
      await processarLinha(pairs[i].drop, pairs[i].fu, i);
      await delay(300);
    }
  } else {
    // CR: todas as linhas visíveis de uma vez — itera pelos dropdowns
    for (let i = 0; i < sec3drops.length; i++) {
      await processarLinha(sec3drops[i], sec3uploads[i], i);
      await delay(200);
    }
  }

  return { n, dbg };
  } catch(e) { return { n: 0, dbg: `ERRO:${e.message.slice(0, 80)}` }; }
}

function mostrarPf() {
  document.getElementById("tela-pf").style.display = "flex";
  document.getElementById("tela-sem-sessao").style.display = "none";
  document.getElementById("tela-busca").style.display = "none";
  // Carrega clientes do sistema ao abrir tela PF
  if (clientesSistema.length === 0) carregarClientesSistema();
}

function mostrarSemSessao() {
  document.getElementById("tela-sem-sessao").style.display = "flex";
  document.getElementById("tela-busca").style.display = "none";
}

function mostrarBusca() {
  document.getElementById("tela-busca").style.display = "flex";
  document.getElementById("tela-sem-sessao").style.display = "none";
  document.getElementById("tela-pf").style.display = "none";
}

// ─── Busca no sistema Supabase ────────────────────────────────────────────────

// Abas do site RW abertas, na ordem em que vale tentar: a última que funcionou, depois as da mesma janela anônima (ou não)
// da aba da PF, depois a usada mais recentemente. Com o site aberto numa aba normal sem login e noutra anônima com
// login, antes pegava sempre a primeira e a busca de clientes voltava vazia
async function abasDoSite() {
  if (SEM_ABAS) return [];
  const pfId = pfTabId || await abaDoPainel();
  const pf = pfId ? await chrome.tabs.get(pfId).catch(() => null) : null;
  const anonima = !!pf?.incognito;
  const abas = (await chrome.tabs.query({})).filter(t => t.url && APP_URLS.some(u => t.url.includes(u)));
  const nota = t => (t.id === appTabId ? 4 : 0) + (t.incognito === anonima ? 2 : 0);
  return abas.sort((a, b) => nota(b) - nota(a) || (b.lastAccessed || 0) - (a.lastAccessed || 0)).map(t => t.id);
}
// Roda no site uma das consultas de site-funcs.js (pelo nome), tentando cada aba até uma responder { ok: true }
async function noSite(nome, args = []) {
  const func = SITE_FUNCS[nome];
  if (!func) return null;
  const tentar = async () => {
    // diagnóstico (2026-11-22): PF na aba anônima não usava o sistema logado na janela normal; mostra no menu o que viu
    const diag = [];
    try {
      const todas = await chrome.tabs.query({});
      diag.push(`abas vistas: ${todas.length} (anônimas: ${todas.filter(t => t.incognito).length})`);
    } catch (e) { diag.push("tabs.query falhou: " + String(e?.message || e).slice(0, 60)); }
    const ids = await abasDoSite().catch(() => []);
    diag.push(`abas do sistema: ${ids.length}`);
    for (const tabId of ids) {
      let r;
      try {
        r = (await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func, args }))?.[0]?.result;
      } catch (e) {
        // aba da janela normal vista de dentro da aba anônima: o Chrome não deixa rodar daqui ("No tab with id");
        // o background (perfil normal) roda por nós a mesma função de site-funcs.js, pelo nome
        try {
          const resp = await chrome.runtime.sendMessage({ action: "rodarNoSite", tabId, nome, args });
          if (resp?.ok) r = resp.result;
          else diag.push(`aba ${tabId}: ` + String(resp?.error || e?.message || e).slice(0, 70));
        } catch (e2) { diag.push(`aba ${tabId}: ` + String(e2?.message || e2).slice(0, 70)); }
      }
      if (r?.ok) { appTabId = tabId; return r; }
      if (r) diag.push(`aba ${tabId}: respondeu sem dados (sem login?)`);
    }
    window.__passarinho_diag_sistema = diag.join(" | ");
    return null;
  };
  const r = await tentar();
  if (r || SEM_ABAS) return r;
  // Nenhuma aba do sistema respondeu (o usuário pediu, 2026-11-22: PF na aba anônima sem precisar entrar no sistema):
  // abre o sistema sozinho numa aba de fundo da JANELA NORMAL, onde o login do site já fica guardado, e tenta de novo.
  // Nunca digita senha; se a janela normal também estiver sem login, avisa para entrar uma vez por lá.
  if (await abrirSistemaNaJanelaNormal()) return await tentar();
  return null;
}

async function abrirSistemaNaJanelaNormal() {
  try {
    // nunca abre várias abas: já existe aba do sistema (mesmo sem login) → não abre outra; e no máximo uma tentativa a
    // cada 10 minutos (guardada fora do menu, que recarrega a cada página da PF)
    const jaTem = (await chrome.tabs.query({})).some(t => !t.incognito && t.url && APP_URLS.some(u => t.url.includes(u)));
    const { abriuSistemaEm = 0 } = await chrome.storage.local.get(["abriuSistemaEm"]);
    if (jaTem || Date.now() - abriuSistemaEm < 10 * 60 * 1000) return false;
    await chrome.storage.local.set({ abriuSistemaEm: Date.now() });
    // quem abre e espera o site ficar pronto é o background: de dentro da aba anônima o Chrome não deixa mexer na
    // janela normal
    const resp = await chrome.runtime.sendMessage({ action: "abrirSistema" });
    return !!resp?.ok;
  } catch (_) {}
  return false;
}

async function carregarClientesSistema() {
  try {
    const resp = await noSite("clientes");
    if (resp?.ok) clientesSistema = resp.data;
  } catch (_) {}
}

function filtrarSistema(query) {
  const lista = document.getElementById("pf-lista-sistema");
  const inp = document.getElementById("pf-input-sistema");
  if (!query || inp?.readOnly) { lista.style.display = "none"; return; }
  const filtrados = buscarClientesExt(clientesSistema, query).slice(0, 8);
  if (!filtrados.length) { lista.style.display = "none"; return; }
  lista.innerHTML = filtrados.map(c =>
    `<div class="pf-cli-item" data-id="${c.id}">
      <div>${(c.nome || "").toUpperCase()}</div>
      <div class="pf-cli-cpf">${c.cpf || "Sem CPF"}</div>
    </div>`
  ).join("");
  lista.querySelectorAll(".pf-cli-item").forEach(el =>
    el.addEventListener("click", () => {
      const c = clientesSistema.find(x => x.id === el.dataset.id);
      if (c) {
        selecionarClienteSistema(c);
        const inp = document.getElementById("pf-input-sistema");
        inp.value = c.nome || "";
        inp.readOnly = true;
      }
      lista.style.display = "none";
    })
  );
  lista.style.display = "block";
}

function setInfoTxt(txt, cor) {
  const infoTxt = document.getElementById("pf-cliente-info-txt");
  const infoEl  = document.getElementById("pf-cliente-info");
  infoTxt.textContent = txt;
  infoEl.style.color  = cor;
}

function limparClienteSistema() {
  arquivosCr = [];
  clienteSelecionado = null;
  chrome.storage.local.remove(["pfClienteCache"]);
  setInfoTxt("", "#406050");
  document.getElementById("btn-limpar-sistema").style.display = "none";
  const inp = document.getElementById("pf-input-sistema");
  if (inp) { inp.value = ""; inp.readOnly = false; inp.focus(); }
  document.getElementById("pf-pasta-info").textContent = "";
  document.getElementById("pf-pasta-info").style.color = "#406050";
  limparSlotUI();
}

// Mesmo nome? Sem acento, maiúsculas e espaços; aceita nome abreviado num dos lados (mesmo primeiro nome e todas as
// palavras do nome menor dentro do maior, ignorando DA/DE/DO/DOS/DAS/E)
function mesmoNome(a, b) {
  const pal = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/[^A-Z ]/g, " ")
    .split(/\s+/).filter(w => w && !["DA", "DE", "DO", "DOS", "DAS", "E"].includes(w));
  const x = pal(a), y = pal(b);
  if (!x.length || !y.length) return true;
  if (x.join(" ") === y.join(" ")) return true;
  if (x[0] !== y[0]) return false;
  const [menor, maior] = x.length <= y.length ? [x, y] : [y, x];
  return menor.length >= 2 && menor.every(w => maior.includes(w));
}

async function detectarGeneroNome(nome) {
  const primeiro = (nome || "").split(" ")[0];
  if (!primeiro) return null;
  try {
    const r = await fetch(`https://api.genderize.io/?name=${encodeURIComponent(primeiro)}&country_id=BR`);
    const d = await r.json();
    if (d.gender && d.probability >= 0.6) return d.gender === "female" ? "feminino" : "masculino";
  } catch {}
  return null;
}

async function selecionarClienteSistema(cliente) {
  clienteSelecionado = cliente;
  // Documentos do cliente anterior saem JÁ: antes, cliente sem nenhum documento no sistema saía da função antes de
  // limpar a lista, e o GT anexou o RG do cliente anterior no processo de outra pessoa (usuário viu, 2026-11-19)
  arquivosCr = [];
  chrome.storage.local.set({ pfClienteCache: cliente }).catch(() => {});
  // Mostra nome no campo e bloqueia edição até limpar
  const inp = document.getElementById("pf-input-sistema");
  if (inp) { inp.value = cliente.nome || ""; inp.readOnly = true; }
  // Mostra/oculta campo de profissão manual
  const profRow = document.getElementById("pf-profissao-row");
  const profInput = document.getElementById("pf-profissao-input");
  if (profRow && profInput) {
    if (!cliente.profissao) {
      profRow.style.display = "block";
      const { ["prof_" + cliente.id]: savedProf } = await chrome.storage.local.get(["prof_" + cliente.id]);
      profInput.value = savedProf || "";
    } else {
      profRow.style.display = "none";
      profInput.value = "";
    }
  }
  // Gênero: o escolhido no cadastro do site vale; só sem ele tenta adivinhar pelo nome (aguarda, para estar pronto no CR)
  if (!cliente.genero) {
    const genero = await detectarGeneroNome(cliente.nome);
    if (genero) clienteSelecionado.genero = genero;
  }
  const pastaInfo = document.getElementById("pf-pasta-info");
  const btnLimpar = document.getElementById("btn-limpar-sistema");
  setInfoTxt(`⏳ Carregando documentos de ${cliente.nome}…`, "#406050");
  btnLimpar.style.display = "none";

  try {
    const resp = await noSite("docsCliente", [cliente.id]);
    const docs = resp?.docs || [];

    if (!docs.length) {
      setInfoTxt(`⚠️ ${cliente.nome} — sem documentos cadastrados`, "#d4a730");
      btnLimpar.style.display = "inline-flex";
      return;
    }

    arquivosCr = [];
    let erros = 0;
    for (const doc of docs) {
      const num = TIPO_PARA_NUMERO[doc.tipo];
      if (!num) continue;
      // o arquivo fica na pasta do próprio cliente no armazenamento (<id do cliente>/<tipo>/...): fora dela, não usa
      if (!String(doc.file_url || "").includes(`/${cliente.id}/`)) { erros++; continue; }
      try {
        const resp = await fetch(doc.file_url);
        if (!resp.ok) { erros++; continue; }
        const buffer = await resp.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        let binary = "";
        const CHUNK = 8192;
        for (let i = 0; i < bytes.length; i += CHUNK)
          binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
        arquivosCr.push({ numero: num, tipo: doc.tipo, cliente: cliente.id, nome: doc.file_name || `${num}.pdf`, base64: btoa(binary) });
      } catch (_) { erros++; }
    }
    if (clienteSelecionado?.id !== cliente.id) { arquivosCr = arquivosCr.filter(a => a.cliente === clienteSelecionado?.id); return; }
    arquivosCr.sort((a, b) => a.numero - b.numero);

    // conta pelos 12 campos do portal (mesma numeração do site); "doc_ident" e outros tipos antigos não contam
    const presentes = new Set(arquivosCr.map(a => SLOT_PORTAL[a.tipo]).filter(Boolean));
    const ok = presentes.size;
    const faltando = [];
    for (let i = 1; i <= 12; i++) if (!presentes.has(i)) faltando.push(i);
    const linhaFalta = faltando.length ? ` — faltam: ${faltando.join(", ")}` : "";
    const cor = faltando.length ? "#d4a730" : "#00c490";

    let txt = `✓ ${ok}/12 — ${cliente.nome}${linhaFalta}`;
    if (erros) txt += ` (${erros} erro(s))`;
    setInfoTxt(txt, cor);
    btnLimpar.style.display = "inline-flex";

    pastaInfo.style.color = cor;
    pastaInfo.textContent = `✓ ${ok}/12 prontos — ${cliente.nome} (sistema)${linhaFalta}`;

    // Mostra preview dos slots mapeados
    mostrarPreviewCr();
  } catch (e) {
    setInfoTxt(`Erro: ${e.message}`, "#ef4444");
    btnLimpar.style.display = "inline-flex";
  }
}
