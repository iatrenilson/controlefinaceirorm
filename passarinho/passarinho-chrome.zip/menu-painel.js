// Menu do Passarinho no painel do Portal PF (painel.js), no estilo do "Sinarm CAC – Assistente":
// cliente, "Cadastro inicial" e "Novo processo ›" com CR, AC e Registrar arma de fogo.
// Usa as mesmas funções da tela do popup (popup.js): busca de cliente do sistema, preencherPfCr, acompanhar...
(() => {
  if (typeof EM_PAINEL === "undefined" || !EM_PAINEL) return;
  const $ = id => document.getElementById(id);

  // A extensão é carregada da pasta: o Chrome só lê o painel.js de novo quando ela é recarregada em chrome://extensions,
  // mas este menu é lido da pasta a cada página. Se a versão na pasta for outra, a extensão se recarrega sozinha
  // (background.js põe o menu novo nas abas abertas). Uma tentativa por versão a cada 5 minutos, para nunca ficar em laço.
  (async () => {
    try {
      const naPasta = (await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json()).version;
      if (!naPasta || naPasta === chrome.runtime.getManifest().version) return;
      const { recarga } = await chrome.storage.local.get(["recarga"]);
      if (recarga && recarga.versao === naPasta && Date.now() - recarga.em < 5 * 60 * 1000) return;
      await chrome.storage.local.set({ recarga: { versao: naPasta, em: Date.now() } });
      chrome.runtime.reload();
    } catch (_) {}
  })();

  // O painel.js ajusta o quadro ao tamanho do menu (com o submenu aberto ele fica mais largo)
  function avisarTamanho() {
    let w = 0, h = 0;
    for (const el of [$("mp-caixa"), $("mp-flyout"), $("mp-gt-box"), $("mp-cert-box"), $("mp-recolhido")]) {
      const r = el.getBoundingClientRect();
      if (r.width && r.height) { w = Math.max(w, r.right); h = Math.max(h, r.bottom); }
    }
    parent.postMessage({ passarinho: "tamanho", w: Math.ceil(w) + 1, h: Math.ceil(h) + 1 }, "*");
  }
  const tamanhos = new ResizeObserver(avisarTamanho);
  tamanhos.observe($("mp-caixa"));
  tamanhos.observe($("mp-recolhido"));

  function status(txt, erro) {
    const st = $("mp-status");
    st.textContent = txt || "";
    st.className = "mp-status" + (erro ? " erro" : "");
    if (erro && txt) abrirParaAviso();
    // aviso comum some sozinho depois de um tempo, se não houver preenchimento em andamento; erro fica até clicar nele
    clearTimeout(status.timer);
    if (txt && !erro) status.timer = setTimeout(() => { if (st.textContent === txt && !emAndamento()) status(""); }, 12000);
    atualizarVisivel();
    avisarTamanho();
  }
  // A caixinha da página só aparece com algo para mostrar: status, aviso, Continuar ou Pausar/Parar (o menu é o popup)
  function emAndamento() {
    const vis = id => { const el = $(id); return !!el && el.style.display && el.style.display !== "none"; };
    return vis("mp-continuar") || vis("mp-controles");
  }
  function atualizarVisivel() {
    const tem = !!($("mp-status").textContent.trim() || $("mp-aviso").textContent.trim()) || emAndamento();
    $("menu-painel").classList.toggle("oculto", !tem);
  }

  // ── Cliente ──
  // linha curta dos documentos, a partir do aviso da tela do popup ("✓ 10/12 — FULANO — faltam: 4, 7")
  function resumoDocs(info) {
    if (!info) return "";
    if (info.startsWith("⏳")) return "⏳ Carregando documentos…";
    if (/sem documentos/i.test(info)) return "⚠️ Sem documentos no sistema";
    const n = info.match(/(\d+)\/12/);
    if (n) return `✓ ${n[1]}/12 documentos` + (info.match(/ — faltam: [\d, ]+/)?.[0] ?? "");
    return info;
  }
  function mostrarCliente() {
    const c = clienteSelecionado;
    $("mp-nome").textContent = c ? (c.nome || "").toUpperCase() : "Escolher cliente…";
    $("mp-limpar").style.display = c ? "inline" : "none";
    $("mp-docs").textContent = c ? resumoDocs($("pf-cliente-info-txt")?.textContent || "") : "";
    avisarTamanho();
  }
  // a tela do popup atualiza o cliente e os documentos sozinha; o menu só repete
  new MutationObserver(mostrarCliente).observe($("pf-cliente-info-txt"), { childList: true, characterData: true, subtree: true });

  function abrirBusca(aviso) {
    $("mp-busca").classList.add("aberta");
    if (!clientesSistema.length) carregarClientesSistema().then(() => listar());
    listar(aviso);
    setTimeout(() => $("mp-input").focus(), 0);
  }
  function fecharBusca() { $("mp-busca").classList.remove("aberta"); $("mp-res").innerHTML = ""; avisarTamanho(); }
  function listar(aviso) {
    const res = $("mp-res");
    const q = $("mp-input").value.trim();
    if (!clientesSistema.length) {
      res.innerHTML = SEM_ABAS ? `<div class="aviso">${AVISO_SEM_ABAS}</div>`
        : `<div class="aviso">Não achei o sistema logado. Entre uma vez no rwinvestimentos.com.br numa janela NORMAL do Chrome (fora da anônima): depois disso o Passarinho abre o sistema sozinho.<br><small style="opacity:.7">${(window.__passarinho_diag_sistema || "").replace(/</g, "")}</small></div>`;
    } else if (!q) {
      res.innerHTML = aviso ? `<div class="aviso">${aviso}</div>` : "";
    } else {
      // até 6, para a lista caber no menu sem rolagem
      const achados = buscarClientesExt(clientesSistema, q).slice(0, 6);
      res.innerHTML = achados.length
        ? achados.map(c => `<div class="op" data-id="${c.id}">${(c.nome || "").toUpperCase()}<small>${c.cpf || "Sem CPF"}</small></div>`).join("")
        : '<div class="aviso">Nenhum cliente encontrado.</div>';
      res.querySelectorAll(".op").forEach(el => el.addEventListener("click", async () => {
        const c = clientesSistema.find(x => x.id === el.dataset.id);
        if (!c) return;
        fecharBusca();
        $("mp-input").value = "";
        status("");
        await selecionarClienteSistema(c);
        mostrarCliente();
      }));
    }
    avisarTamanho();
  }
  $("mp-cliente").addEventListener("click", e => {
    if (e.target.closest("#mp-limpar")) {
      limparClienteSistema();
      mostrarCliente();
      abrirBusca();
      return;
    }
    $("mp-busca").classList.contains("aberta") ? fecharBusca() : abrirBusca();
  });
  $("mp-input").addEventListener("input", () => listar());
  $("mp-input").addEventListener("keydown", e => {
    if (e.key === "Enter") $("mp-res").querySelector(".op")?.click();
    if (e.key === "Escape") fecharBusca();
  });

  // ── Ações ──
  function precisaCliente() {
    if (clienteSelecionado) return false;
    status("⚠️ Escolha o cliente no ícone da Passarinho, lá em cima.", true);
    return true;
  }
  // Todas as opções usam os documentos do cliente no sistema (Clientes Armas), igual ao CR; a Autorização de Compra
  // não pede arquivos. variante: "caca" na Autorização de Compra Caça (muda só a escolha dos itens 11 e 12 no portal)
  function executar(modo, variante = "") {
    fecharSub();
    if (precisaCliente()) return;
    preencherPfCr(modo, variante);
  }
  $("mp-cadastro").addEventListener("click", () => executar("cadastro"));
  $("mp-sisgcorp").addEventListener("click", () => executar("sisgcorp"));
  // No SisGCorp o menu tem só o cadastro inicial de lá (a tela é diferente da PF); no Portal PF fica tudo como era
  const NO_SISGCORP = /sisgcorp\.eb\.mil\.br/.test(location.ancestorOrigins?.[0] || document.referrer || "");
  if (NO_SISGCORP) {
    $("mp-cadastro").style.display = "none";
    $("mp-novo").style.display = "none";
    $("mp-sisgcorp").style.display = "";
  }

  // Submenu "Novo processo": abre ao passar o mouse ou ao clicar
  let fecharTimer = null;
  function abrirSub() {
    clearTimeout(fecharTimer);
    const item = $("mp-novo"), fly = $("mp-flyout");
    fly.style.left = `${$("mp-caixa").offsetLeft + $("mp-caixa").offsetWidth + 6}px`;
    fly.style.top = `${item.offsetTop - 6}px`;
    fly.classList.add("aberto");
    item.classList.add("ativo");
    avisarTamanho();
  }
  function fecharSub() {
    clearTimeout(fecharTimer);
    $("mp-flyout").classList.remove("aberto");
    $("mp-gt-box").classList.remove("aberto");
    $("mp-gt").classList.remove("ativo");
    $("mp-novo").classList.remove("ativo");
    avisarTamanho();
  }
  // não fecha enquanto se digita um evento novo do GT (o mouse pode sair do menu)
  const fecharDepois = () => { clearTimeout(fecharTimer); if ($("mp-gt-box").contains(document.activeElement)) return; fecharTimer = setTimeout(fecharSub, 350); };
  $("mp-novo").addEventListener("mouseenter", abrirSub);
  $("mp-novo").addEventListener("click", () => ($("mp-flyout").classList.contains("aberto") ? fecharSub() : abrirSub()));
  $("mp-novo").addEventListener("mouseleave", fecharDepois);
  $("mp-flyout").addEventListener("mouseenter", () => clearTimeout(fecharTimer));
  $("mp-flyout").addEventListener("mouseleave", fecharDepois);
  // lista de eventos do GT (ao lado do submenu): passar o mouse nela mantém tudo aberto
  $("mp-gt-box").addEventListener("mouseenter", () => clearTimeout(fecharTimer));
  $("mp-gt-box").addEventListener("mouseleave", fecharDepois);
  $("mp-flyout").querySelectorAll("[data-modo]").forEach(el =>
    el.addEventListener("click", () => executar(el.dataset.modo, el.dataset.variante || "")));

  // ── Certidões (2026-11-22): "Emitir todas" ou uma por uma; abre o site numa aba e preenche com o cliente do menu ──
  const certBox = $("mp-cert-box"), certItem = $("mp-cert");
  if (NO_SISGCORP) certItem.style.display = "none";
  function abrirCert() {
    clearTimeout(fecharTimer);
    $("mp-flyout").classList.remove("aberto"); $("mp-novo").classList.remove("ativo");
    $("mp-gt-box").classList.remove("aberto"); $("mp-gt").classList.remove("ativo");
    certBox.style.left = `${$("mp-caixa").offsetLeft + $("mp-caixa").offsetWidth + 6}px`;
    certBox.style.top = `${certItem.offsetTop - 6}px`;
    certBox.classList.add("aberto");
    certItem.classList.add("ativo");
    avisarTamanho();
  }
  function fecharCert() { certBox.classList.remove("aberto"); certItem.classList.remove("ativo"); avisarTamanho(); }
  let fecharCertTimer = null;
  const fecharCertDepois = () => { clearTimeout(fecharCertTimer); fecharCertTimer = setTimeout(fecharCert, 350); };
  certItem.addEventListener("mouseenter", () => { clearTimeout(fecharCertTimer); abrirCert(); });
  certItem.addEventListener("click", () => (certBox.classList.contains("aberto") ? fecharCert() : abrirCert()));
  certItem.addEventListener("mouseleave", fecharCertDepois);
  certBox.addEventListener("mouseenter", () => clearTimeout(fecharCertTimer));
  certBox.addEventListener("mouseleave", fecharCertDepois);
  $("mp-novo").addEventListener("mouseenter", fecharCert);
  async function certidoes(quais) {
    fecharCert();
    if (precisaCliente()) return;
    const c = clienteSelecionado;
    status(`⏳ Abrindo ${quais.length === 1 ? "a certidão" : quais.length + " certidões"} de ${String(c.nome || "").toUpperCase()}…`);
    try {
      const res = await emitirCertidoesNoFundo(c, quais);
      const falhas = res.filter(r => !r.ok);
      status(res.map(r => `${r.ok ? "✓" : "⚠️"} ${r.nome}${r.ok ? (r.depois ? " (termina ao abrir a aba)" : "") : `: ${r.msg}`}`).join(" · ") +
        (falhas.length ? " — confira essas abas e preencha à mão." : " — resolva o captcha e emita em cada aba."), falhas.length > 0);
    } catch (e) { status("⚠️ Não consegui abrir as certidões: " + String(e?.message || e).slice(0, 80), true); }
  }
  $("mp-cert-todas").addEventListener("click", () => certidoes(["federal", "estadual", "eleitoral", "militar"]));
  certBox.querySelectorAll("[data-cert]").forEach(el => el.addEventListener("click", () => certidoes([el.dataset.cert])));

  // ── GT Sinarm CAC (só no Sinarm CAC, servicos.pf.gov.br): escolhe o evento (clube) e preenche a Guia de Tráfego ──
  // Os eventos ficam guardados aqui na extensão (o usuário pediu), com o endereço que vai em "Local de destino"
  const NO_SINARM = /servicos\.pf\.gov\.br/.test(location.ancestorOrigins?.[0] || document.referrer || "");
  const EVENTOS_PADRAO = [{ id: "ponta-negra", nome: "Clube de Tiro Ponta Negra", logradouro: "Av. Liberalina Loureiro",
    numero: "457", bairro: "Ponta Negra", cidade: "Manaus", uf: "AM", cep: "69037-216" }];
  let eventosGt = EVENTOS_PADRAO;
  const lerEventos = async () => {
    try { const r = await chrome.storage.local.get(["gtEventos"]); eventosGt = Array.isArray(r.gtEventos) ? r.gtEventos : EVENTOS_PADRAO; } catch (_) {}
  };
  const gravarEventos = () => chrome.storage?.local.set({ gtEventos: eventosGt }).catch(() => {});
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  function listarEventos() {
    const lista = $("mp-gt-lista");
    lista.innerHTML = eventosGt.length ? eventosGt.map(ev => `<div class="mp-item" data-ev="${esc(ev.id)}" style="font-size:12px;gap:6px">
        <span style="flex:1">${esc(ev.nome)}<br><small style="opacity:.7">${esc(ev.logradouro)}, ${esc(ev.numero)} – ${esc(ev.cidade)}/${esc(ev.uf)}</small></span>
        <span data-apagar="${esc(ev.id)}" title="Excluir este evento" style="opacity:.6">🗑</span></div>`).join("")
      : '<div style="font-size:12px;padding:4px 8px;opacity:.7">Nenhum evento cadastrado.</div>';
    avisarTamanho();
  }
  if (NO_SINARM) {
    $("mp-gt").style.display = "";
    lerEventos().then(listarEventos);
    // abre a lista de eventos AO LADO do submenu, na altura do item "GT Sinarm CAC" (o usuário pediu: não embaixo)
    const abrirEventos = () => {
      clearTimeout(fecharTimer);
      const fly = $("mp-flyout"), item = $("mp-gt"), box = $("mp-gt-box");
      box.style.left = `${fly.offsetLeft + fly.offsetWidth + 6}px`;
      box.style.top = `${fly.offsetTop + item.offsetTop - 6}px`;
      box.classList.add("aberto");
      item.classList.add("ativo");
      listarEventos();
    };
    $("mp-gt").addEventListener("mouseenter", abrirEventos);
    $("mp-gt").addEventListener("click", () => ($("mp-gt-box").classList.contains("aberto") && !$("mp-gt-box").contains(document.activeElement) ? ($("mp-gt-box").classList.remove("aberto"), $("mp-gt").classList.remove("ativo"), avisarTamanho()) : abrirEventos()));
    // os outros itens do submenu fecham a lista de eventos
    $("mp-flyout").querySelectorAll("[data-modo]").forEach(el => el.addEventListener("mouseenter", () => {
      if ($("mp-gt-box").contains(document.activeElement)) return;
      $("mp-gt-box").classList.remove("aberto"); $("mp-gt").classList.remove("ativo"); avisarTamanho();
    }));
    $("mp-gt-lista").addEventListener("click", e => {
      const apagar = e.target.closest("[data-apagar]");
      if (apagar) {
        e.stopPropagation();
        const ev = eventosGt.find(x => x.id === apagar.dataset.apagar);
        if (ev && confirm(`Excluir o evento "${ev.nome}"?`)) { eventosGt = eventosGt.filter(x => x !== ev); gravarEventos(); listarEventos(); }
        return;
      }
      const item = e.target.closest("[data-ev]");
      const ev = item && eventosGt.find(x => x.id === item.dataset.ev);
      if (!ev) return;
      executar("gt", JSON.stringify(ev));
    });
    $("mp-gt-novo").addEventListener("click", () => {
      const f = $("mp-gt-form");
      f.style.display = f.style.display === "none" ? "" : "none";
      if (f.style.display === "") $("mp-gt-nome").focus();
      avisarTamanho();
    });
    $("mp-gt-salvar").addEventListener("click", () => {
      const v = id => $(id).value.trim();
      if (!v("mp-gt-nome") || !v("mp-gt-logr") || !v("mp-gt-cid") || !v("mp-gt-uf")) { status("Preencha nome, logradouro, cidade e UF do evento.", true); return; }
      eventosGt = [...eventosGt, { id: "ev" + Date.now().toString(36), nome: v("mp-gt-nome"), logradouro: v("mp-gt-logr"),
        numero: v("mp-gt-num"), bairro: "", cidade: v("mp-gt-cid"), uf: v("mp-gt-uf").toUpperCase(), cep: "" }];
      gravarEventos();
      for (const id of ["mp-gt-nome", "mp-gt-logr", "mp-gt-num"]) $(id).value = "";
      $("mp-gt-form").style.display = "none";
      listarEventos();
      status("Evento salvo.");
    });
  }

  // ── Andamento: repete o status e a pausa "▶ Continuar" da tela do popup ──
  const pfStatus = $("pf-status"), pausa = $("pf-pausa");
  const repetirStatus = () => status(pfStatus.textContent, pfStatus.classList.contains("erro"));
  new MutationObserver(repetirStatus).observe(pfStatus, { childList: true, characterData: true, subtree: true, attributes: true });
  const repetirPausa = () => {
    const parado = pausa.style.display && pausa.style.display !== "none";
    $("mp-continuar").style.display = parado ? "block" : "none";
    $("mp-continuar").title = $("pf-pausa-txt")?.textContent || "";
    // o aviso da pausa (ex.: campos vazios no cadastro do sistema) aparece escrito no menu, não só no título do botão
    const txtPausa = $("pf-pausa-txt")?.textContent || "", iAviso = txtPausa.indexOf("⚠️");
    $("mp-aviso").textContent = parado && iAviso >= 0 ? txtPausa.slice(iAviso) : "";
    if (parado) abrirParaAviso();
    atualizarVisivel();
    avisarTamanho();
  };
  new MutationObserver(repetirPausa).observe(pausa, { attributes: true, attributeFilter: ["style"], childList: true, subtree: true });
  $("mp-continuar").addEventListener("click", () => $("btn-continuar-etapa").click());

  // ⏸ Pausar / ▶ Retomar e ⏹ Parar: repetem os botões do popup
  const ctrl = $("pf-controles");
  const repetirControles = () => {
    $("mp-controles").style.display = ctrl.style.display === "flex" ? "flex" : "none";
    $("mp-pausar").textContent = $("btn-pf-pausar").textContent;
    atualizarVisivel();
    avisarTamanho();
  };
  new MutationObserver(repetirControles).observe(ctrl, { attributes: true, childList: true, subtree: true, characterData: true });
  $("mp-pausar").addEventListener("click", () => $("btn-pf-pausar").click());
  $("mp-parar").addEventListener("click", () => $("btn-pf-parar").click());

  // ── Recolher: a setinha ‹ deixa só a etiqueta "Passarinho ›" no canto; a escolha fica guardada para as próximas páginas ──
  // (o menu que perdeu a ligação com a extensão não tem chrome.storage: aí só não guarda)
  const guardado = chrome.storage?.local;
  function recolher(sim, guardar = true) {
    if (sim) { fecharSub(); fecharBusca(); }
    $("menu-painel").classList.toggle("recolhido", sim);
    if (guardar) guardado?.set({ menuRecolhido: sim }).catch(() => {});
    avisarTamanho();
  }
  // aviso que precisa ser visto (erro, pausa "▶ Continuar") abre o menu recolhido, sem mudar a escolha guardada
  function abrirParaAviso() {
    if ($("menu-painel").classList.contains("recolhido")) recolher(false, false);
  }
  $("mp-recolher").addEventListener("click", e => { e.stopPropagation(); recolher(true); });
  $("mp-recolhido").addEventListener("click", () => recolher(false));
  // 2026-11-22: tudo se faz pelo popup do ícone; o menu da página começa sempre recolhido (só a etiqueta) e abre sozinho
  // quando precisa (abrirParaAviso: Continuar, aviso, erro) ou quando o popup manda preencher
  // só a caixinha de andamento (ver popup.html .so-andamento): aberta, mas escondida até ter o que mostrar
  recolher(false, false);
  $("menu-painel").classList.add("so-andamento");
  atualizarVisivel();
  $("mp-status").addEventListener("click", () => { if (!emAndamento()) status(""); });

  // Passarinho pausada pelo botão do popup (chrome.storage passarinhoPausado): o menu some por inteiro e nada roda
  // sozinho (ler processos, conferir conta, pedido guardado, carregar o sistema). Retomar volta tudo.
  let pausado = false;
  const aplicarPausa = p => {
    pausado = !!p;
    $("menu-painel").style.display = pausado ? "none" : "";
    avisarTamanho();
  };
  chrome.storage?.local.get(["passarinhoPausado"]).then(r => aplicarPausa(r.passarinhoPausado)).catch(() => {});
  chrome.storage?.onChanged?.addListener((mud, area) => {
    if (area === "local" && mud.passarinhoPausado) aplicarPausa(mud.passarinhoPausado.newValue);
  });

  // Popup do ícone → "Preencher agora": escolhe o cliente e roda o processo AQUI (o menu acompanha, mostra o
  // Continuar/Pausar e confere a conta). Só o menu da aba certa responde.
  let minhaAba = null;
  abaDoPainel().then(id => { minhaAba = id; }).catch(() => {});

  // Pedido guardado pelo popup ("Preencher agora" sem o site aberto): o popup abriu este site; espera o login no gov.br
  // e, quando a conta logada for a DO CLIENTE do pedido, começa sozinho. Vale 20 minutos. Conta de outra pessoa: avisa
  // e não faz nada (nunca preenche o processo de alguém com os dados de outro).
  const SITE_DO_MODO = m => (m === "gt" ? /servicos\.pf\.gov\.br/ : /portal\.pf\.gov\.br/);
  const ondeEstou = location.ancestorOrigins?.[0] || document.referrer || "";
  let avisouPendente = "";
  async function conferirPendente() {
    if (pausado) return;
    let p = null;
    try { p = (await chrome.storage.local.get(["acaoPendente"])).acaoPendente; } catch (_) { return; }
    if (!p) return;
    if (Date.now() - (p.em || 0) > 20 * 60 * 1000) { chrome.storage.local.remove(["acaoPendente"]).catch(() => {}); return; }
    if (!SITE_DO_MODO(p.modo).test(ondeEstou)) return;
    const tabId = await abaPfAtual();
    if (!tabId) return;
    let nome = "";
    try {
      nome = (await chrome.scripting.executeScript({ target: { tabId },
        func: () => (document.querySelector(".profile-name, .user-info-name")?.textContent || "").replace(/\s+/g, " ").trim(),
      }))?.[0]?.result || "";
    } catch (_) { return; }
    const quem = String(p.cliente?.nome || "").toUpperCase();
    if (!nome) {
      if (avisouPendente !== "login") {
        avisouPendente = "login";
        recolher(false, false);
        status(`⏳ Faça o login no gov.br com a conta de ${quem}. Depois disso a Passarinho começa sozinha.`);
      }
      return;
    }
    if (!mesmoNome(nome, p.cliente?.nome || "")) {
      if (avisouPendente !== nome) {
        avisouPendente = nome;
        status(`⛔ A conta aberta é de ${nome.toUpperCase()}, mas o pedido é de ${quem}. Nada foi preenchido: saia e entre na conta certa.`, true);
      }
      return;
    }
    // conta certa: tira o pedido (para não rodar duas vezes) e começa
    await chrome.storage.local.remove(["acaoPendente"]).catch(() => {});
    if (clienteSelecionado?.id !== p.cliente?.id) {
      if (!clientesSistema.length) await carregarClientesSistema();
      await selecionarClienteSistema(clientesSistema.find(c => c.id === p.cliente?.id) || p.cliente);
      mostrarCliente();
    }
    recolher(false, false);
    status("");
    executar(p.modo, p.variante || "");
  }
  setTimeout(conferirPendente, 2500);
  // sempre conferindo (antes parava 25 min depois de abrir a página, e o "Preencher agora" do popup também usa o pedido
  // guardado quando a mensagem não chega a este quadro)
  setInterval(conferirPendente, 3000);
  // popup aberto nesta aba pergunta qual é o cliente daqui (um só cliente escolhido: o do menu, que é o da conta aberta)
  chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
    if (msg?.action !== "qualCliente" || !minhaAba || msg.tabId !== minhaAba) return false;
    responder({ cliente: clienteSelecionado || null });
    return false;
  });
  chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
    if (msg?.action !== "menuExecutar" || !minhaAba || msg.tabId !== minhaAba) return false;
    (async () => {
      try {
        if (msg.cliente?.id && clienteSelecionado?.id !== msg.cliente.id) {
          if (!clientesSistema.length) await carregarClientesSistema();
          await selecionarClienteSistema(clientesSistema.find(c => c.id === msg.cliente.id) || msg.cliente);
          mostrarCliente();
        }
        recolher(false, false);
        status("");
        executar(msg.modo, msg.variante || "");
        responder({ ok: true });
      } catch (e) { responder({ ok: false, erro: String(e?.message || e) }); }
    })();
    return true;
  });
  // clique no ícone da extensão no portal (background.js) abre o menu recolhido
  chrome.storage?.onChanged?.addListener((mud, area) => {
    if (area === "local" && mud.menuRecolhido && mud.menuRecolhido.newValue === false) recolher(false, false);
  });

  // cliente guardado da última vez (o popup.js restaura sozinho ao abrir)
  const inicio = setInterval(mostrarCliente, 500);
  setTimeout(() => clearInterval(inicio), 6000);
  mostrarCliente();
  repetirPausa();

  // ── Conta aberta x cliente escolhido (o usuário pediu): se o nome da conta no Sinarm CAC / Portal PF não bate com o
  // cliente do menu, troca sozinho para o cliente certo (um único com esse nome em Clientes Armas) ou tira o cliente
  // e abre a busca para escolher à mão. Nunca mexe enquanto um preenchimento está rodando.
  let contaConferida = "";
  async function conferirConta() {
    if (pausado) return;
    const tabId = await abaPfAtual();
    if (!tabId) return;
    let nome = "";
    try {
      nome = (await chrome.scripting.executeScript({ target: { tabId },
        func: () => (document.querySelector(".profile-name, .user-info-name")?.textContent || "").replace(/\s+/g, " ").trim(),
      }))?.[0]?.result || "";
    } catch (_) { return; }
    if (!nome) { contaConferida = ""; return; }
    const atual = clienteSelecionado?.nome || "";
    const chave = nome + "|" + atual;
    if (chave === contaConferida) return;
    if (atual && mesmoNome(nome, atual)) { contaConferida = chave; return; }
    const estado = await lerEstadoPf(tabId);
    if (estado?.rodando) return;
    if (!clientesSistema.length) await carregarClientesSistema();
    const iguais = clientesSistema.filter(c => mesmoNome(nome, c.nome));
    if (iguais.length === 1) {
      fecharBusca();
      await selecionarClienteSistema(iguais[0]);
      mostrarCliente();
      status(atual ? `Cliente trocado para ${String(iguais[0].nome).toUpperCase()} (é a conta aberta).` : "");
    } else if (atual) {
      limparClienteSistema();
      mostrarCliente();
      // a busca de cliente não aparece mais aqui (o menu é o popup do ícone): avisa na caixinha
      status(iguais.length > 1
        ? `⚠️ A conta aberta é de ${nome.toUpperCase()} e há mais de um cadastro com esse nome em Clientes Armas. Corrija no sistema.`
        : `⚠️ A conta aberta é de ${nome.toUpperCase()}, que não está em Clientes Armas. Cadastre no sistema para usar a Passarinho.`, true);
    }
    contaConferida = nome + "|" + (clienteSelecionado?.nome || "");
  }
  // PF aberta (inclusive na aba anônima): já busca os clientes; sem aba do sistema logada, o popup.js abre o sistema
  // sozinho numa aba de fundo da janela normal (abrirSistemaNaJanelaNormal)
  setTimeout(() => { if (!pausado && !clientesSistema.length) carregarClientesSistema(); }, 1200);
  setTimeout(conferirConta, 1500);
  setInterval(conferirConta, 3000);

  // ── Conferência no Portal PF (2026-11-24, o usuário pediu: sistema e Portal lado a lado) ──
  // Nos "Dados pessoais" do Portal PF, pinta cada dado: VERDE quando é igual ao cadastro do sistema, VERMELHO quando
  // está diferente ou vazio (passando o mouse mostra o que está no sistema). Só com a conta aberta = cliente escolhido.
  // Não muda nada no site da PF: só a cor das letras.
  async function marcarConferenciaPf() {
    if (pausado || !/portal\.pf\.gov\.br/.test(ondeEstou)) return;
    const c = clienteSelecionado;
    if (!c?.id) return;
    const tabId = await abaPfAtual();
    if (!tabId) return;
    const data = String(c.data_nascimento || "").split("T")[0].split("-");
    const sistema = {
      "nome completo": c.nome, "data de nascimento": data.length === 3 ? `${data[2]}/${data[1]}/${data[0]}` : "",
      "cpf": c.cpf, "genero": c.genero, "nome da mae": c.nome_mae, "uf": c.estado, "cidade": c.cidade, "cep": c.cep,
      "endereco residencial": c.endereco, "bairro": c.bairro, "no": c.numero, "complemento": c.complemento,
      // Formulário (campos que se digitam): rótulo da PF → dado do sistema
      "endereco": c.endereco, "sexo": c.genero, "no identidade": c.rg, "orgao emissor": c.orgao_emissor,
      "data de expedicao": (d => d.length === 3 ? `${d[2]}/${d[1]}/${d[0]}` : "")(String(c.data_expedicao || "").split("T")[0].split("-")),
      "uf de nascimento": c.uf_nascimento, "local de nascimento": c.local_nascimento, "profissao": c.profissao,
      "telefone 1": c.telefone, "e mail": c.email, "nome do pai": c.nome_pai,
    };
    let res = null;
    try {
      res = (await chrome.scripting.executeScript({ target: { tabId }, args: [sistema], func: sistema => {
        // resultado de cada campo, para pintar também o cadastro no sistema RW (rótulo da PF → campo)
        const CAMPO = { "nome completo": "nome", "data de nascimento": "nasc", "cpf": "cpf", "genero": "genero", "sexo": "genero",
          "nome da mae": "mae", "uf": "estado", "cidade": "cidade", "cep": "cep", "endereco residencial": "endereco",
          "endereco": "endereco", "bairro": "bairro", "no": "numero", "complemento": "complemento", "no identidade": "rg",
          "orgao emissor": "orgao", "data de expedicao": "expedicao", "uf de nascimento": "ufnasc",
          "local de nascimento": "localnasc", "profissao": "profissao", "telefone 1": "telefone", "e mail": "email", "nome do pai": "pai" };
        const res = {};
        const n = t => String(t || "").replace(/\([^)]*\)/g, " ").normalize("NFD").replace(/[̀-ͯ]/g, "")
          .toLowerCase().replace(/[º°]/g, "o").replace(/[^a-z0-9/ ]/g, " ").replace(/\s+/g, " ").trim();
        const so = t => String(t || "").replace(/\D/g, "");
        const igual = (rot, pf, sis) => {
          if (rot === "cpf" || rot === "cep" || rot === "no identidade") return so(pf) === so(sis);
          if (rot === "telefone 1") return so(pf).slice(-8) === so(sis).slice(-8);
          if (rot === "genero" || rot === "sexo") return n(pf).charAt(0) === n(sis).charAt(0);
          // "AM — Amazonas" (lista da PF) x "AM"; "SSP" x "SSP-AM"
          if (rot === "uf" || rot === "uf de nascimento") return n(pf).split(" ")[0] === n(sis).split(" ")[0];
          if (rot === "orgao emissor") { const a = n(pf), b = n(sis); return !!a && (b.startsWith(a) || a.startsWith(b)); }
          if (/endereco/.test(rot)) { const a = n(pf), b = n(sis); return a === b || a.includes(b) || b.includes(a); }
          return n(pf) === n(sis);
        };
        const pintar = (el, ok, sis) => {
          el.style.setProperty("color", ok ? "#0a8a3a" : "#d32f2f", "important");
          el.style.setProperty("font-weight", "700", "important");
          el.title = ok ? "✓ Igual ao sistema" : `✗ No sistema: ${sis || "(vazio)"}`;
        };
        // Formulário: <label> + campo (input / lista). Data do campo vem como 1992-06-21
        for (const lab of document.querySelectorAll("label")) {
          if (lab.closest("#passarinho-painel")) continue;
          const rot = n(lab.textContent.replace(/\*/g, ""));
          if (!(rot in sistema)) continue;
          const SEL = "input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea";
          // o campo logo DEPOIS do rótulo (o primeiro da linha poderia ser de outro rótulo)
          const depois = () => {
            for (let el = lab.nextElementSibling; el; el = el.nextElementSibling) {
              if (el.matches(SEL)) return el;
              const x = el.querySelector(SEL);
              if (x) return x;
            }
            return null;
          };
          const campo = (lab.htmlFor && document.getElementById(lab.htmlFor)) || depois() || lab.parentElement?.querySelector(SEL);
          if (!campo) continue;
          let pf = campo.tagName === "SELECT" ? (campo.selectedOptions[0]?.textContent || "") : campo.value;
          if (/^\d{4}-\d{2}-\d{2}$/.test(pf)) { const [a, m, d] = pf.split("-"); pf = `${d}/${m}/${a}`; }
          pf = String(pf || "").trim();
          const sis = String(sistema[rot] || "").trim();
          if (!sis && !pf) { campo.style.removeProperty("color"); continue; }
          const okCampo = !!pf && !!sis && igual(rot, pf, sis);
          pintar(campo, okCampo, sis);
          res[CAMPO[rot]] = okCampo;
        }
        // rótulo = elemento só com texto igual ao nome do campo; o valor é o elemento logo depois dele
        const folhas = [...document.querySelectorAll("label,span,div,p,strong,b,dt,th,small")]
          .filter(el => !el.children.length && el.textContent.trim().length < 40);
        for (const rotEl of folhas) {
          const rot = n(rotEl.textContent);
          if (!(rot in sistema) || rotEl.closest("#passarinho-painel")) continue;
          const valEl = rotEl.nextElementSibling || rotEl.parentElement?.nextElementSibling;
          if (!valEl || valEl.contains(rotEl)) continue;
          // campo de digitar (Formulário): já conferido acima, pelo valor do campo
          if (valEl.matches("input,select,textarea") || valEl.querySelector("input,select,textarea")) continue;
          const pf = valEl.textContent.replace(/\s+/g, " ").trim();
          const sis = String(sistema[rot] || "").trim();
          const vazioPf = !pf || pf === "—" || pf === "-";
          if (!sis && vazioPf) { valEl.style.removeProperty("color"); continue; }
          const ok = !vazioPf && sis && igual(rot, pf, sis);
          valEl.style.setProperty("color", ok ? "#0a8a3a" : "#d32f2f", "important");
          valEl.style.setProperty("font-weight", "700", "important");
          valEl.title = ok ? "✓ Igual ao sistema" : `✗ No sistema: ${sis || "(vazio)"}`;
          if (!(CAMPO[rot] in res)) res[CAMPO[rot]] = !!ok;
        }
        return res;
      } }))?.[0]?.result || null;
    } catch (_) {}
    // Pinta também o cadastro aberto no sistema RW (o usuário pediu, 2026-11-25: "não destacou no meu sistema"),
    // em cada aba do sistema que estiver com o cadastro DESTE cliente aberto. Só quando o resultado muda (ou a cada 15 s,
    // se o cadastro foi aberto depois). Nunca abre aba do sistema para isso.
    if (!res || !Object.keys(res).length) return;
    const assinatura = c.id + JSON.stringify(res);
    if (assinatura === conferenciaEnviada && Date.now() - conferenciaEm < 15000) return;
    conferenciaEnviada = assinatura; conferenciaEm = Date.now();
    for (const abaSistema of await abasDoSite().catch(() => [])) {
      try {
        await chrome.scripting.executeScript({ target: { tabId: abaSistema }, world: "MAIN", func: SITE_FUNCS.marcarConferencia, args: [c.nome, res] });
      } catch (_) {
        // sistema na janela normal e a PF na anônima: o background roda por nós (só funções de site-funcs.js, pelo nome)
        chrome.runtime.sendMessage({ action: "rodarNoSite", tabId: abaSistema, nome: "marcarConferencia", args: [c.nome, res] }).catch(() => {});
      }
    }
  }
  let conferenciaEnviada = "", conferenciaEm = 0;
  setInterval(marcarConferenciaPf, 3000);

  // ── Acompanhamento do processo: na tela "Minhas solicitações" do Portal PF (conta gov do cliente) lê o status
  // de cada pedido e grava no site (tabela processos_pf). O cliente vê no link /acompanhamento/<id do cliente>.
  // Só grava quando o nome da conta na PF bate com um cliente de Clientes Armas (o escolhido no menu, ou o único com
  // esse nome); "status_desde" só muda quando o status de um protocolo muda.
  let ultimaLeitura = "", avisouErro = "", salvoEm = 0;
  const limparNome = t => String(t || "").replace(/\([^)]*\)/g, " ").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/\s+/g, " ").trim();
  async function lerSolicitacoesPf() {
    if (pausado) return;
    const tabId = await abaPfAtual();
    if (!tabId) return;
    let lido = null;
    try {
      lido = (await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: () => {
        const texto = el => {
          if (!el) return "";
          const c = el.cloneNode(true);
          c.querySelectorAll(".p-column-title").forEach(x => x.remove()); // rótulo da coluna (aparece em tela estreita)
          return c.textContent.replace(/\s+/g, " ").trim();
        };
        // Sinarm CAC (servicos.pf.gov.br/sisgcorp...): Solicitação de Serviço › Pessoa Física › Listar Processo.
        // Colunas: Nr Protocolo, Data de Entrada, Serviço, Situação do Processo, Motivo, OM, Situação da GRU, Posição na fila
        if (location.hostname === "servicos.pf.gov.br") {
          if (!/^#\/listar-processos/.test(location.hash)) return null;
          const linhas = [...document.querySelectorAll("table tbody tr")].map(tr => {
            const td = tr.querySelectorAll("td");
            return { origem: "sinarm", protocolo: texto(td[0]), data: texto(td[1]), servico: texto(td[2]), status: texto(td[3]),
              motivo: texto(td[4]), gru: texto(td[6]), posicao_fila: texto(td[7]), descricao: "" };
          }).filter(l => /\d{4,}/.test(l.protocolo));
          return { nome: (document.querySelector(".profile-name")?.textContent || "").trim(), linhas };
        }
        // Portal PF (portal.pf.gov.br): Minhas solicitações
        if (!/^#\/solicitacoes\/?(\?.*)?$/.test(location.hash)) return null;
        const linhas = [...document.querySelectorAll("app-solicitacoes-table table tbody tr, app-portal-table table tbody tr")]
          .map(tr => {
            const td = tr.querySelectorAll("td");
            return {
              servico: texto(td[0]?.querySelector(".solicitacao-titulo")) || texto(td[0]),
              descricao: texto(td[0]?.querySelector(".solicitacao-descricao")),
              protocolo: texto(td[1]), data: texto(td[2]), status: texto(td[3]),
            };
          })
          .filter(l => /\d{4}-\d+/.test(l.protocolo));
        return { nome: (document.querySelector(".user-info-name")?.textContent || "").trim(), linhas };
      } }))?.[0]?.result;
    } catch (_) { return; }
    // fora da lista (saiu da conta, foi para outra tela, entrou em outra conta): abrir a lista de novo conta como
    // consulta nova e atualiza a "Última consulta" do link, mesmo que nada tenha mudado
    if (!lido?.nome || !lido.linhas?.length) { ultimaLeitura = ""; return; }
    const assinatura = JSON.stringify(lido);
    // a mesma lista continua aberta: não grava de novo a cada 4 s, só a cada 10 minutos
    if (assinatura === ultimaLeitura && Date.now() - salvoEm < 10 * 60 * 1000) return;

    if (!clientesSistema.length) await carregarClientesSistema();
    const alvo = limparNome(lido.nome);
    let cli = clienteSelecionado?.id && limparNome(clienteSelecionado.nome) === alvo ? clienteSelecionado : null;
    if (!cli) {
      const achados = clientesSistema.filter(c => limparNome(c.nome) === alvo);
      if (achados.length === 1) cli = achados[0];
    }
    if (!cli?.id) {
      ultimaLeitura = assinatura;
      status(!clientesSistema.length
        ? `⚠️ Não consegui falar com o sistema RW (lista de clientes vazia). Diagnóstico: ${window.__passarinho_diag_sistema || "sem tentativa"}`
        : `⚠️ Status da PF não salvo: não achei "${lido.nome}" em Clientes Armas (ou há mais de um com esse nome). Escolha o cliente no menu.`, true);
      return;
    }

    const resp = await noSite("salvarProcessos", [cli.id, lido.linhas]);

    if (resp?.ok) {
      ultimaLeitura = assinatura; avisouErro = ""; salvoEm = Date.now();
      noSite("concluirPedidosDoCliente", [cli.id]).catch(() => {}); // pedido do celular dele: atendido aqui mesmo
      status(`📋 Status ${lido.linhas[0]?.origem === "sinarm" ? "do Sinarm CAC" : "do Portal PF"} salvo para ${cli.nome}: ${lido.linhas.length} solicitação(ões)` +
        (resp.mudaram ? `, ${resp.mudaram} com status novo.` : "."));
    } else if (avisouErro !== assinatura) {
      avisouErro = assinatura;
      status("⚠️ Não consegui salvar o status da PF. Deixe o rwinvestimentos.com.br aberto e logado em outra aba.", true);
    }
  }
  setInterval(lerSolicitacoesPf, 4000);
  lerSolicitacoesPf();

  // Cliente pediu atualização pelo celular (2026-11-25): com o Portal PF aberto a Passarinho não atende sozinha (derrubaria
  // a conta aberta aqui), então avisa quem está esperando. Abrir "Minhas solicitações" na conta dele já atende.
  let avisoPedidos = "";
  async function avisarPedidos() {
    if (pausado || emAndamento()) return;
    // este computador não atende a fila (opção do popup): não vai fechar aba nenhuma, então não avisa
    if ((await chrome.storage.local.get(["filaDesligada"]).catch(() => ({}))).filaDesligada) return;
    // só atrapalha o Portal PF aberto numa janela NORMAL (as anônimas têm sessão própria e não seguram o pedido)
    const normais = await chrome.tabs.query({ url: ["https://portal.pf.gov.br/*", "https://servicos.pf.gov.br/*", "https://sso.acesso.gov.br/*"] })
      .then(t => t.filter(x => !x.incognito)).catch(() => []);
    if (!normais.length) { avisoPedidos = ""; return; }
    const r = await noSite("pedidosPendentes", []).catch(() => null);
    if (!r?.ok) return;
    // 2026-11-28 (o usuário achou o aviso gigante): só os pedidos do CELULAR têm nome (no máximo 2); os da consulta geral
    // ("automatico") não foram pedidos por cliente nenhum e viram só "consulta geral em andamento". Aviso curto, que some
    // sozinho, e só reaparece quando muda quem está esperando.
    const nomes = [...new Set(r.pedidos.filter(p => !p.automatico).map(p => p.nome).filter(Boolean))];
    const geral = r.pedidos.filter(p => p.automatico).length;
    const chave = nomes.join("|") + (geral ? "|geral" : "");
    if (chave === avisoPedidos) return;
    avisoPedidos = chave;
    if (!nomes.length && !geral) return;
    const quem = nomes.length
      ? `📲 ${nomes.slice(0, 2).map(n => n.split(" ")[0].toUpperCase()).join(", ")}${nomes.length > 2 ? ` e mais ${nomes.length - 2}` : ""} pediu consulta pelo celular`
      : `🔎 Consulta geral em andamento (${geral} na fila)`;
    status(`${quem}. Esta aba do Portal PF pode ser fechada em até 30 s para a Passarinho consultar (as anônimas ficam).`);
  }
  setInterval(avisarPedidos, 15000);
  setTimeout(avisarPedidos, 4000);
})();
