// Menu do Passarinho fixo no Portal PF, no canto de cima à esquerda (no estilo do "Sinarm CAC – Assistente",
// em dourado e preto): cliente, Cadastro inicial e Novo processo › CR / AC / Registrar arma de fogo. O menu é a página
// da extensão (popup.html?painel=1, em menu-painel.js) num quadro transparente do tamanho dele: fica sempre na tela e
// não fecha quando se clica no site, ao contrário do popup.
(() => {
  // __passarinhoPainel: versão do menu já posto nesta página (a extensão recarregada com versão nova põe outro no lugar)
  const versao = chrome.runtime.getManifest().version;
  if (window.top !== window || window.__passarinhoPainel === versao) return;
  window.__passarinhoPainel = versao;
  // Menu de antes da extensão ser recarregada: o script antigo o recoloca se for tirado, então só fica escondido
  const antigo = document.getElementById("passarinho-painel");
  if (antigo) {
    antigo.id = "passarinho-painel-antigo";
    antigo.style.setProperty("display", "none", "important");
  }
  const host = document.createElement("div");
  host.id = "passarinho-painel";
  // no canto de cima à esquerda (o usuário pediu); o submenu abre para a direita e a setinha recolhe o menu numa etiqueta
  host.style.cssText = "all:initial;position:fixed;top:8px;left:8px;z-index:2147483646;";
  // no Sinarm CAC (servicos.pf.gov.br) o canto é o logo e a setinha do site: fica na barra de cima, depois do menu lateral
  if (location.hostname === "servicos.pf.gov.br") {
    // fica logo abaixo do menu lateral do site (depois de "Controle de Venda de Munições") e acompanha a altura dele:
    // abrir um menu empurra o Passarinho para baixo; com o menu lateral fechado, fica na barra de cima
    // fim do último item VISÍVEL do menu: submenu fechado continua no meio da lista (escondido, mas ocupando altura),
    // então a altura da lista inteira deixava o Passarinho bem abaixo de "Controle de Venda de Munições"
    const fimDoMenu = () => {
      let fim = 0;
      for (const a of document.querySelectorAll("app-menu a")) {
        const r = a.getBoundingClientRect();
        if (!r.height || !r.width) continue;
        let aparece = true;
        for (let p = a.parentElement; p && p.tagName !== "APP-MENU"; p = p.parentElement) {
          if (p.tagName !== "UL") continue;
          const rp = p.getBoundingClientRect();
          if (rp.height < 1 || r.top >= rp.bottom - 1 || getComputedStyle(p).display === "none") { aparece = false; break; }
        }
        if (aparece) fim = Math.max(fim, r.bottom);
      }
      return fim;
    };
    // Ao abrir a página o menu do site ainda não existe (ou ainda não tem os itens): antes o Passarinho ia para a barra
    // de cima e depois descia, "bugando" na abertura. Agora fica ESCONDIDO até achar o lugar certo; a barra de cima só
    // vale quando o menu lateral foi FECHADO pelo usuário (lista existe, mas recolhida). Sem nada em 8 s, aparece em cima.
    let posicionado = false;
    const inicio = Date.now();
    host.style.visibility = "hidden";
    const mostrar = () => { if (!posicionado) { posicionado = true; host.style.visibility = ""; } };
    const seguirMenu = () => {
      const lista = document.querySelector("app-menu ul.ultima-main-menu");
      const r = lista && lista.getBoundingClientRect();
      const aberto = !!r && r.width > 40 && r.right > 0;
      const fim = aberto ? fimDoMenu() : 0;
      let left, top;
      if (aberto && fim > 0) {
        left = Math.max(8, Math.round(r.left + 8)) + "px";
        top = Math.min(Math.round(fim + 8), innerHeight - 40) + "px";
      } else if (lista && !aberto && document.readyState === "complete" && (posicionado || Date.now() - inicio > 1500)) {
        left = "270px"; top = "8px";            // menu lateral fechado: barra de cima
      } else if (!posicionado && Date.now() - inicio > 8000) {
        left = "270px"; top = "8px";            // o site não mostrou o menu: não deixa o Passarinho sumido
      } else return;                            // ainda carregando: espera, sem pular de lugar
      if (host.style.left !== left) host.style.left = left;
      if (host.style.top !== top) host.style.top = top;
      mostrar();
    };
    seguirMenu();
    // o menu abre com animação: confere a posição várias vezes por segundo (é só uma medida, não pesa)
    setInterval(seguirMenu, 200);
    addEventListener("resize", seguirMenu);
    addEventListener("scroll", seguirMenu, true);
  }
  const raiz = host.attachShadow({ mode: "closed" });
  // a sombra é do quadro (drop-shadow segue o desenho do menu): dentro dele ela ficava cortada na borda
  raiz.innerHTML = "<style>iframe{display:block;border:0;background:transparent;color-scheme:normal;width:252px;height:200px;" +
    "filter:drop-shadow(0 8px 18px rgba(0,0,0,.45))}</style>";
  const quadro = document.createElement("iframe");
  quadro.src = chrome.runtime.getURL("popup.html?painel=1");
  quadro.allow = "clipboard-write";
  raiz.appendChild(quadro);
  // o menu avisa o tamanho que precisa (com o submenu ou a busca aberta ele cresce; recolhido é só a etiqueta, e o
  // quadro transparente não pode passar dela, senão tapa cliques no site)
  window.addEventListener("message", e => {
    if (e.source !== quadro.contentWindow || !e.data || e.data.passarinho !== "tamanho") return;
    const r = quadro.getBoundingClientRect();
    quadro.style.width = Math.min(Math.max(40, e.data.w), innerWidth - r.left - 8) + "px";
    quadro.style.height = Math.min(Math.max(24, e.data.h), innerHeight - r.top - 8) + "px";
  });
  const colocar = () => { if (!host.isConnected && document.body) document.body.appendChild(host); };
  colocar();
  // site que redesenha a página inteira tiraria o menu junto
  new MutationObserver(colocar).observe(document.documentElement, { childList: true });
  if (document.body) new MutationObserver(colocar).observe(document.body, { childList: true });

  // Sair de verdade (2026-11-25, o usuário pediu): no Portal PF / Sinarm CAC, clicar em "Sair" saía e entrava de novo na
  // MESMA conta (a sessão do gov.br continua guardada no navegador). Ao clicar em Sair, a Passarinho apaga a sessão do
  // gov.br e da PF neste navegador (background.js, limparSessaoGov) e volta para a tela de entrar.
  if (/^(portal|servicos)\.pf\.gov\.br$/.test(location.hostname)) {
    document.addEventListener("click", e => {
      const el = e.target?.closest?.("button,a,[role=button],[role=menuitem],li");
      // 2026-11-26: "/s+/" (sem a barra) trocava as letras "s" e o "Sair" nunca era reconhecido
      const t = (el?.textContent || "").replace(/\s+/g, " ").trim();
      if (!el || !/^(sair|sair do sistema|sair do portal)$/i.test(t)) return;
      try { chrome.runtime.sendMessage({ action: "sairGov" }); } catch (_) {}
    }, true);
  }
})();
